from .Item import *

class DiamondOre(Item):
    def getName(self):
        return "minecraft:diamond_ore"

    def getTexturFile(self):
        return "./texturs/items/diamond_ore.jpe"

handler.register(DiamondOre)
