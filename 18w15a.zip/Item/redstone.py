from .Item import *

class Redstone(Item):
    def getName(self):
        return "minecraft:redstone"

    def getTexturFile(self):
        return "./texturs/items/redstone.png"

handler.register(Redstone)
