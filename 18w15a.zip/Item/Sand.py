from .Item import *

class Sand(Item):
    def getName(self):
        return "minecraft:sand"

    def getTexturFile(self):
        return "./texturs/items/sand_item.jpe"

handler.register(Sand)
