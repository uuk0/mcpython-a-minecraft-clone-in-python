from .Item import *

class Gravel(Item):
    def getName(self):
        return "minecraft:gravel"

    def getTexturFile(self):
        return "./texturs/items/gravel.jpe"

handler.register(Gravel)
