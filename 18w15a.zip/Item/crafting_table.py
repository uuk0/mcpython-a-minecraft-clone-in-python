from .Item import *

class crafting_table(Item):
    def getName(self):
        return "minecraft:crafting_table"

    def getTexturFile(self):
        return "./texturs/items/crafting_table.jpe"

    def getFuelAmount(self):
        return 20

handler.register(crafting_table)
