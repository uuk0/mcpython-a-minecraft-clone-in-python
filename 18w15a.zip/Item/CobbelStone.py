from .Item import *

class CobbelStone(Item):
    def getName(self):
        return "minecraft:cobblestone"

    def getTexturFile(self):
        return "./texturs/items/cobbel_stone_item.jpe"

handler.register(CobbelStone)
