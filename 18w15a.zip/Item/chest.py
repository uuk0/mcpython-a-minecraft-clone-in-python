from .Item import *

class chest(Item):
    def getName(self):
        return "minecraft:chest"

    def getTexturFile(self):
        return "./texturs/items/chest.jpe"

    def getFuelAmount(self):
        return 20

handler.register(chest)
