from .Item import *
from oredictnames import *

class Wood_Log_0(Item):
    def getName(self):
        return "minecraft:wood_log_0"

    def getTexturFile(self):
        return "./texturs/items/wood_log_0.jpe"

    def getOreDictNames(self):
        return [OreDict.WOOD_LOG]

    def getFuelAmount(self):
        return 20

handler.register(Wood_Log_0)

class Wood_Log_1(Item):
    def getName(self):
        return "minecraft:wood_log_1"

    def getTexturFile(self):
        return "./texturs/items/jugle_wood_1.jpe"

    def getOreDictNames(self):
        return [OreDict.WOOD_LOG]

    def getFuelAmount(self):
        return 20

handler.register(Wood_Log_1)

class Wood_Log_2(Item):
    def getName(self):
        return "minecraft:wood_log_2"

    def getTexturFile(self):
        return "./texturs/items/wood_log_2.jpe"

    def getOreDictNames(self):
        return [OreDict.WOOD_LOG]

    def getFuelAmount(self):
        return 20

handler.register(Wood_Log_2)
