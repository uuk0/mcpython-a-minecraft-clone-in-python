from .Item import *

class Cactus(Item):
    def getName(self):
        return "minecraft:cactus"

    def getTexturFile(self):
        return "./texturs/items/cactus.jpe"

handler.register(Cactus)
