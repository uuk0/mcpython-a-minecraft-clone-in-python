from .Item import *

class Stone(Item):
    def getName(self):
        return "minecraft:stone"

    def getTexturFile(self):
        return "./texturs/items/stone_item.jpe"

handler.register(Stone)
