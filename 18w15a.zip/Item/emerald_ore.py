from .Item import *

class Bedrock(Item):
    def getName(self):
        return "minecraft:emerald_ore"

    def getTexturFile(self):
        return "./texturs/items/bedrock_item.jpe"

handler.register(Bedrock)
