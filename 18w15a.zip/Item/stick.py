from .Item import *

class Stick(Item):
    def getName(self):
        return "minecraft:stick"

    def getTexturFile(self):
        return "C:/Python/mcpython/mcpython20/masterA/texturs/items/stick.jpg"

    def hasBlock(self):
        return False

    def getFuelAmount(self):
        return 20

handler.register(Stick)
