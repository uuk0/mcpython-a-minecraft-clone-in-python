from .Block import *

class IronBlock(Block):
    def getTex(self):
        return tex_coords((11, 2), (11, 2), (11, 2))

    def getName(self):
        return "minecraft:iron_block"

    def getDestroyGroups(self):
        return [destroyGroups.PIKAXE]

handler.register(IronBlock)
