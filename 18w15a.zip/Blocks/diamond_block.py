from .Block import *

class DiamondBlock(Block):
    def getTex(self):
        return tex_coords((11, 0), (11, 0), (11, 0))

    def getName(self):
        return "minecraft:diamond_block"

    def getDestroyGroups(self):
        return [destroyGroups.PIKAXE]

handler.register(DiamondBlock)
