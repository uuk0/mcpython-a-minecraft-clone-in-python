from moduls import *

class handler:
    def __init__(self):
        self.files = []
        self.groups = {}

    def register(self, file, id):
        if not file in self.files:
            print("[texturhandler/INFO] adding textur file: "+file)
            self.files.append(file)
            self.groups[id] = TextureGroup(image.load(file).get_texture())

    def getGroup(self, id):
        return self.groups[id]


handler = handler()
handler.register("./texturs/texture.png", 0)
handler.register("./texturs/textur2.png", 1)
#handler.register("./texturs/texture3.png", 2)
