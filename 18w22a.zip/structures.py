import pickle

STRUCTUR_VERSION = "0.0.4"
COMPATIBLE = [STRUCTUR_VERSION, "0.0.3"]

""".structur file data:
pickled: {"version":"0.1.1",
          "size":(x, y, z),
          "blocks":[<blocklist>],
          "name":name}

block: [mode, ...]
mode = 0: add block with name at position
mode = 1: remove block at position
mode = 2: nbtchange x y z name data"""

class StructurHandler:
    def __init__(self):
        self.structurs = {}

    def register(self, structur):
        self.structurs[structur.name] = structur


handler = StructurHandler()

class Structur:
    def __init__(self, file):
        f = open("./assets/structures/"+file+".structur", mode="rb")
        data = pickle.load(f)
        f.close()
        if not data["version"] in COMPATIBLE:
            print("[ERROR] can't load structur "+file+". structur version not compatible")
        else:
            self.size = data["size"]
            self.blocks = data["blocks"]
            self.name = data["name"]
            self.data = data
            handler.register(self)

    def past(self, model, x, y, z):
        for e in self.blocks:
            if e[0] == 0:
                model.add_block((e[2][0]+x, e[2][1]+y, e[2][2]+z), e[1], save=False)
            elif e[0] == 1:
                model.remove_block((e[1][0]+x, e[1][1]+y, e[1][2]+z), save=False)
            elif e[0] == 2:
                model.world[(e[1][0]+x, e[1][1]+y, e[1][2]+z)].setNBT(e[2], e[3])
