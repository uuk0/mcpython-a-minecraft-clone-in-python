from moduls import *
import Item as Item_file
import texturGroups
from EventHandler import *
from config import CONFIGS
import traceback

class InventoryHandler:
    def __init__(self):
        self.inventorys = []
        self.shown = []
        self.inventoryinst = {}
        self.inventoryslotsinst = {}
        self.window = None
        self.nextslotid = 0
        self.nextinvid = 0
        self.v1 = 0
        self.states = {}
        eventhandler.on_event("on_invalid_game_state", self.checkstates)
        self.eventbinds = []
        self.active = []

    def checkstates(self, eventname, statename):
        print(statename, self.states, statename in self.states.keys(), self.states.keys())
        if statename in self.states.keys():
            inst = self.states[statename]
            self.window.menüeventbinds.append(eventhandler.on_event("on_draw_3D", self.window.on_draw_3d_game))
            self.window.menüeventbinds.append(eventhandler.on_event("on_draw_2D", self.draw))
            self.window.menüeventbinds.append(eventhandler.on_event("on_mouse_press", self.window.player.inventory.on_mouse_press))
            self.window.menüeventbinds.append(eventhandler.on_event("on_mouse_motion", self.window.player.inventory.on_mouse_motion))
            self.window.menüeventbinds.append(eventhandler.on_event("on_key_press", self.on_key_press))
            self.eventbinds = self.window.menüeventbinds[-5:]
            self.window.set_exclusive_mouse(False)

    def on_key_press(self, eventname, symbol, modifiers):
        if symbol == key.ESCAPE:
            for e in self.eventbinds:
                eventhandler.unregister_on_event(e)
            self.window.set_menü("game")
            self.shown = [0]

    def register(self, klass):
        self.inventorys.append(klass)

    def show(self, id):
        if id not in self.shown:
            self.shown.append(id)
            if self.inventoryinst[id].mouseOut():
                self.v1 += 1
                if self.window: self.window.set_exclusive_mouse(False)

    def hide(self, id):
        if id in self.shown:
            self.shown.remove(id)
            if self.inventoryinst[id].mouseOut():
                self.v1 -= 1
                if self.v1 == 0 and self.window:
                    self.window.set_exclusive_mouse(True)
        if id in self.active:
            self.active.remove(id)

    def draw(self, *args):
        iitems = []
        flag = [False] * 3
        flag2 = [True] * 3
        for e in self.shown:
            e = self.inventoryinst[e]
            if e.getId() == 4 or e.getId() == 5:
                flag = [True] * 3
                flag2[2] = False
                iitems.append(e)
        for e in iitems:
            e.draw()
        if 1 in self.shown or flag[1]:
            for i in range(1, 4):
                if flag2[i-1]: self.inventoryinst[i].draw(image=not flag[i-1])
            flag[0] = True
        if 0 in self.shown or flag:
            self.inventoryinst[0].draw(image=1 not in self.shown or not flag[0])


    def registerInst(self, inst):
        print("[INFO] registering inventoryInst: "+str(inst))
        id = self.nextinvid
        self.states["inventory:open:" + str(id)] = inst
        inst.eventname = "inventory:open:" + str(id)
        print(inst, inst.eventname)
        CONFIGS["init"]["GAME_STATES"].append(inst.eventname)
        self.nextinvid += 1
        self.inventoryinst[id] = inst
        inst.id = id
        for e in inst.slots:
            self.registerSlotInst(e)
        if inst.getId() not in [0, 1, 2, 3]:
            self.active.append(inst.id)

    def registerSlotInst(self, slot):
        id = self.nextslotid
        self.nextslotid += 1
        self.inventoryslotsinst[id] = slot
        slot.id = id


    def changeId(self, invinst, id):
        key = None
        for e in self.inventoryinst.keys():
            if self.inventoryinst[e] == invinst:
                key = e
        invinst.id = id
        del self.inventoryinst[key]
        self.inventoryinst[id] = invinst

handler = InventoryHandler()

def nonefunk(*args, **kwargs):
    pass

class Slot:
    def __init__(self, x, y, oredictallow=None, mode="a", stid=None, onupdate=nonefunk):
        self.image = None
        self.item = None
        self.x = x
        self.y = y
        self.startpos = (x, y)
        self.amount = 0
        self.id = 0
        self.stid = stid
        self.oredictallow = oredictallow
        self.update = onupdate
        self.debug = False
        if self.oredictallow != None and type(self.oredictallow) != list:
            self.oredictallow = [self.oredictallow]
        self.amountlabel = pyglet.text.Label('', font_name='Arial', font_size=10,
            x=self.x + 53, y=self.y - 3, anchor_x='left', anchor_y='top',
            color=(0, 0, 0, 255))
        self.mode = mode

    def setItem(self, item, amount=1, update=True):
        if item == None:
            self.image = None
            self.amount = 0
        else:
            if type(item) == str:
                try:
                    item = Item_file.handler.getClass(item)()
                except:
                    print("[ERROR] not arival item try to be added to an slot. itemname="+str(item))
                    traceback.print_exc()
                    return
            if self.oredictallow != None:
                flag = False
                for e in self.oredictallow:
                    if e in item.getOreDictNames():
                        flag = True
                if not flag:
                    print("[ERROR] try to add a item that is not definited to inventory", self, item.getName(), self.item.getOreDictNames() if self.item else None, self.id)
                    return False
            if not item or item.getTexturFile() == None:
                print("[ERROR] setting item -> item is None")
                return
            try:
                self.image = pyglet.sprite.Sprite(
                       texturGroups.handler.groups[item.getTexturFile()])
            except AttributeError:
                item = Item_file.handler.getClass(item)()
                self.image = pyglet.sprite.Sprite(
                    texturGroups.handler.groups[item.getTexturFile()])
            self.image.x = self.x
            self.image.y = self.y
            self.image.scale = 0.25
        self.item = item
        self.amount = amount
        if self.item: self.item.slot = self
        if item == None:
            self.amount = 0
        if update: self.update(self, item, amount)
        return True

    def draw(self):
        if self.amount == 0 and self.item:
            self.setItem(None)
        if not self.item:
            self.amount = 0
        if self.image != None:
            self.image.draw()
            self.amountlabel.x = self.x + 33
            self.amountlabel.y = self.y + 2
            self.amountlabel.text = str(self.amount)
            self.amountlabel.draw()
        if self.debug:
            print("[DEBUG/INFO] dawing slot", self.image, self.amount, self.item)

    def setPos(self, x, y, update=True):
        if update: self.update(self, self.item, self.amount)
        self.x = x
        self.y = y
        if self.image != None:
            self.image.x = x
            self.image.y = y

    def getData(self):
        return (self.item, self.amount)

    def setAmount(self, amount, update=True):
        if update: self.update(self, self.item, self.amount)
        if amount == 0:
            self.setItem(None)
        else:
            self.amount = amount

    def getDestroyHardness(self):
        if self.item == None:
            return 1
        else:
            return self.item.getToolHardness()

    def reset(self, update=True):
        self.setPos(self.startpos[0], self.startpos[1], update=update)

class Inventory:
    def __init__(self):
        self.slots = self.getSlots()
        self.id = 0
        handler.registerInst(self)
        self.eventname = None
        self.block = None
        if self.getImage():
            self.image = pyglet.sprite.Sprite(texturGroups.handler.groups[self.getImage()]) if self.getImage() != None else None
            if self.getImage() != None: self.image.x, self.image.y = self.getImagePos()
        else:
            self.image = None

    def draw(self, *args, image=True):
        if self.image and image:
            self.image.draw()
        for e in self.slots:
            e.draw()

    def getSlots(self):
        return []

    def getImage(self):
        return None

    def getOverwrites(self):
        return []

    def getDepedens(self):
        return []

    def getImagePos(self):
        return (0, 0)

    def mouseOut(self):
        return True

    def drawBefore(self):
        return []

    def drawAfter(self):
        return []

    def drawWithoutImage(self):
        return []

    def getId(self):
        return None

    def getInventoryDependence(self):
        return []