
window = None
model = None
player = None