import pickle, os, shutil, time
import Inventorys, chat, config

SAVE_VERSION = "0.0.12"
COMPATIBLE = [SAVE_VERSION, "0.0.11"]

def loadWorld(model, name):
    keys = list(model.world.keys())[:]
    for b in keys:
        model.remove_block(b)
    name = "./saves/" + name
    if not os.path.exists(name):
        print("[ERROR] path not found")
        return
    f = open(name+"/world.info", mode="rb")
    info = pickle.load(f)
    f.close()
    if info[0] not in COMPATIBLE:
        print("[ERROR] unsupported world-version")
        return
    if info[0] != SAVE_VERSION or (len(info) <= 2 or info[2] != config.CONFIGS["GAME_VERSION"]):
        nameA = name + "_backup_" + str(time.time())
        saveWorld(model, nameA)
        f = open(name + "/world.info", mode="wb")
        pickle.dump([SAVE_VERSION]+info[1]+[config.CONFIGS["GAME_VERSION"]], f)
        f.close()
    f = open(name+"/sectors.info", mode="rb")
    sectors = pickle.load(f)
    f.close()
    for sector in sectors.keys():
        print("[INFO] loading sector", sector)
        file = sectors[sector]
        f = open(file, mode="rb")
        sector_data = pickle.load(f)
        f.close()
        for e in sector_data:
            try:
                if e[0] == 0:
                    #e = e[1:]
                    model.add_block(*e[1:])
                elif e[0] == 1:
                    model.world[e[1]].setNBT(e[2], e[3])
                elif e[0] == 2:
                    model.remove_block(*e[1:])
                elif e[0] == 3:
                    inv = Inventorys.handler.inventoryinst[model.world[e[1]].getInventoryID()]
                    inv.slots[e[2]].setItem(e[3])
                    inv.slots[e[2]].amount = e[4]
                else:
                    print("[ERROR] unknown chunk-command:", e)
            except:
                print("[ERROR] during executeing command: ", e)
    f = open(name + "/inventorys.info", mode="rb")
    invinfo = pickle.load(f)
    f.close()
    for k in invinfo.keys():
        if k in Inventorys.handler.inventoryinst.keys():
            inv = Inventorys.handler.inventoryinst[k]
            for e in inv.slots:
                if e.id not in invinfo[k].keys():
                    print("[ERROR] inventory id is not filled in system")
                else:
                    if invinfo[k][e.id][0]:
                        e.amount = invinfo[k][e.id][1]
                        e.setItem(invinfo[k][e.id][0])
                    else:
                        e.setItem(None)
        else:
            print("[ERROR] loading inventory: inventory not found id=", k)

    f = open(name + "/player.info", mode="rb")
    playerdata = pickle.load(f)
    f.close()
    model.window.position = playerdata[0]
    model.window.player.mode = playerdata[1]
    model.window.rotation = playerdata[3] if len(playerdata) > 3 else (0, 0)
    chat.chat.excecute("/gamemode "+str(playerdata[2]))
    f = open(name + "/hights.info", mode="rb")
    model.high_data = pickle.load(f)
    f.close()



def saveWorld(model, name):
    model.window.worldname = name
    version = SAVE_VERSION
    info = [version, name, len(model.world), config.CONFIGS["GAME_VERSION"]]
    name = "./saves/"+name
    if os.path.exists(name):
        shutil.rmtree(name)
    os.makedirs(name)

    sectors = {}
    invregister = []
    for k in model.sectors.keys():
        positions = model.sectors[k]
        commands = []
        for p in positions:
            block = model.world[p]
            commands.append([0, p, block.getName()])
            for n in block.getNBTNames():
                commands.append([1, p, n, block.getNBT(n)])
            if block.hasInventory():
                inv = Inventorys.handler.inventoryinst[block.getInventoryID()]
                for i, s in enumerate(inv.slots):
                    commands.append([3, block.pos, i, s.item.getName() if s.item else None, s.amount])
                invregister.append(inv)
        sectors[k] = commands
    sector_info = {}
    sector_files = {}
    last_id = 0
    for k in sectors.keys():
        sector_files[last_id] = k
        last_id += 1
    os.makedirs(name+"/chunks")
    for s in sector_files.keys():
        f = open(name+"/chunks/sector_"+str(s)+".chunk", mode="wb")
        pickle.dump(sectors[sector_files[s]], f)
        f.close()
        sector_info[sector_files[s]] = name+"/chunks/sector_"+str(s)+".chunk"
    f = open(name+"/sectors.info", mode="wb")
    pickle.dump(sector_info, f)
    f.close()
    info.append(last_id)
    invdata = {}
    for e in Inventorys.handler.inventoryinst.keys():
        if not Inventorys.handler.inventoryinst[e] in invregister:
            invdata[e] = {}
            for s in Inventorys.handler.inventoryinst[e].slots:
                invdata[e][s.id] = [s.item.getName() if s.item else None, s.amount]
            invregister.append(Inventorys.handler.inventoryinst[e])
    f = open(name + "/inventorys.info", mode="wb")
    pickle.dump(invdata, f)
    f.close()
    f = open(name + "/world.info", mode="wb")
    pickle.dump(info, f)
    f.close()
    playerdata = [model.window.position, model.window.player.mode, model.window.player.gamemode, model.window.rotation]
    f = open(name + "/player.info", mode="wb")
    pickle.dump(playerdata, f)
    f.close()
    f = open(name+"/hights.info", mode="wb")
    pickle.dump(model.high_data, f)
    f.close()
    f = open("./assets/textures/misc/delight.png", mode="rb")
    imgdata = f.read()
    f.close()
    f = open(name+"/logo.png", mode="wb")
    f.write(imgdata)
    f.close()

def savePlayerData(worldname, window):
    name = "./saves/"+worldname
    playerdata = [window.position, window.player.mode, window.player.gamemode, window.rotation]
    f = open(name + "/player.info", mode="wb")
    pickle.dump(playerdata, f)
    f.close()

def saveCommandToTMP(worldname, commands):
    name = "./saves/" + worldname
    f = open(name + "/sectors.info", mode="rb")
    sectors = pickle.load(f)
    f.close()
    f = open(name + "/world.info", mode="rb")
    info = pickle.load(f)
    f.close()
    _name = name + "/chunks/sector_" + str(info[3]) + ".chunk"
    x, y = 0, 0
    while (x, y) in sectors:
        x += 1
    sectors[(x, y)] = _name
    info[3] += 1
    f = open(name + "/world.info", mode="wb")
    pickle.dump(info, f)
    f.close()
    f = open(name + "/sectors.info", mode="wb")
    pickle.dump(sectors, f)
    f.close()
    file = _name
    data = commands
    f = open(file, mode="wb")
    pickle.dump(data, f)
    f.close()

def saveToChunk(chunk, worldname, command): #warning! not good saving (only append command)
    if type(command) == list:
        for e in command:
            saveToChunk(chunk, worldname, e)
        return
    name = "./saves/"+worldname
    f = open(name+"/sectors.info", mode="rb")
    sectors = pickle.load(f)
    f.close()
    if not chunk in sectors:
        f = open(name+"/world.info", mode="rb")
        info = pickle.load(f)
        f.close()
        _name = name+"/chunks/sector_"+str(info[3])+".chunk"
        info[4] += 1
        f = open(name + "/world.info", mode="wb")
        pickle.dump(info, f)
        f.close()
        f = open(_name, mode="wb")
        pickle.dump([], f)
        f.close()
        sectors[chunk] = _name
        f = open(name + "/sectors.info", mode="wb")
        pickle.dump(sectors, f)
        f.close()
    file = sectors[chunk]
    f = open(file, mode="rb")
    data = pickle.load(f)
    f.close()
    data.append(command)
    f = open(file, mode="wb")
    pickle.dump(data, f)
    f.close()
