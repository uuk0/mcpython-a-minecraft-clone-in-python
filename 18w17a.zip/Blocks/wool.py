from .Block import *

for i in range(0, 16):
    class Wool(Block):
        id = 0

        def getTex(self):
            return tex_coords((15, self.id), (15, self.id), (15, self.id))

        def getName(self):
            return "minecraft:wool_"+str(15-self.id)

        def getDestroyGroups(self):
            return [destroyGroups.SHEER]

    Wool.id = i
    handler.register(Wool)
