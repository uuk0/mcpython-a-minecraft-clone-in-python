from .Item import *
from oredictnames import OreDict


class Dye0(Item):
    def getName(self):
        return "minecraft:ash"

    def getTexturFile(self):
        return "./assets/textures/items/ash.png"

    def hasBlock(self):
        return False

    def getOreDictNames(self):
        return [OreDict.DYE, OreDict.WHITE_DYE]

handler.register(Dye0)


class Dye1(Item):
    def getName(self):
        return "minecraft:bone_meel"

    def getTexturFile(self):
        return "./assets/textures/items/bonemeel.png"

    def hasBlock(self):
        return False

    def getOreDictNames(self):
        return [OreDict.DYE, OreDict.WHITE_DYE]

handler.register(Dye1)

class Dye2(Item):
    def getName(self):
        return "minecraft:brown_dye"

    def getTexturFile(self):
        return "./assets/textures/items/brown_dye.png"

    def hasBlock(self):
        return False

    def getOreDictNames(self):
        return [OreDict.DYE, OreDict.BROWN_DYE]

handler.register(Dye2)

class Dye3(Item):
    def getName(self):
        return "minecraft:green_dye"

    def getTexturFile(self):
        return "./assets/textures/items/green_dye.png"

    def hasBlock(self):
        return False

    def getOreDictNames(self):
        return [OreDict.DYE, OreDict.GREEN_DYE]

handler.register(Dye3)

class Dye4(Item):
    def getName(self):
        return "minecraft:grey_dye"

    def getTexturFile(self):
        return "./assets/textures/items/grey_dye.png"

    def hasBlock(self):
        return False

    def getOreDictNames(self):
        return [OreDict.DYE, OreDict.GREY_DYE]

handler.register(Dye4)

class Dye5(Item):
    def getName(self):
        return "minecraft:ink_sack"

    def getTexturFile(self):
        return "./assets/textures/items/ink_sack.png"

    def hasBlock(self):
        return False

    def getOreDictNames(self):
        return [OreDict.DYE, OreDict.BLACK_DYE]

handler.register(Dye5)

class Dye6(Item):
    def getName(self):
        return "minecraft:lapis"

    def getTexturFile(self):
        return "./assets/textures/items/lapis.png"

    def hasBlock(self):
        return False

    def getOreDictNames(self):
        return [OreDict.DYE, OreDict.BLUE_DYE]

handler.register(Dye6)