import EventHandler, Blocks, Item, crafting
import globals as G
from mathhelper import *

@EventHandler.eventhandler.event
def on_key_press(eventname, button, mods):
    block = None
    pp = normalize(G.window.position)
    for e in BLOCKS:
        if e.pos == (pp[0], pp[1]-1, pp[2]): block = e
        if e.pos == (pp[0], pp[1]-2, pp[2]): block = e
        if e.pos == (pp[0], pp[1], pp[2]): block = e
    if not block: return 
    if button == 32: #jump
        if block.getUpPosition():
            G.window.position = block.getUpPosition()
            G.player.position = block.getUpPosition()
    elif button == 65505: #sneak
        if block.getDownPosition():
            G.window.position = block.getDownPosition()
            G.player.position = block.getDownPosition()

BLOCKS = []

class Elevator(Blocks.Block):
    def on_creat(self, *args, **kwargs):
        BLOCKS.append(self)
    
    def getTex(self):
        return tex_coords((9, 4),(9, 4),(9, 4))

    def getName(self):
        return "elevator:elevator"

    def getDestroyGroups(self):
        return [destroyGroups.PIKAXE]

    def getUpPosition(self):
        for i in range(self.pos[1]+1, 255):
            if (self.pos[0], i, self.pos[2]) in G.model.world and G.model.world[(self.pos[0], i, self.pos[2])].getName() == "elevator:elevator": return (self.pos[0], i+1, self.pos[2])
        return None

    def getDownPosition(self):
        for i in range(0, self.pos[1]):
            if (self.pos[0], i, self.pos[2]) in G.model.world and G.model.world[(self.pos[0], i, self.pos[2])].getName() == "elevator:elevator": return (self.pos[0], i+2, self.pos[2])
        return None

Blocks.handler.register(Elevator)

class Elevator(Item.Item):
    def getName(self):
        return "elevator:elevator"

    def getTexturFile(self):
        return "./assets/textures/items/apple.png"

Item.handler.register(Elevator)

def init():
    pass

crafting.Recipi(crafting.Grid.crafting_3x3, ["minecraft:iron"]*4+["minecraft:redstone"]+ ["minecraft:iron"]*4, ["elevator:elevator"], [1]*9, [1])

