from WorldHandler import *
from moduls import *
from constans import *

def initgame(window, creat=True):
    #configurate opengl
    glClearColor(0.5, 0.69, 1.0, 1)
    glEnable(GL_CULL_FACE)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
    glEnable(GL_FOG)
    glFogfv(GL_FOG_COLOR, (GLfloat * 4)(0.5, 0.69, 1.0, 1))
    glHint(GL_FOG_HINT, GL_DONT_CARE)
    glFogi(GL_FOG_MODE, GL_LINEAR)
    glFogf(GL_FOG_START, 20.0)
    glFogf(GL_FOG_END, 60.0)
    if creat:
        print("[INFO] preparing spawn area...")
        print("[INFO] generatign high-data")
        generateHighData(window.model)
        print("[INFO] generating base-chunk")
        l = generateChunkA(0, 0, (16, 16), window.model)
        for e in l:
            window.model.add_block(*e)
        window.state = "game"
        y = 0
        while (0, y, 0) in window.model.world:
            y += 1
        window.position = window.startpos = (0, y+1, 0)
        print("[INFO] finsih!")
    
