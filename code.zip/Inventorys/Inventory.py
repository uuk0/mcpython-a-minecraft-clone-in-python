from moduls import *
import Item as Item_file

class InventoryHandler:
    def __init__(self):
        self.inventorys = []
        self.shown = []
        self.inventoryinst = {}
        self.inventoryslotsinst = {}
        self.window = None
        self.nextslotid = 0
        self.nextinvid = 0
        self.v1 = 0

    def register(self, klass):
        self.inventorys.append(klass)

    def show(self, id):
        if id not in self.shown:
            self.shown.append(id)
            if self.inventoryinst[id].mouseOut():
                self.v1 += 1
                if self.window: self.window.set_exclusive_mouse(False)

    def hide(self, id):
        if id in self.shown:
            self.shown.remove(id)
            if self.inventoryinst[id].mouseOut():
                self.v1 -= 1
                if self.v1 == 0 and self.window:
                    self.window.set_exclusive_mouse(True)

    def draw(self):
        iitems = []
        flag = [False] * 3
        for e in self.shown:
            e = self.inventoryinst[e]
            if e.getId() == 4:
                flag = [True] * 3
                iitems.append(e)
        for e in iitems:
            e.draw()
        if 1 in self.shown or flag[1]:
            for i in range(1, 4):
                self.inventoryinst[i].draw(image=not flag[i-1])
            flag[0] = True
        if 0 in self.shown or flag:
            self.inventoryinst[0].draw(image=1 not in self.shown or not flag[0])


    def registerInst(self, inst):
        print("registering inventoryInst: "+str(inst))
        id = self.nextinvid
        self.nextinvid += 1
        self.inventoryinst[id] = inst
        inst.id = id
        for e in inst.slots:
            self.registerSlotInst(e)

    def registerSlotInst(self, slot):
        id = self.nextslotid
        self.nextslotid += 1
        self.inventoryslotsinst[id] = slot
        slot.id = id

handler = InventoryHandler()

class Slot:
    def __init__(self, x, y, oredictallow=None, mode="a", stid=None):
        self.image = None
        self.item = None
        self.x = x
        self.y = y
        self.amount = 0
        self.id = 0
        self.stid = stid
        self.oredictallow = oredictallow
        if self.oredictallow != None and type(self.oredictallow) != list:
            self.oredictallow = [self.oredictallow]
        self.amountlabel = pyglet.text.Label('', font_name='Arial', font_size=10,
            x=self.x + 53, y=self.y - 3, anchor_x='left', anchor_y='top',
            color=(0, 0, 0, 255))
        self.mode = mode

    def setItem(self, item, amount=1):
        if item == None:
            self.image = None
            self.amount = 0
        else:
            if type(item) == str:
                item = Item_file.handler.getClass(item)()
            if self.oredictallow != None:
                flag = False
                for e in self.oredictallow:
                    if e in item.getOreDictNames():
                        flag = True
                if not flag:
                    print("[ERROR] try to add a item that is not definited to inventory", self, item.getName(), self.getOreDictNames(), self.id)
                    return False
            self.image = pyglet.sprite.Sprite(
                        pyglet.image.load(item.getTexturFile()))
            self.image.x = self.x
            self.image.y = self.y
            self.image.scale = 0.25
        self.item = item
        self.amount = amount
        if item == None:
            self.amount = 0
        return True

    def draw(self):
        if self.amount == 0 and self.item:
            self.setItem(None)
        if not self.item:
            self.amount = 0
        if self.image != None:
            self.image.draw()
            self.amountlabel.x = self.x + 33
            self.amountlabel.y = self.y + 2
            self.amountlabel.text = str(self.amount)
            self.amountlabel.draw()

    def setPos(self, x, y):
        self.x = x
        self.y = y
        if self.image != None:
            self.image.x = x
            self.image.y = y

    def getData(self):
        return (self.item, self.amount)

    def setAmount(self, amount):
        if amount == 0:
            self.setItem(None)
        else:
            self.amount = amount

    def getDestroyHardness(self):
        if self.item == None:
            return 1
        else:
            return self.item.getToolHardness()

class Inventory:
    def __init__(self):
        self.slots = self.getSlots()
        self.id = 0
        handler.registerInst(self)
        if self.getImage():
            self.image = pyglet.sprite.Sprite(pyglet.image.load(self.getImage()))
            self.image.x, self.image.y = self.getImagePos()
        else:
            self.image = None

    def draw(self, image=True):
        if self.image and image:
            self.image.draw()
        for e in self.slots:
            e.draw()

    def getSlots(self):
        return []

    def getImage(self):
        return ""

    def getOverwrites(self):
        return []

    def getDepedens(self):
        return []

    def getImagePos(self):
        return (0, 0)

    def mouseOut(self):
        return True

    def drawBefore(self):
        return []

    def drawAfter(self):
        return []

    def drawWithoutImage(self):
        return []

    def getId(self):
        return None