from .Inventory import *
from oredictnames import *


class craftingtable(Inventory):
    def getId(self):
        return 4

    def getSlots(self):
        return [Slot(0, 0), Slot(0, 0), Slot(0, 0),
                Slot(0, 0), Slot(0, 0), Slot(0, 0),
                Slot(0, 0), Slot(0, 0), Slot(0, 0),
                Slot(0, 0, mode="o")]

    def getImage(self):
        for e in self.slots:
            print(e.id)
        return "./texturs/crafting_table.png"

    def getDepedens(self):
        return [0, 1]

    def getImagePos(self):
        return (180, 10)


handler.register(craftingtable)