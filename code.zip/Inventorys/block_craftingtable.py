from .Inventory import *
from oredictnames import *


class craftingtable(Inventory):
    def getId(self):
        return 4

    def getSlots(self):
        return []

    def getImage(self):
        return "./texturs/crafting_table.png"

    def getDepedens(self):
        return [0, 1]


handler.register(craftingtable)