from .Inventory import *
from oredictnames import *
import crafting


class furnes(Inventory):
    def getId(self):
        return 4

    def getSlots(self):
        s =    [Slot(0, 0), Slot(0, 0),
                Slot(0, 0, mode="o", stid="minecraft:slot:furnes:out")]
        for e in s:
            e.setItem("stone")
        return s

    def getImage(self):
        for e in self.slots:
            print(e, e.id)
        return "./texturs/furnace.png"

    def getDepedens(self):
        return [0, 1]

    def getImagePos(self):
        return (180, 10)



handler.register(furnes)