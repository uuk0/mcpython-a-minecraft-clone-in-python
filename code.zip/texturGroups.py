from moduls import *

class handler:
    def __init__(self):
        self.files = []
        self.groups = {}

    def getGroup(self, file):
        if not file in self.files:
            self.files.append(file)
            self.groups[file] = TextureGroup(image.load(file).get_texture())
        return self.groups[file]


handler = handler()
