import pickle, os
import Inventorys

def loadWorld(model, name):
    name = str(name)
    if not os.path.exists("./saves/"+name+".mcworld"):
        print("[ERROR] during loading world: world not found named "+name)
        return
    f = open("./saves/"+name+".mcworld", mode="rb")
    data = pickle.load(f)
    f.close()
    for e in data:
        if e[0] == 0: #addblock
            model.add_block(*e[1:])
        elif e[0] == 1: #setnbt
            model.world[e[1]].setNBT(e[2], e[3])
        elif e[0] == 2: #setinventoryitem
            block = model.world[e[1]]
            inv = block.getInventorys()
            inv[int(e[2])].slots[int(e[3])].setItem(e[4], amount=e[5])
        elif e[0] == 3: #setplayerinventoryitem
            Inventorys.handler.inventoryslotsinst[e[1]].slots[e[2]].setItem(e[3], amount=e[4])


def saveWorld(model, name):
    data = []
    for e in model.world.keys():
        block = model.world[e]
        data.append([0, block.pos, block.getName()])
        for e in block.getNBTNames():
            nbtdata = block.getNBT(e)
            data.append([1, block.pos, e, nbtdata])
        for i1, inv in enumerate(block.getInventorys()):
            for i2, s in enumerate(inv.slots):
                data.append([2, block.pos, i1, i2, s.item.getName(), s.amount])
    for i1, e in enumerate(Inventorys.handler.inventoryslotsinst):
        try:
            if e.getId() in [0, 1, 2, 3]:
                for i2, s in enumerate(e.slots):
                    data.append([3, i1, i2, s.item.getName(), s.amount])
        except:
            print("[WARNING] can't save inventory id="+str(i1))
    name = str(name)
    f = open("./saves/"+name+".mcworld", mode="wb")
    pickle.dump(data, f)
    f.close()