print("[INFO] definiting Window-class")

from Model import *

import Block

from Block import Blocks

from chat import *

from TickHandler import handler as tickhandler

from player import *

import Item

class Window(pyglet.window.Window):

    def __init__(self, *args, **kwargs):
        self.WorldName = ""
        super(Window, self).__init__(*args, **kwargs)
        self.state = ""

        # Whether or not the window exclusively captures the mouse.
        self.exclusive = False

        # When flying gravity has no effect and speed is increased.
        self.flying = False

        # Strafing is moving lateral to the direction you are facing,
        # e.g. moving to the left or right while continuing to face forward.
        #
        # First element is -1 when moving forward, 1 when moving back, and 0
        # otherwise. The second element is -1 when moving left, 1 when moving
        # right, and 0 otherwise.
        self.strafe = [0, 0]

        # Current (x, y, z) position in the world, specified with floats. Note
        # that, perhaps unlike in math class, the y-axis is the vertical axis.
        self.position = self.startpos = (0, 0, 0)

        # First element is rotation of the player in the x-z plane (ground
        # plane) measured from the z-axis down. The second is the rotation
        # angle from the ground plane up. Rotation is in degrees.
        #
        # The vertical plane rotation ranges from -90 (looking straight down) to
        # 90 (looking straight up). The horizontal rotation range is unbounded.
        self.rotation = (0, 0)

        # Which sector the player is currently in.
        self.sector = None

        # The crosshairs at the center of the screen.
        self.reticle = None

        # Velocity in the y (upward) direction.
        self.dy = 0

        # A list of blocks the player can place. Hit num keys to cycle.
        #self.inventory = [Blocks.Grass, Blocks.Sand, Blocks.Brick, Blocks.Stone, Blocks.Dirt, Blocks.CobbelStone]
        self.hotbarelement = 0

        # The current block the user can place. Hit num keys to cycle.
        #self.block = self.inventory[0]

        # Convenience list of num keys.
        self.num_keys = [
            key._1, key._2, key._3, key._4, key._5,
            key._6, key._7, key._8, key._9, key._0]

        # Instance of the model that handles the world.
        self.model = Model(self)

        # The label that is displayed in the top left of the canvas.
        self.label = pyglet.text.Label('', font_name='Arial', font_size=18,
            x=10, y=self.height - 10, anchor_x='left', anchor_y='top',
            color=(0, 0, 0, 255))

        self.label2 = pyglet.text.Label('', font_name='Arial', font_size=18,
            x=10, y=self.height - 30, anchor_x='left', anchor_y='top',
            color=(0, 0, 0, 255))

        self.chatlabel = pyglet.text.Label('', font_name='Arial', font_size=18,
            x=30, y=50, anchor_x='left', anchor_y='top',
            color=(0, 0, 0, 255))

        self.player = player(self)

        #time to manage destroy-system
        self.mouseclicktime = 0
        self.isclicked = False
        self.clickingblock = None
        self.clickstarttime = 0

        #mousepos for playerinventory
        self.mousepos = (0, 0)

        #helper vars for braking system
        self.braking_start = None

        # This call schedules the `update()` method to be called
        # TICKS_PER_SEC. This is the main game event loop.
        pyglet.clock.schedule_interval(self.update, 1.0 / TICKS_PER_SEC)
        pyglet.clock.schedule_interval(tickhandler._run, 0.5)

        self.keyEvent = "window"
        self.last_generate = 1000

    def set_exclusive_mouse(self, exclusive):
        """ If `exclusive` is True, the game will capture the mouse, if False
        the game will ignore the mouse.

        """
        super(Window, self).set_exclusive_mouse(exclusive)
        self.exclusive = exclusive

    def get_sight_vector(self):
        """ Returns the current line of sight vector indicating the direction
        the player is looking.

        """
        x, y = self.rotation
        # y ranges from -90 to 90, or -pi/2 to pi/2, so m ranges from 0 to 1 and
        # is 1 when looking ahead parallel to the ground and 0 when looking
        # straight up or down.
        m = math.cos(math.radians(y))
        # dy ranges from -1 to 1 and is -1 when looking straight down and 1 when
        # looking straight up.
        dy = math.sin(math.radians(y))
        dx = math.cos(math.radians(x - 90)) * m
        dz = math.sin(math.radians(x - 90)) * m
        return (dx, dy, dz)

    def get_motion_vector(self):
        """ Returns the current motion vector indicating the velocity of the
        player.

        Returns
        -------
        vector : tuple of len 3
            Tuple containing the velocity in x, y, and z respectively.

        """
        if any(self.strafe):
            x, y = self.rotation
            strafe = math.degrees(math.atan2(*self.strafe))
            y_angle = math.radians(y)
            x_angle = math.radians(x + strafe)
            if self.flying:
                m = math.cos(y_angle)
                dy = math.sin(y_angle)
                if self.strafe[1]:
                    # Moving left or right.
                    dy = 0.0
                    m = 1
                if self.strafe[0] > 0:
                    # Moving backwards.
                    dy *= -1
                # When you are flying up or down, you have less left and right
                # motion.
                dx = math.cos(x_angle) * m
                dz = math.sin(x_angle) * m
            else:
                dy = 0.0
                dx = math.cos(x_angle)
                dz = math.sin(x_angle)
        else:
            dy = 0.0
            dx = 0.0
            dz = 0.0
        return (dx, dy, dz)

    def update(self, dt):
        """ This method is scheduled to be called repeatedly by the pyglet
        clock.

        Parameters
        ----------
        dt : float
            The change in time since the last call.

        """
        if dt > 10:
            print("[ERROR] update-zyklus do need more time then normal ("+str(dt)+" secounds)")
        self.model.process_queue()
        sector = sectorize(self.position)
        if sector != self.sector:
            self.model.change_sectors(self.sector, sector)
            if self.sector is None:
                self.model.process_entire_queue()
            self.sector = sector
        m = 8
        dt = min(dt, 0.2)
        for _ in xrange(m):
            self._update(dt / m)

        if self.position[1] < -100:
            self.kill("player fell out of the world")
        if normalize(self.position) in self.model.world:
            self.player.harts -= 0.5

        self.player.update()

        if self.braking_start != None:
            if self.player.gamemode == 1:
                vector = self.get_sight_vector()
                block, previous = self.model.hit_test(self.position, vector)
                b = self.model.world[block]
                self.model.remove_block(b.pos)
                self.braking_start = None
                return
            d = time.time() - self.braking_start
            vector = self.get_sight_vector()
            block, previous = self.model.hit_test(self.position, vector)
            i = self.player.inventory.hotbar.slots[self.hotbarelement].item
            if not block: return
            b = self.model.world[block]
            id = i.getDestroyMultiplierWithTool(b) if i else 1
            if d / id > b.getHardness() / 5 and b.isBreakAbleWithItem(i) and b.isBreakAble():
                self.player.addToFreePlace(b.getDrop(i), b.getDropAmount(i))
                self.model.remove_block(b.pos)
                self.braking_start = time.time()
            elif not b.isBreakAbleWithItem(i) or not b.isBreakAble():
                self.braking_start = time.time()

    def _update(self, dt):
        """ Private implementation of the `update()` method. This is where most
        of the motion logic lives, along with gravity and collision detection.

        Parameters
        ----------
        dt : float
            The change in time since the last call.

        """
        # walking
        speed = FLYING_SPEED if self.flying else WALKING_SPEED
        d = dt * speed # distance covered this tick.
        dx, dy, dz = self.get_motion_vector()
        # New position in space, before accounting for gravity.
        dx, dy, dz = dx * d, dy * d, dz * d
        # gravity
        if not self.flying:
            # Update your vertical speed: if you are falling, speed up until you
            # hit terminal velocity; if you are jumping, slow down until you
            # start falling.
            self.dy -= dt * GRAVITY
            self.dy = max(self.dy, -TERMINAL_VELOCITY)
            dy += self.dy * dt
        # collisions
        x, y, z = self.position
        if self.player.gamemode != 3:
            x, y, z = self.collide((x + dx, y + dy, z + dz), PLAYER_HEIGHT)
        else:
            x, y, z = x + dx, y + dy, z + dz
        self.position = (x, y, z)

    def collide(self, position, height):
        """ Checks to see if the player at the given `position` and `height`
        is colliding with any blocks in the world.

        Parameters
        ----------
        position : tuple of len 3
            The (x, y, z) position to check for collisions at.
        height : int or float
            The height of the player.

        Returns
        -------
        position : tuple of len 3
            The new position of the player taking into account collisions.

        """
        # How much overlap with a dimension of a surrounding block you need to
        # have to count as a collision. If 0, touching terrain at all counts as
        # a collision. If .49, you sink into the ground, as if walking through
        # tall grass. If >= .5, you'll fall through the ground.
        #pad = 0.25
        pad = 0
        p = list(position)
        np = normalize(position)
        for face in FACES:  # check all surrounding blocks
            for i in xrange(3):  # check each dimension independently
                if not face[i]:
                    continue
                # How much overlap you have with this dimension.
                d = (p[i] - np[i]) * face[i]
                if d < pad:
                    continue
                for dy in xrange(height):  # check each height
                    op = list(np)
                    op[1] -= dy
                    op[i] += face[i]
                    if tuple(op) not in self.model.world or not self.model.world[tuple(op)].hasHitbox():
                        continue
                    p[i] -= (d - pad) * face[i]
                    if face == (0, -1, 0) or face == (0, 1, 0):
                        # You are colliding with the ground or ceiling, so stop
                        # falling / rising.
                        self.dy = 0
                    break
        return tuple(p)

    def on_mouse_press(self, x, y, button, modifiers):
        """ Called when a mouse button is pressed. See pyglet docs for button
        amd modifier mappings.

        Parameters
        ----------
        x, y : int
            The coordinates of the mouse click. Always center of the screen if
            the mouse is captured.
        button : int
            Number representing mouse button that was clicked. 1 = left button,
            4 = right button.
        modifiers : int
            Number representing any modifying keys that were
            pressed when the
            mouse button was clicked.

        """
        if self.player.mode == 2 or self.player.mode == 3:
            self.player.inventory.on_mouse_press(x, y, button, modifiers)
            return
        if self.keyEvent == "chat" and chat.opened:
            return
        if self.exclusive and self.player.gamemode != 3 and self.player.gamemode != 2:
            vector = self.get_sight_vector()
            block, previous = self.model.hit_test(self.position, vector)
            if (button == mouse.RIGHT) or \
                    ((button == mouse.LEFT) and (modifiers & key.MOD_CTRL)):
                if block and self.model.world[block].hasInventory():
                    invhandler.shown.append(self.model.world[block].getInventoryID())
                    for e in range(1, 4):
                        invhandler.show(e)
                    print("showing inventory")
                elif self.player.inventory.hotbar.slots[self.hotbarelement].item:
                    slot = self.player.inventory.hotbar.slots[self.hotbarelement]
                    if slot.item.hasBlock() and block in self.model.world and not self.model.world[block].hasInventory():
                        self.model.add_block(previous, slot.item.getName())
                        if self.player.gamemode == 0:
                            if slot.amount == 1:
                                slot.setItem(None)
                            else:
                                slot.amount -= 1
                    else:
                        slot.item.on_right_click(block, previous, button, modifiers)
            elif button == pyglet.window.mouse.LEFT:
                if block:
                    if (not self.player.inventory.hotbar.slots[self.hotbarelement].item) or self.player.inventory.hotbar.slots[self.hotbarelement].item.canDestroyBlock(block, button, modifiers) and self.model.world[block].isBreakAble():
                        self.braking_start = time.time()
                    else:
                        self.player.inventory.hotbar.slots[self.hotbarelement].item.on_left_click(self, block, previous, button, modifiers)
            elif button == pyglet.window.mouse.MIDDLE:
                if self.player.gamemode == 1:
                    item = Item.handler.getClass(self.model.world[block].getItemName())()
                    item.blocknbt = self.model.world[block].getAllItemNBT()
                    self.player.addToFreePlace(item)
        elif self.player.mode != 2 and self.player.mode != 3:
            self.set_exclusive_mouse(True)

    def on_mouse_drag(self, x, y, dx, dy, buttons, modifiers):
        if self.player.mode == 2 or self.player.mode == 3:
            self.player.inventory.on_mouse_drag(x, y, dx, dy, buttons, modifiers)

    def on_mouse_release(self, x, y, button, modifiers):
        if self.player.mode == 2 or self.player.mode == 3:
            self.player.inventory.on_mouse_release(x, y, button, modifiers)
        self.braking_start = None


    def on_mouse_motion(self, x, y, dx, dy):
        """ Called when the player moves the mouse.

        Parameters
        ----------
        x, y : int
            The coordinates of the mouse click. Always center of the screen if
            the mouse is captured.
        dx, dy : float
            The movement of the mouse.

        """
        if self.player.inventory.moving_slot:
            if self.player.inventory.moving_slot:
                self.player.inventory.moving_slot.setPos(x + dx, y + dy)
            return
        self.mousepos = (x, y)
        if self.keyEvent == "chat" and chat.opened:
            return
        if self.exclusive:
            m = 0.15
            x, y = self.rotation
            x, y = x + dx * m, y + dy * m
            y = max(-90, min(90, y))
            self.rotation = (x, y)

    def on_key_press(self, symbol, modifiers):
        """ Called when the player presses a key. See pyglet docs for key
        mappings.

        Parameters
        ----------
        symbol : int
            Number representing the key that was pressed.
        modifiers : int
            Number representing any modifying keys that were pressed.

        """
        if self.keyEvent == "chat" and chat.opened:
            if symbol == key.ESCAPE:
                chat.opened = False
                chat.text = ""
            else:
                chat.addKey(symbol, modifiers)
            return
        if symbol == key.W:
            self.strafe[0] -= 1
        elif symbol == key.S:
            self.strafe[0] += 1
        elif symbol == key.A:
            self.strafe[1] -= 1
        elif symbol == key.D:
            self.strafe[1] += 1
        elif symbol == key.SPACE:
            if self.dy == 0:
                self.dy = JUMP_SPEED
        elif symbol == key.ESCAPE:
            if self.player.mode == 1:
                self.set_exclusive_mouse(False)
            else:
                if self.player.inventory.moving_slot and self.player.inventory.moving_start:
                    self.player.inventory.moving_slot.setPos(*self.player.inventory.moving_start)
                    self.player.inventory.moving_slot = None
                self.player.mode = 1
                self.set_exclusive_mouse(True)
                for i in range(0, 4):
                    invhandler.hide(i)
                for e in invhandler.shown:
                    if invhandler.inventoryinst[e].getId() == 4:
                        invhandler.hide(e)
                invhandler.show(0)
        elif symbol == key.TAB and self.player.gamemode == 1:
            self.flying = not self.flying
        elif symbol in self.num_keys:
            index = self.num_keys.index(symbol)
            self.hotbarelement = index
            if self.braking_start: self.braking_start = time.time()
        elif symbol == key.T:
            chat.open()
        elif symbol == key.E:
            if self.player.mode == 1:
                self.player.mode = 2 if self.player.gamemode == 0 or self.player.gamemode == 2 else 3
                self.set_exclusive_mouse(False)
                invhandler.show(1)
                invhandler.show(2)
                invhandler.show(3)
            elif self.player.mode == 2 or self.player.mode == 3:
                self.player.mode = 1
                self.set_exclusive_mouse(True)
                invhandler.hide(1)
                invhandler.hide(2)
                invhandler.hide(3)
        elif symbol == key.LSHIFT and (self.player.mode == 2 or self.player.mode == 3):
            self.player.inventory.on_shift()

    def on_key_release(self, symbol, modifiers):
        """ Called when the player releases a key. See pyglet docs for key
        mappings.

        Parameters
        ----------
        symbol : int
            Number representing the key that was pressed.
        modifiers : int
            Number representing any modifying keys that were pressed.

        """
        if self.keyEvent == "chat" and chat.opened:
            if self.strafe[0] != 0:
                self.strafe[0] = 0
            if self.strafe[1] != 0:
                self.strafe[1] = 0
            return
        if symbol == key.W:
            self.strafe[0] += 1
        elif symbol == key.S:
            self.strafe[0] -= 1
        elif symbol == key.A:
            self.strafe[1] += 1
        elif symbol == key.D:
            self.strafe[1] -= 1

    def on_resize(self, width, height):
        """ Called when the window is resized to a new `width` and `height`.

        """
        # label
        self.label.y = height - 10
        # reticle
        if self.reticle:
            self.reticle.delete()
        x, y = self.width // 2, self.height // 2
        n = 10
        self.reticle = pyglet.graphics.vertex_list(4,
            ('v2i', (x - n, y, x + n, y, x, y - n, x, y + n))
        )

    def set_2d(self):
        """ Configure OpenGL to draw in 2d.

        """
        width, height = self.get_size()
        glDisable(GL_DEPTH_TEST)
        glViewport(0, 0, width, height)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        glOrtho(0, width, 0, height, -1, 1)
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()

    def set_3d(self):
        """ Configure OpenGL to draw in 3d.

        """
        width, height = self.get_size()
        glEnable(GL_DEPTH_TEST)
        glViewport(0, 0, width, height)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(65.0, width / float(height), 0.1, 60.0)
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()
        x, y = self.rotation
        glRotatef(x, 0, 1, 0)
        glRotatef(-y, math.cos(math.radians(x)), 0, math.sin(math.radians(x)))
        x, y, z = self.position
        glTranslatef(-x, -y, -z)

    def on_draw(self):
        """ Called by pyglet to draw the canvas.

        """
        self.clear()
        self.set_3d()
        glColor3d(1, 1, 1)
        self.model.batch.draw()
        self.draw_focused_block()
        self.set_2d()
        self.draw_label()
        self.draw_reticle()
        invhandler.draw()
        chat.draw()

    def draw_focused_block(self):
        """ Draw black edges around the block that is currently under the
        crosshairs.

        """
        vector = self.get_sight_vector()
        block = self.model.hit_test(self.position, vector)[0]
        if block:
            x, y, z = block
            vertex_data = cube_vertices(x, y, z, 0.51)
            glColor3d(0, 0, 0)
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)
            pyglet.graphics.draw(24, GL_QUADS, ('v3f/static', vertex_data))
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)

    def draw_label(self):
        """ Draw the label in the top left of the screen.

        """
        x, y, z = self.position
        self.label.text = '%02d (%.2f, %.2f, %.2f) %d / %d' % (
            pyglet.clock.get_fps(), x, y, z,
            len(self.model._shown), len(self.model.world))
        self.label.draw()
        vector = self.get_sight_vector()
        block = self.model.hit_test(self.position, vector)[0]
        if block:
            self.label2.text = "You are looking at "+self.model.world[block].getVisualName()
            self.label2.draw()

    def draw_reticle(self):
        """ Draw the crosshairs in the center of the screen.

        """
        glColor3d(0, 0, 0)
        self.reticle.draw(GL_LINES)

    def kill(self, msg):
        y = 4
        while (0, y, 0) in self.model.world:
            y += 1
        self.position = self.startpos = (0, y+1, 0)
        chat.printIn(msg)
        self.player.harts = 10

    def openInventory(self, id):
        invhandler.show(id)

    def on_mouse_scroll(self, x, y, scroll_x, scroll_y):
        if 2 not in invhandler.shown:
            if self.hotbarelement + scroll_x > 8:
                if self.hotbarelement + 1 > 1:
                    scroll_x -= 1
                    self.hotbarelement = 0
                while self.hotbarelement + scroll_x > 8:
                    scroll_x -= 9
            self.hotbarelement += scroll_x
        if self.braking_start: self.braking_start = time.time()
