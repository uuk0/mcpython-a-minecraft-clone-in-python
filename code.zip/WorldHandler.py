import pickle, random
import Blocks, Item

xrange = range

def generateWorld(self):
    # generate the hills randomly
    print("[INFO] starting worldgernerator")
    print("[WORLDGENERATOR/INFO] generating hills")
    n = 80  # 1/2 width and height of world
    s = 1  # step size
    y = 0  # initial y height
    o = n - 10
    for i in xrange(120):
        #print(i)
        a = random.randint(-o, o)  # x position of the hill
        b = random.randint(-o, o)  # z position of the hill
        c = -2  # base of the hill
        h = random.randint(1, 6)  # height of the hill
        s = random.randint(4, 8)  # 2 * s is the side length of the hill
        d = 1  # how quickly to taper off the hills
        t = random.choice([Blocks.Sand, Blocks.Brick, Blocks.Stone, Blocks.CobbelStone,
                           Blocks.wood_plank_1, Blocks.wood_plank_2, Blocks.wood_plank_3,
                           Blocks.Sandstone])
        for y in xrange(c, c + h):
            for x in xrange(a - s, a + s + 1):
                for z in xrange(b - s, b + s + 1):
                    if (x - a) ** 2 + (z - b) ** 2 > (s + 1) ** 2:
                        continue
                    if (x - 0) ** 2 + (z - 0) ** 2 < 5 ** 2:
                        continue
                    self.add_block((x, y, z), t, immediate=False, creat=True)
                    #if y == -1:
                        #self.world[(x, -2, z)].update(self, self.window)
            s -= d  # decrement side lenth so hills taper off

    print("[WORLDGENERATOR/INFO] generating base")
    n = 80  # 1/2 width and height of world
    s = 1  # step size
    y = 0  # initial y height
    for x in xrange(-n, n + 1, s):
        for z in xrange(-n, n + 1, s):
            # create a layer stone an grass everywhere.
            if not (x, y - 2, z) in self.world:
                self.add_block((x, y - 2, z), Blocks.Grass, immediate=False, creat=True)
            self.add_block((x, y - 3, z), Blocks.Bedrock, immediate=False, creat=True)
            if x in (-n, n) or z in (-n, n):
                # create outer walls.
                for dy in xrange(-2, 3):
                    self.add_block((x, y + dy, z), Blocks.Bedrock, immediate=False, creat=True)

    print("[INFO] World generator complet")

def loadWorld(model, name):
    print("[INFO] loading world")
    f = open("./saves/"+name+".mcWorld", mode="rb")
    data = pickle.load(f)
    f.close()
    if data["WorldVersion"] != "0.0.3":
        print("unsupported world format")
        raise RuntimeError()
    print("[INFO] loading blocks ("+str(len(data["WORLD"]))+")")
    for key in data["WORLD"].keys():
        model.add_block(key, data["WORLD"][key][0])
    model.window.position = data["player"][0]
    print("[INFO] loading player data")
    for i, slot in enumerate(data["player"][1][0]):
        model.window.player.inventory.hotbar_slots[i].setItem(Item.handler.getClass(slot[0]))
    for i, row in enumerate(data["player"][1][1]):
        for i2, slot in enumerate(row):
            model.window.player.inventory.rows[i][i2].setItem(Item.handler.getClass(slot[0]))
    model.window.player.mode = data["player"][2]
    model.window.player.gamemode = data["player"][3]
    model.window.player.harts = data["player"][4]
                            
        

def saveWorld(model, name):
    data = {"WORLD":{}, "player":[], "WorldVersion":"0.0.3"}
    for key in model.world.keys():
        inst = model.world[key]
        data["WORLD"][key] = [inst.getName()]
    data["player"] = [model.window.position, [[], []], model.window.player.mode, model.window.player.gamemode, model.window.player.harts]
    for slot in model.window.player.inventory.hotbar_slots:
        data["player"][1][0] += [slot.item.getName() if slot.item != None else None]
    for row in model.window.player.inventory.rows:
        data["player"][1][1].append([])
        for slot in row:
            data["player"][1][1][-1].append([slot.item.getName() if slot.item != None else None])
    f = open("./saves/"+name+".mcWorld", mode="wb")
    pickle.dump(data, f)
    f.close()
