import pickle, random
import Blocks, Item

xrange = range

def generateWorld(model):
    # generate the hills randomly
    print("[INFO] starting worldgernerator")
    worldsize = (16, 16) #one-half of one side
    print("[WORLDGENERATOR/INFO] generating bedrock-layer")
    for x in range(-worldsize[0], worldsize[0]):
        for z in range(-worldsize[1], worldsize[1]):
            model.add_block((x, 0, z), "minecraft:bedrock")
    print("[WORLDGENERATOR/INFO] generating hills with high-data")
    hights = {}
    for x in range(-worldsize[0], worldsize[0]):
        for z in range(-worldsize[1], worldsize[1]):
            l1 = hights[(x, z-1)] if z > -worldsize[0] and (x, z-1) in hights else None
            l2 = hights[(x-1, z)] if x > -worldsize[0] and (x-1, z) in hights else None
            l3 = hights[(x+1, z)] if x <  worldsize[0] and (x+1, z) in hights else None
            l4 = hights[(x, z+1)] if z <  worldsize[0] and (x, z+1) in hights else None
            if l1 == l2 == l3 == l4 == None:
                y = yr = random.randint(10, 20)
            else:
                values = []
                for e in [l1, l2, l3, l4]:
                    if e:
                        values.append(e)
                if len(values) == 0:
                    y = yr = random.randint(10, 20)
                else:
                    all = 0
                    for e in values:
                        all += e
                    y = round(all / len(values)) + round(random.randint(-10, 10) / 8)
                    yr = y
            hights[(x, z)] = y
            for y in range(1, y+1):
                if y == hights[(x, z)]:
                    model.add_block((x, y, z), "minecraft:grass")
                elif y < yr / 3 * 2:
                    model.add_block((x, y, z), "minecraft:stone")
                else:
                    model.add_block((x, y, z), "minecraft:dirt")
    print("[WORLDGENERATOR/INFO] generating trees")
    for _ in range(round(round((worldsize[0] + worldsize[1]) / 2) / 2)):
        (x, z) = (random.randint(-worldsize[0], worldsize[0]-1), random.randint(-worldsize[0], worldsize[0]-1))
        y = hights[(x, z)] if (x, z) in hights else 1
        log_m = random.choice(["minecraft:wood_log_0", "minecraft:wood_log_1", "minecraft:wood_log_2"])
        for y in range(y+1, y+random.randint(3, 10)): #treehight
            model.add_block((x, y, z), log_m)
        for xa in range(x-1, x+2):
            for za in range(z-1, z+2):
                model.add_block((xa, y+1, za), "minecraft:leave_0")
    print("[WORLDGENERATOR/INFO] generating ores")
    ORES = ["minecraft:coal_ore", "minecraft:gold_ore", "minecraft:diamond_ore", "minecraft:iron_ore"]
    for _ in range(round(round((worldsize[0] + worldsize[1]) / 2) * 32)):
        (x, z) = (random.randint(-worldsize[0], worldsize[0] - 1), random.randint(-worldsize[0], worldsize[0] - 1))
        y = random.randint(1, round(hights[(x, z)] / 3 * 2)) if (x, z) in hights else 1
        ore = random.choice(ORES)
        model.add_block((x, y, z), ore)
    print("[INFO] World generator complet")
