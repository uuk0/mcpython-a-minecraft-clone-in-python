import pickle, random
#import Blocks, Item
from constans import *
from mathhelper import *
from moduls import *
import WorldSaver

xrange = range

def generateWorld(model, bx=0, bz=0, size=(16, 16)):
    sector = sectorize((bx, 0, bz))
    generateChunkA(sector[0]*SECTOR_SIZE, sector[2]*SECTOR_SIZE, (16, 16), model)

def generateChunk(sector, model):
    model.togenerate.append([generateChunkA, (sector[0]*SECTOR_SIZE, sector[2]*SECTOR_SIZE, (16, 16), model)])

def generateChunkA(bx, bz, size, model):
    print("[WORLDGENERATOR/INFO] generating chunk ", sectorize((bx, 0, bz)))
    clist = []
    worldsize = (round(size[0] / 2), round(size[1] / 2))
    for x in range(-worldsize[0], worldsize[0]):
        for z in range(-worldsize[1], worldsize[1]):
            clist.append([0, (x + bx, 0, z + bz), "minecraft:bedrock"])
    hights = model.high_data
    for x in range(-worldsize[0], worldsize[0]):
        for z in range(-worldsize[1], worldsize[1]):
            try:
                y = yr = hights[(x, z)]
            except:
                yr = y = random.randint(10, 100)
                print("[ERROR] during generating chunk: high not found for block: ", (x, z))
                hights[(x, z)] = y
            for y in range(1, y + 1):
                if y == hights[(x, z)]:
                    clist.append([0, (x + bx, y, z + bz), "minecraft:grass"])
                elif y < yr / 3 * 2:
                    clist.append([0, (x + bx, y, z + bz), "minecraft:stone"])
                else:
                    clist.append([0, (x + bx, y, z + bz), "minecraft:dirt"])
    for _ in range(config.CONFIGS["TREE_AMOUNT_PER_SECTOR"]):
        (x, z) = (random.randint(-worldsize[0], worldsize[0] - 1), random.randint(-worldsize[0], worldsize[0] - 1))
        y = hights[(x, z)] if (x, z) in hights else 1
        log_m = random.choice(["minecraft:wood_log_0", "minecraft:wood_log_1", "minecraft:wood_log_2"])
        for y in range(y + 1, y + random.randint(*config.CONFIGS["TREE_HIGH"])):  # treehight
            clist.append([0, (x + bx, y, z + bz), log_m])
        for xa in range(x - 1, x + 2):
            for za in range(z - 1, z + 2):
                clist.append([0, (xa + bx, y + 1, za + bz), "minecraft:leave_0"])
    ORES = config.CONFIGS["ORES"]
    for _ in range(config.CONFIGS["ORE_AMOUNT_PER_SECTOR"]):
        (x, z) = (random.randint(-worldsize[0], worldsize[0] - 1), random.randint(-worldsize[0], worldsize[0] - 1))
        y = random.randint(1, round(hights[(x, z)] / 3 * 2)) if (x, z) in hights else 1
        ore = random.choice(ORES)
        clist.append([0, (x + bx, y, z + bz), ore])
    return clist

def generateHighData(model):
    worldsize = (20*8, 20*8)
    hights = {}
    for x in range(-worldsize[0], worldsize[0]):
        for z in range(-worldsize[1], worldsize[1]):
            l1 = hights[(x, z - 1)] if z > -worldsize[0] and (x, z - 1) in hights else None
            l2 = hights[(x - 1, z)] if x > -worldsize[0] and (x - 1, z) in hights else None
            l3 = hights[(x + 1, z)] if x < worldsize[0] and (x + 1, z) in hights else None
            l4 = hights[(x, z + 1)] if z < worldsize[0] and (x, z + 1) in hights else None
            if l1 == l2 == l3 == l4 == None:
                y = yr = random.randint(10, 20)
            else:
                values = []
                for e in [l1, l2, l3, l4]:
                    if e:
                        values.append(e)
                if len(values) == 0:
                    y = yr = random.randint(10, 20)
                else:
                    all = 0
                    for e in values:
                        all += e
                    y = round(all / len(values)) + round(random.randint(-100, 100) / 95)
                    yr = y
            hights[(x, z)] = y
    model.high_data = hights

def generateChunkToSave(name, bx, bz, model, size=(16, 16)):
    print("generating")
    data = generateChunkA(bx, bz, size, model)
    print("saving")
    WorldSaver.saveCommandToTMP(name, data)