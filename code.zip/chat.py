import Item, Block
from moduls import *

from pyglet.window import key

from crafting import craftinghandler

import WorldHandler

from Inventorys.Inventory import handler as invhandler

from mathhelper import *

from constans import *

KeyToValue = {key.A:"a", key.B:"b", key.C:"c", key.D:"d", key.E:"e", key.F:"f", key.G:"g", key.H:"h", key.I:"i",
              key.J:"j", key.K:"k", key.L:"l", key.M:"m", key.N:"n", key.O:"o", key.P:"p", key.Q:"q", key.R:"r",
              key.S:"s", key.T:"t", key.U:"u", key.V:"v", key.W:"w", key.X:"x", key.Y:"y", key.Z:"z", key._0:"0",
              key._1:"1", key._2:"2", key._3:"3", key._4:"4", key._5:"5", key._6:"6", key._7:"7", key._8:"8",
              key._9:"9", key.COMMA:",", key.MINUS:"-", key.PLUS:"+", key.SPACE:" "}

class chat:
    def __init__(self):
        self.chat = []
        self.opened = False
        self.window = None
        self.text = ""
        self.last_commants = []
        self.command_id = -1

    def printIn(self, msg):
        self.chat.append(msg)
        if len(self.chat) > 100:
            chat.pop(0)
        print("[CHAT] "+msg)

    def warn(self, msg):
        print("[WARNING] "+msg)

    def open(self):
        self.opened = True

    def addKey(self, symbol, mod):
        import pyglet.window.key
        key = pyglet.window.key
        if symbol == key.ENTER:
            self.excecute(self.text)
            self.text = ""
            self.window.keyEvent = "window"
            self.opened = False
            self.last_commants.append(self.text)
            self.text = ""
        elif symbol == key.BACKSPACE:
            self.text = self.text[:-1]
        elif symbol == key._7 and (mod & key.MOD_SHIFT):
            self.text += "/"
        elif symbol == key.ESCAPE:
            print("[WARNING] keyhandler does give 'esc'-key to chat.")
        elif symbol == key.MINUS and (mod & key.MOD_SHIFT):
            self.text += "_"
        elif symbol == key.PLUS and (mod & key.MOD_SHIFT):
            self.text += "*"
        elif symbol == key.PLUS and (mod & 108):
            self.text += "~"
        elif symbol == key.MOD_SHIFT:
            return #vorbereitend
        elif symbol == key.UP:
            self.command_id += 1
            if self.command_id == len(self.last_commants):
                self.command_id = len(self.last_commants) - 1
            self.text = self.last_commants[self.command_id]
        elif symbol == key.DOWN:
            self.command_id -= 1
            if self.command_id == -1:
                self.text = ""
            else:
                self.text = self.last_commants[self.command_id]
        else:
            if symbol in KeyToValue.keys():
                k = KeyToValue[symbol]
                if (mod & key.MOD_SHIFT):
                    k = k.upper()
                self.text += k
            else:
                print("[WARN] unknown char key "+str(symbol))

    def draw(self):
        if self.opened:
            self.window.keyEvent = "chat"
        else:
            self.window.keyEvent = "window"
        self.window.chatlabel.text = self.text
        self.window.chatlabel.draw()

    def excecute(self, msg):
        if not self.opened: return
        command = msg
        sc = command.split(" ")
        if command == "/help":
            print("error::commandnotfound")
        elif sc[0] == "/give":
            amount = 1 if len(sc) == 2 else int(sc[2])
            print(self.window.player.addToFreePlace(sc[1], amount))
        elif sc[0] == "/clear":
            for s in self.window.player.inventory.hotbar.slots:
                s.setItem(None)
            for s in self.window.player.inventory.rows.slots:
                s.setItem(None)
            for s in self.window.player.inventory.armor.slots:
                s.setItem(None)
            for s in self.window.player.inventory.crafting.slots:
                s.setItem(None)
        elif sc[0] == "/kill":
            self.window.kill("player fell out of the world")
        elif sc[0] == "/gamemode":
            self.window.player.gamemode = int(sc[1])
            if sc[1] == "0" or sc[1] == "2":
                self.window.flying = False
            elif sc[1] == "3":
                self.window.flying = True
        elif sc[0] == "/tp":
            self.window.position = (int(sc[1]), int(sc[2]), int(sc[3]))
        elif sc[0] == "/setblock":
            self.window.model.add_block((int(sc[1]), int(sc[2]), int(sc[3])), sc[4])
        elif sc[0] == "/fill":
            sx, sy, sz, ex, ey, ez = int(sc[1]), int(sc[2]), int(sc[3]), int(sc[4]), int(sc[5]), int(sc[6])
            block = sc[7]
            if len(sc) > 9 and sc[8] == "replace":
                replace = sc[9]
            else:
                replace = False
            for x in range(sx, ex):
                for y in range(sy, ey):
                    for z in range(sz, ez):
                        if not (x, y, z) in self.window.model.world:
                            if replace == False or replace == "air" or replace == "minecraft:air":
                                if block != "air":
                                    self.window.model.remove_block((x, y, z))
                        else:
                            oblock = self.window.model.world[(x, y, z)]
                            if oblock.getName() == Block.handler.getByName(replace).getName(False) or replace == False:
                                self.window.model.add_block((x, y, z), block)
        elif sc[0] == "/setPlace":
            amount = 1 if len(sc) == 1 else int(sc[1])
            self.window.player.setPlace(int(sc[1]), sc[2], amount)
        elif sc[0] == "/save":
            if self.window.WorldName == None:
                if len(sc) > 1:
                    self.window.WorldName = sc[1]
                else:
                    self.window.WorldName = input("weltname: ")
            elif len(sc) > 1:
                self.window.WorldName = sc[1]
            WorldHandler.saveWorld(self.window.model, self.window.WorldName)
        elif sc[0] == "/change":
            start = int(sc[1])
            end = int(sc[2])
            slotA = self.window.player.getSlot(start).getData()
            slotB = self.window.player.getSlot(end).getData()
            self.window.player.getSlot(end).setItem(slotA[0])
            self.window.player.getSlot(end).setAmount(slotA[1])
            self.window.player.getSlot(start).setItem(slotB[0])
            self.window.player.getSlot(start).setAmount(slotB[1])
        elif sc[0] == "/sort":
            items = []
            for i in range(0, 36):
                items.append(self.window.player.getSlot(i).getData())
            sort = {}
            for e in items:
                if e[0] != None:
                    if not e[0].getName() in sort:
                        sort[e[0].getName()] = e[1]
                    else:
                        sort[e[0].getName()] += e[1]
            skeys = list(sort.keys()).sort()
            nid = 0
            self.execute("/clear")
            for key in skeys:
                while sort[key] > 0:
                    self.window.player.getPlace(nid).setSlot(key)
                    if sort[key] > self.window.player.getPlace(nid).getMaxStackSize():
                        self.window.player.getPlace(nid).setAmount(self.window.player.getPlace(nid).getMaxStackSize())
                        sort[key] -= self.window.player.getPlace(nid).getMaxStackSize()
                    else:
                        self.window.player.getPlace(nid).setAmount(sort[key])
        elif sc[0] == "/info":
            vector = self.window.get_sight_vector()
            block, previous = self.window.model.hit_test(self.window.position, vector)
            if block:
                print(self.window.model.world[block].getInfoData())
        elif sc[0] == "/nbtNameInfo":
            vector = self.window.get_sight_vector()
            block, previous = self.window.model.hit_test(self.window.position, vector)
            if block:
                print(self.window.model.world[block].getNBTNames())
        elif sc[0] == "/nbtchange":
            vector = self.window.get_sight_vector()
            block, previous = self.window.model.hit_test(self.window.position, vector)
            if block:
                print(self.window.model.world[block].setNBT(sc[1], sc[2]))
            self.excecute("/texupdate")
        elif sc[0] == "/nbtread":
            vector = self.window.get_sight_vector()
            block, previous = self.window.model.hit_test(self.window.position, vector)
            if block:
                print(self.window.model.world[block].getNBT(sc[1]))
        elif sc[0] == "/texupdate":
            vector = self.window.get_sight_vector()
            block, previous = self.window.model.hit_test(self.window.position, vector)
            if block:
                print(self.window.model.world[block].generateTEX())
                self.window.model.hide_block(block)
                self.window.model.show_block(block)
        elif sc[0] == "/changeinventory":
            if sc[1] == "1":
                id = int(sc[2])
                x, y = int(sc[3]), int(sc[4])
                slot = self.window.player.getSlot(id)
                slot.setPos(x, y)
        elif sc[0] == "/itemnbtread":
            if self.window.player.inventory.hotbar_slots[self.window.hotbarelement] != None:
                print(self.window.player.inventory.hotbar_slots[self.window.hotbarelement].item.blocknbt,
                      self.window.player.inventory.hotbar_slots[self.window.hotbarelement].item.getName())
        elif sc[0] == "/updatecrafting":
            craftinghandler.check_player(self.window.player)
        elif sc[0] == "/itemnameread":
            try:
                print(self.window.player.inventory.hotbar_slots[self.window.hotbarelement].item.id)
            except:
                print("no item found")
        elif sc[0] == "/getOpenGuis":
            print(invhandler.inventoryinst)
        elif sc[0] == "/resetInventory":
            invhandler.shown = [0]
        elif sc[0] == "/generate":
            cx, _, cz = sectorize(self.window.position)
            bx = cx * SECTOR_SIZE
            bz = cz * SECTOR_SIZE
            WorldHandler.generateWorld(self.window.model, bx=bx, bz=bz, size=(16, 16))
        else:
            print("error::unknowncommand")
            print(sc)

chat = chat()
