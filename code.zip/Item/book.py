from .Item import *

class Bookshelve(Item):
    def getName(self):
        return "minecraft:book"

    def getTexturFile(self):
        return "./texturs/items/book_normal.png"

    def hasBlock(self):
        return False

handler.register(Bookshelve)
