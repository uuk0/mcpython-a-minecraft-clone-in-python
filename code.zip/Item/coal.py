from .Item import *

class Coal(Item):
    def getName(self):
        return "minecraft:coal"

    def getTexturFile(self):
        return "./texturs/items/coal.png"

    def hasBlock(self):
        return False

handler.register(Coal)
