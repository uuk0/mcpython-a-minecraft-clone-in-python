from .Item import *

class CoalOre(Item):
    def getName(self):
        return "minecraft:coal_ore"

    def getTexturFile(self):
        return "./texturs/items/coal_ore.jpe"

handler.register(CoalOre)
