from .Item import *

class crafting_table(Item):
    def getName(self):
        return "minecraft:crafting_table"

    def getTexturFile(self):
        return "./texturs/items/crafting_table.jpe"

handler.register(crafting_table)
