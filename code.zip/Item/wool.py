from .Item import *

for i in range(0, 16):
    class Wool(Item):
        id = 0

        def getName(self):
            return "minecraft:wool_"+str(self.id)

        def getTexturFile(self):
            return "./texturs/items/WOOL#"+str(self.id)+".png"


    Wool.id = i
    handler.register(Wool)
