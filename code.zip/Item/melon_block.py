from .Item import *

class melon_block(Item):
    def getName(self):
        return "minecraft:melon_block"

    def getTexturFile(self):
        return "./texturs/items/melon_block_item.jpe"

handler.register(melon_block)
