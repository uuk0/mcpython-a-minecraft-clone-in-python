from .Item import *

class IronBlock(Item):
    def getName(self):
        return "minecraft:iron_block"

    def getTexturFile(self):
        return "./texturs/items/iron_block.jpe"

handler.register(IronBlock)
