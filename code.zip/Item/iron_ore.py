from .Item import *

class IronOre(Item):
    def getName(self):
        return "minecraft:iron_ore"

    def getTexturFile(self):
        return "./texturs/items/ironore.jpe"

handler.register(IronOre)
