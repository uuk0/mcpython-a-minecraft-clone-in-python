from .Item import *

class DiamondBlock(Item):
    def getName(self):
        return "minecraft:diamond_block"

    def getTexturFile(self):
        return "./texturs/items/diamond_block.jpe"

handler.register(DiamondBlock)
