
from destroyGroup import *

class ItemHandler:
    def __init__(self):
        self.nametoitem = {}
        self.prefixes = []

    def register(self, itemclass):
        name = itemclass().getName()
        self.nametoitem[name] = itemclass
        if not name.split(":")[0] in self.prefixes:
            self.prefixes.append(name.split(":")[0])

    def getClass(self, name):
        if type(name) == str:
            if name in self.nametoitem:
                return self.nametoitem[name]
            for pre in self.prefixes:
                if pre+":"+name in self.nametoitem:
                    return self.nametoitem[pre+":"+name]
            print("[ERROR] "+str(name)+" not found")
            return None
        return name()

handler = ItemHandler()

class Item:
    def __init__(self):
        self.blocknbt = {}
        self.mode = "ITEM"

    def getName(self):
        return "minecraft:none"

    def getTexturFile(self):
        return "./texturs/none.png"

    def hasBlock(self):
        return True

    def getMaxStackSize(self):
        return 64

    def getToolHardness(self):
        return 1 #1/n multiplier

    def getAttackDamage(self):
        return 1

    def getDestroyGroup(self):
        return None

    def getDestroyMultiplierWithTool(self):
        return 1

    def getOreDictNames(self):
        return []

    def __call__(self):
        obj =  self.__class__()
        obj.blocknbt = self.blocknbt.copy()
        return obj

    def getFuelAmount(self):
        return 0

    def on_right_click(self, block, previos, button, modifiers):
        pass

    def canDestroyBlock(self, block, button, modifiers):
        return True

    def on_left_click(self, block, previos, button, modifiers):
        pass


    
