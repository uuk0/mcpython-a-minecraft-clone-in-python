from .Item import *

class Gold(Item):
    def getName(self):
        return "minecraft:gold"

    def getTexturFile(self):
        return "./texturs/items/gold_ingot.png"

    def hasBlock(self):
        return False

handler.register(Gold)
