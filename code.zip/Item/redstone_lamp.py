from .Item import *

class redstone_lamp(Item):
    def getName(self):
        return "minecraft:redstone_lamp"

    def getTexturFile(self):
        return "./texturs/items/redstone_lamp_item.jpe"

handler.register(redstone_lamp)
