from .Item import *


class Dirt(Item):
    def getName(self):
        return "minecraft:dirt"

    def getTexturFile(self):
        return "./texturs/items/dirt_item.jpe"

handler.register(Dirt)
