from .Item import *

class Brick(Item):
    def getName(self):
        return "minecraft:brick"

    def getTexturFile(self):
        return "./texturs/items/brick_item.jpe"

handler.register(Brick)
