from .Item import *

class redstone_block(Item):
    def getName(self):
        return "minecraft:redstone_block"

    def getTexturFile(self):
        return "./texturs/items/redstone_block.jpe"

handler.register(redstone_block)
