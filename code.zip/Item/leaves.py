from .Item import *

class leave_0(Item):
    def getName(self):
        return "minecraft:leave_0"

    def getTexturFile(self):
        return "./texturs/items/leave_0.png"

handler.register(leave_0)
