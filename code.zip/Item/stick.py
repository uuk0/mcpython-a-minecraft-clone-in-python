from .Item import *

class Stick(Item):
    def getName(self):
        return "minecraft:stick"

    def getTexturFile(self):
        return "C:/Python/mcpython/mcpython20/masterA/texturs/items/stick.jpg"

    @property
    def hasBlock(self):
        return False

handler.register(Stick)
