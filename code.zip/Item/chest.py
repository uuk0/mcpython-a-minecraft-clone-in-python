from .Item import *

class chest(Item):
    def getName(self):
        return "minecraft:chest"

    def getTexturFile(self):
        return "./texturs/items/chest.jpe"

handler.register(chest)
