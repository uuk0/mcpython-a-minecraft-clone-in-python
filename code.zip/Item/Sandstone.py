from .Item import *

class Sandstone(Item):
    def getName(self):
        return "minecraft:sandstone"

    def getTexturFile(self):
        return "./texturs/items/sandstone_item.jpe"

handler.register(Sandstone)
