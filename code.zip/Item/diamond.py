from .Item import *

class Diamond(Item):
    def getName(self):
        return "minecraft:diamond"

    def getTexturFile(self):
        return "./texturs/items/diamond.png"

    def hasBlock(self):
        return False

handler.register(Diamond)
