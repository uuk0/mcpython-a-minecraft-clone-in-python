from .Item import *

class GoldBlock(Item):
    def getName(self):
        return "minecraft:gold_block"

    def getTexturFile(self):
        return "./texturs/items/gold_block.jpe"

handler.register(GoldBlock)
