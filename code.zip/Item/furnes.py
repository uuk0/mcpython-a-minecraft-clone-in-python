from .Item import *

class furnes(Item):
    def getName(self):
        return "minecraft:furnes"

    def getTexturFile(self):
        return "./texturs/items/furnes_item.jpe"

handler.register(furnes)
