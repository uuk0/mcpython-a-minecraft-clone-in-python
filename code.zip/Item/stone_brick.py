from .Item import *

class StoneBrick(Item):
    def getName(self):
        return "minecraft:stone_brick"

    def getTexturFile(self):
        return "./texturs/items/stone_brick.jpe"

handler.register(StoneBrick)
