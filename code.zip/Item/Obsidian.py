from .Item import *

class Obsidian(Item):
    def getName(self):
        return "minecraft:obsidian"

    def getTexturFile(self):
        return "./texturs/items/obsidian_item.jpe"

handler.register(Obsidian)
