from .Item import *

class Pumpkin(Item):
    def getName(self):
        return "minecraft:pumpkin"

    def getTexturFile(self):
        return "./texturs/items/PUMPKIN.png"

handler.register(Pumpkin)
