from .Item import *

class GoldOre(Item):
    def getName(self):
        return "minecraft:gold_ore"

    def getTexturFile(self):
        return "./texturs/items/gold_ore.jpe"

handler.register(GoldOre)
