from .Item import *

class Iron(Item):
    def getName(self):
        return "minecraft:iron"

    def getTexturFile(self):
        return "./texturs/items/iron_ingot.png"

    def hasBlock(self):
        return False

handler.register(Iron)
