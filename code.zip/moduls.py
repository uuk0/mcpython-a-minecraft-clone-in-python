print("[INFO] importing moduls")

print("[IMPORT/INFO] importing sys")
import sys

print("[IMPORT/INFO] importing math")
import math

print("[IMPORT/INFO] importing random")
import random

print("[IMPORT/INFO] importing time")
import time

print("[IMPORT/INFO] importing collections")
from collections import deque

print("[IMPORT/INFO] importing pyglet")
print("[IMPORT/INFO] importing pyglet.image")
from pyglet import image
print("[IMPORT/INFO] importing pyglet.gl")
from pyglet.gl import *
print("[IMPORT/INFO] importing pyglet.graphics")
from pyglet.graphics import TextureGroup
print("[IMPORT/INFO] importing pyglet.window")
from pyglet.window import key, mouse
import pyglet
