
class OreDict:
    ARMOR = "mcpython:oredict:armor"
    ARMOR_HEAD   = "mcpython:oredict:armor:head"
    ARMOR_BODY   = "mcpython:oredict:armor:body"
    ARMOR_LEG    = "mcpython:oredict:armor:leg"
    ARMOR_FOOT   = "mcpython:oredict:armor:foot"

    TOOL_SHOVEL  = "mcpython:oredict:tool:shovel"
    TOOL_PICKAXE = "mcpython:oredict:tool:pickaxe"
    TOOL_HOE     = "mcpython:oredict:tool:hoe"
    TOOL_AXE     = "mcpython:oredict:tool:axe"
    TOOL_SWORD   = "mcpython:oredict:tool:sword"

    FUEL         = "mcpython:oredict:fuel"

    DIRT         = "mcpython:oredict:dirt"
    GRASS        = "mcpython:oredict:grass"
    STONE        = "mcpython:oredict:stone"
    WOOL = "mcpython:oredict:wool"
    WOOD_PLANK = "mcpython:oredict:wood_plank"
    WOOD_LOG = "mcpython:oredict:wood_log"
