
class OreDict:
    ARMOR = "mcpython:oredict:armor"
    ARMOR_HEAD = "mcpython:oredict:armor:head"
    ARMOR_BODY = "mcpython:oredict:armor:body"
    ARMOR_LEG  = "mcpython:oredict:armor:leg"
    ARMOR_FOOT = "mcpython:oredict:armot:foot"
    WOOD_LOG   = "mcpython:oredict:wood_log"
    WOOL       = "mcpython:oredict:wool"
    WOOD_PLANK = "mcpython:oredict:wood_plank"
    FUEL       = "mcpython:ordict:fuel"
