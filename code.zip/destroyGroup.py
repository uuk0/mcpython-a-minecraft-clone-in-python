class destroyGroups:
    SHOVEL = "mcpython:group:destroy:shovel"
    PIKAXE = "mcpython:group:destroy:pikaxe"
    HOE    = "mcpython:group:destroy:hoe"
    AXE    = "mcpython:group:destroy:axe"
    SWORD  = "mcpython:group:destroy:sword"
