from .Block import *
from player import Slot
from Inventorys import block_craftingtable

class crafting_table(Block):
    def __init__(self, *args, **kwargs):
        Block.__init__(self, *args, **kwargs)
        """self.inventory = [Slot(0, 0),
                          Slot(0, 0),
                          Slot(0, 0),
                          Slot(0, 0),
                          Slot(0, 0),
                          Slot(0, 0),
                          Slot(0, 0),
                          Slot(0, 0),
                          Slot(0, 0),
                          Slot(0, 0, mode="o")]"""
        self.inventory = []
    
    def getTexturFile(self):
        return 1
    
    def getTex(self):
        return total_tex_coords((2, 0), (2, 0),
                                (0, 0), (0, 0), (0, 0), (0, 0))

    def getName(self):
        return "minecraft:crafting_table"

    def getNBTNames(self):
        names = []
        for e in range(10):
            names.append("inventory_"+str(e)+"_x")
            names.append("inventory_"+str(e)+"_y")
            names.append("inventory_"+str(e)+"_item")

        return names

    def drawInventory(self):
        pass

    def setNBT(self, name, value):
        pass

    def getNBT(self, name):
        pass

    def getAllNBT(self):
        return []

    def getAllItemNBT(self):
        return {}

    def setAllNBT(self, nbt):
        pass

    def hasInventory(self):
        return True

    def getInventoryID(self):
        return self.inv.id

    def on_creat(self):
        self.inv = block_craftingtable.craftingtable()

    def getInventoryID(self):
        return self.inv.id

    def getDestroyGroups(self):
        return [destroyGroups.AXE]


handler.register(crafting_table)
