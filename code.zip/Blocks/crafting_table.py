import Inventorys
from .Block import *
from player import Slot
import crafting


class crafting_table(Block):
    def __init__(self, *args, **kwargs):
        Block.__init__(self, *args, **kwargs)
    
    def getTexturFile(self):
        return 1
    
    def getTex(self):
        return total_tex_coords((2, 0), (2, 0),
                                (0, 0), (0, 0), (0, 0), (0, 0))

    def getName(self):
        return "minecraft:crafting_table"

    def getNBTNames(self):
        names = []
        for e in range(10):
            names.append("inventory_"+str(e)+"_x")
            names.append("inventory_"+str(e)+"_y")
            names.append("inventory_"+str(e)+"_item")

        return names

    def drawInventory(self):
        pass

    def setNBT(self, name, value):
        pass

    def getNBT(self, name):
        pass

    def getAllNBT(self):
        return []

    def getAllItemNBT(self):
        return {}

    def setAllNBT(self, nbt):
        pass

    def hasInventory(self):
        return True

    def getInventoryID(self):
        return self.inv.id

    def on_creat(self):
        self.inv = Inventorys.craftingtable()
        self.inv.block = self
        self.crafting_recipi = None
        for e in self.inv.slots:
            e.update = self.crafting_update

    def crafting_update(self):
        slots = self.inv.slots
        for c in crafting.craftinghandler.recipis[crafting.Grid.crafting_1x1]:
            print(c)
            flag = [False, False, None]
            for e in slots[:-1]:
                if e.item and e.item.getName() == c.input[0]:
                    if flag[0]:
                        flag[1] = True
                    else:
                        flag[0] = True
                        flag[2] = e
                elif e.item:
                    flag[2] = True
            if flag[0] and not flag[1]:
                self.crafting_recipi = flag[2]
                self.inv.slots[-1].setItem(c.output[0], amount=c.outputamount[0])


    def getInventoryID(self):
        return self.inv.id

    def getDestroyGroups(self):
        return [destroyGroups.AXE]

    def getDrop(self, item):
        items = [self.getName()]
        for e in self.inv.slots:
            if e.item: items.append(e.item.getName())
        return items

    def getDropAmount(self, item):
        items = [1]
        for e in self.inv.slots:
            if e.item: items.append(e.amount)
        return items


handler.register(crafting_table)
