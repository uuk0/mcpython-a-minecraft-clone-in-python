from .Block import *
import random


class CoalOre(Block):
    def getTex(self):
        return tex_coords((0, 4), (0, 4), (0, 4))

    def getName(self):
        return "minecraft:coal_ore"

    def getDrop(self, item):
        return "minecraft:coal"

    def getDropAmount(self, item):
        return random.randint(1, 10)

    def getDestroyGroups(self):
        return [destroyGroups.PIKAXE]

handler.register(CoalOre)
