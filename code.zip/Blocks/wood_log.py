from .Block import *

class TexturError(Exception): pass

SIDES = {"N":"mcpython:side:N",
         "O":"mcpython:side:O",
         "S":"mcpython:side:S",
         "W":"mcpython:side:W",
         "U":"mcpython:side:U",
         "D":"mcpython:side:D",
         "A":"mcpython:side:A"}

class WoodLog(Block):
    def __init__(self, pos, hitblock=None, side=None):
        Block.__init__(self, pos)
        self.side = side
        if self.side == None:
            if hitblock == None:
                hitblock = (pos[0], pos[1] + 1, pos[2])
            if hitblock[1] > pos[1]:
                self.side = SIDES["U"]
            elif hitblock[1] < pos[1]:
                self.side = SIDES["D"]
            elif hitblock[0] > pos[0]:
                self.side = SIDES["N"]
            elif hitblock[0] < pos[0]:
                self.side = SIDES["S"]
            elif hitblock[2] > pos[2]:
                self.side = SIDES["O"]
            elif hitblock[2] < pos[2]:
                self.side = SIDES["W"]
            else:
                self.side = SIDES["U"]
        self.generateTEX()

    def generateTEX(self):
        if self.side == SIDES["U"] or self.side == SIDES["D"]:
            self.tex = total_tex_coords(self.getTexturFront(),
                                        self.getTexturFront(),
                                        self.getTexturSide(),
                                        self.getTexturSide(),
                                        self.getTexturSide(),
                                        self.getTexturSide())
        elif self.side == SIDES["N"] or self.side == SIDES["S"]:
            self.tex = total_tex_coords(self.getTexturSideB(),
                                        self.getTexturSide(),
                                        self.getTexturFront(),
                                        self.getTexturFront(),
                                        self.getTexturSide(),
                                        self.getTexturSide())
        elif self.side == SIDES["O"] or self.side == SIDES["W"]:
            self.tex = total_tex_coords(self.getTexturSide(),
                                        self.getTexturSideB(),
                                        self.getTexturSide(),
                                        self.getTexturSide(),
                                        self.getTexturFront(),
                                        self.getTexturFront())
        elif self.side == SIDES["A"]:
            self.tex = total_tex_coords(self.getTexturSide(),
                                        self.getTexturSide(),
                                        self.getTexturSide(),
                                        self.getTexturSide(),
                                        self.getTexturSide(),
                                        self.getTexturSide())
        else:
            print("[ERROR] side is incorrect by wood_log")
            print("-> reseting sides...")
            self.side = SIDES["U"]
            self.generateTEX()
            
    def getTexturFront(self):
        return

    def getTexturSide(self):
        return

    def getTexturSideB(self):
        return

    def getTex(self):
        return self.tex

    def getInfoData(self):
        return self.getName()+"/instance/"+str(id(self))+"/{tex="+str(self.tex)+", side="+str(self.side)+"}"

    def getNBTNames(self):
        return ["side", "tex"]

    def setNBT(self, name, value):
        if name == "side":
            if value in SIDES.keys():
                value = SIDES[value]
            self.side = str(value)
            self.generateTEX()

    def getNBT(self, name):
        if name == "side":
            return self.side
        elif name == "tex":
            return self.tex

    def getAllNBT(self):
        return [self.side]

    def getAllItemNBT(self):
        return {"side":self.side}

    def setAllNBT(self, nbt):
        print(nbt, "side" in nbt.keys())
        if "side" in nbt.keys():
            self.side = nbt["side"]
            self.generateTEX()
    

class Wood_Log_0(WoodLog):
    def getTexturFront(self):
        return (5, 1)

    def getTexturSide(self):
        return (5, 0)

    def getTexturSideB(self):
        return (8, 0)

    def getName(self):
        return "minecraft:wood_log_0"
        
handler.register(Wood_Log_0)

class Wood_Log_1(WoodLog):
    def getTexturFront(self):
        return (6, 1)

    def getTexturSide(self):
        return (6, 0)

    def getTexturSideB(self):
        return (8, 1)

    def getName(self):
        return "minecraft:wood_log_1"

handler.register(Wood_Log_1)
