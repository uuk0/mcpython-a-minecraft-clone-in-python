from .Block import *


class Brick(Block):
    def getTex(self):
        return tex_coords((2, 0), (2, 0), (2, 0))

    def getName(self):
        return "minecraft:brick"

handler.register(Brick)
