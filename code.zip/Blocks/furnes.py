from .Block import *


class furnes(Block):
    def getTex(self):
        return total_tex_coords((7, 15), (7, 15), (6, 15), (8, 15), (8, 15), (8, 15))

    def getName(self):
        return "minecraft:furnes"

    def getTexturFile(self):
        return "./texturs/textur2.png"

handler.register(furnes)
