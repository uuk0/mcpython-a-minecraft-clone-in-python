from .Block import *


class furnes(Block):
    def on_creat(self):
        self.inv = None
        self.fueltime = 0

    def getTex(self):
        if self.fueltime > 0:
            return total_tex_coords((7, 15), (7, 15), (7, 15), (8, 15), (8, 15), (8, 15))
        else:
            return total_tex_coords((7, 15), (7, 15), (6, 15), (8, 15), (8, 15), (8, 15))

    def getName(self):
        return "minecraft:furnes"

    def getTexturFile(self):
        return 1

    def getDestroyGroups(self):
        return [destroyGroups.PIKAXE]

handler.register(furnes)
