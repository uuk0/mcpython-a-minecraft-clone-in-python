from .Block import *


class Obsidian(Block):
    def getTex(self):
        return tex_coords((3, 0), (3, 0), (3, 0))

    def getName(self):
        return "minecraft:obsidian"

handler.register(Obsidian)
