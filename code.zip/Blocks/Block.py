
from mathhelper import *
from texturGroups import handler as texturhandler
from moduls import *
from destroyGroup import *
import texturGroups

class Block:
    def __init__(self, pos, hitblock=None, register=False):
        self.pos = pos
        self.redstone_level = self.defaultRedstoneLevel()
        if not register: self.on_creat()

    def getTex(self):
        print("[ERROR] unknown block-definition-tex: "+str(self.__name__))
        raise RuntimeError()

    def update(self, model, window):
        pass

    def getName(self):
        return "unknown:block"

    def isBreakAble(self):
        return True

    def getTexturFile(self):
        return 0

    def defaultRedstoneLevel(self):
        return False

    def getItemName(self):
        return self.getName()

    def getDropAmount(self, item):
        return 1

    def getDrop(self, item):
        return self.getItemName()

    def hasHitbox(self):
        return True

    def getDestroyGroups(self):
        return []

    def getHardness(self):
        return 1

    def getBrakeSoundFile(self):
        return "./sounds/dig/stone1.ogg"

    def getVisualName(self):
        return self.getName()

    def redstoneStateUpdate(self, model, world):
        pass

    def __call__(self, *args, **kwargs):
        obj =  self.__class__(*args, **kwargs)
        obj.setAllNBT(self.getAllItemNBT())

    def getInfoData(self):
        return ""

    def getNBTNames(self):
        return []

    def setNBT(self, name, value):
        pass

    def getNBT(self, name):
        pass

    def generateTEX(self):
        pass

    def getAllNBT(self):
        return []

    def getAllItemNBT(self):
        return {}

    def setAllNBT(self, nbt):
        pass

    def hasInventory(self):
        return False

    def getInventoryID(self):
        return 0

    def show(self, model, window, texture):
        x, y, z = position = self.pos
        vertex_data = cube_vertices(x, y, z, 0.5)
        texture_data = list(texture)
        # create vertex list
        # FIXME Maybe `add_indexed()` should be used instead
        model._shown[position] = model.batch.add(24, GL_QUADS,
                                               texturGroups.handler.getGroup(model.world[position].getTexturFile()),
                                               ('v3f/static', vertex_data),
                                               ('t2f/static', texture_data))

    def hide(self, model, window):
        position = self.pos
        if position in model._shown:
            model._shown.pop(position).delete()

    def on_creat(self):
        pass

    def on_left_click(self, block, previos, button, modifiers):
        pass

    def on_right_click(self, block, previos, button, modifiers):
        pass

    def isBreakAbleWithItem(self, item):
        return True

    def getOreDictNames(self):
        return []

    def getInventorys(self):
        return []
    

class BlockHandler:
    def __init__(self):
        self.blocks = {}
        self.prefixes = []

    def register(self, blockclass):
        name = blockclass((0, 0, 0), register=True).getName()
        self.blocks[name] = blockclass
        if not name.split(":")[0] in self.prefixes:
            self.prefixes.append(name.split(":")[0])

    def getByName(self, name):
        if type(name) == str:
            if name in self.blocks:
                return self.blocks[name]
            for pre in self.prefixes:
                if pre+":"+name in self.blocks:
                    return self.blocks[pre+":"+name]
            return None
        else:
            return name


handler = BlockHandler()
