from .Block import *

class Grass(Block):
    def getTex(self):
        return tex_coords((1, 0), (0, 1), (0, 0))

    def getName(self):
        return "minecraft:grass"

    def update(self, model, window):
        (x, y, z) = self.pos
        if (x, y+1, z) in model.world:
            model.add_block(self.pos, "minecraft:dirt", creat=True)

    def getDrop(self):
        return "minecraft:dirt"

handler.register(Grass)
