from .Block import *

class Wool(Block):
    def on_creat(self):
        self.id = 0

    def getAllItemNBT(self):
        return {"id":self.id}

    def getNBT(self, name):
        if name == "id":
            return self.id

    def getNBTNames(self):
        return ["id"]

    def setAllNBT(self, nbt):
        self.id = nbt["id"] if "id" in nbt else 0

    def setNBT(self, name, value):
        if name == "id":
            self.id = int(value)

    def getTex(self):
        return tex_coords((15, 15-self.id), (15, 15-self.id), (15, 15-self.id))

    def getName(self):
        return "minecraft:wool"

    def getDestroyGroups(self):
        return [destroyGroups.SHEER]

handler.register(Wool)
