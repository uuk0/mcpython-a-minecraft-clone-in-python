from .Block import *


class GoldOre(Block):
    def getTex(self):
        return tex_coords((3, 4), (3, 4), (3, 4))

    def getName(self):
        return "minecraft:gold_ore"

handler.register(GoldOre)
