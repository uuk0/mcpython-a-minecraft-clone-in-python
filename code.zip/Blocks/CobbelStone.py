from .Block import *


class CobbelStone(Block):
    def getTex(self):
        return tex_coords((6, 3), (6, 3), (6, 3))

    def getName(self):
        return "minecraft:cobblestone"

handler.register(CobbelStone)
