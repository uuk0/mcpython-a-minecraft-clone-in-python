from .Block import *

class wood_plank_1(Block):
    def getName(self):
        return "minecraft:wood_plank_0"

    def getTex(self):
        return tex_coords((1, 3), (1, 3), (1, 3))

    def getDestroyGroups(self):
        return [destroyGroups.AXE]

handler.register(wood_plank_1)

class wood_plank_2(Block):
    def getName(self):
        return "minecraft:wood_plank_2"

    def getTex(self):
        return tex_coords((2, 3), (2, 3), (2, 3))

    def getDestroyGroups(self):
        return [destroyGroups.AXE]

handler.register(wood_plank_2)

class wood_plank_3(Block):
    def getName(self):
        return "minecraft:wood_plank_1"

    def getTex(self):
        return tex_coords((3, 3), (3, 3), (3, 3))

    def getDestroyGroups(self):
        return [destroyGroups.AXE]

handler.register(wood_plank_3)
