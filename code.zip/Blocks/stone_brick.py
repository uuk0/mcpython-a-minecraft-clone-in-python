from .Block import *

class StoneBrick(Block):
    def getTex(self):
        return tex_coords((0, 3), (0, 3), (0, 3))

    def getName(self):
        return "minecraft:stone_brick"

handler.register(StoneBrick)
