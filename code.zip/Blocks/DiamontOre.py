from .Block import *
import random


class DiamondOre(Block):
    def getTex(self):
        return tex_coords((2, 4), (2, 4), (2, 4))

    def getName(self):
        return "minecraft:diamond_ore"

    def getDrop(self):
        return "minecraft:diamond"

    def getDropAmount(self):
        return random.randint(1, 3)

handler.register(DiamondOre)
