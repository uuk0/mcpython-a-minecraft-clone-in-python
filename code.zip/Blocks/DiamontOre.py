from .Block import *
import random


class DiamondOre(Block):
    def getTex(self):
        return tex_coords((2, 4), (2, 4), (2, 4))

    def getName(self):
        return "minecraft:diamond_ore"

    def getDrop(self, item):
        return "minecraft:diamond"

    def getDropAmount(self, item):
        return random.randint(1, 3)

    def isBreakAbleWithItem(self, item):
        if item.getName() == "minecraft:iron_pick_axe" or item.getName() == "minecraft:diamond_pick_axe":
            return True
        return False

    def getDestroyGroups(self):
        return [destroyGroups.PIKAXE]

handler.register(DiamondOre)
