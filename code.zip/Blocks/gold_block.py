from .Block import *

class GoldBlock(Block):
    def getTex(self):
        return tex_coords((11, 1), (11, 1), (11, 1))

    def getName(self):
        return "minecraft:gold_block"

handler.register(GoldBlock)
