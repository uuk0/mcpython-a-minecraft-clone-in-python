from .Block import *


class IronOre(Block):
    def getTex(self):
        return tex_coords((1, 4), (1, 4), (1, 4))

    def getName(self):
        return "minecraft:iron_ore"

handler.register(IronOre)
