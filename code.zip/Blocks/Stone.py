from .Block import *

class Stone(Block):
    def getTex(self):
        return tex_coords((2, 1), (2, 1), (2, 1))

    def getName(self):
        return "minecraft:stone"

    def getDrop(self, item):
        return "minecraft:cobblestone"

    def getDestroyGroups(self):
        return [destroyGroups.PIKAXE]


handler.register(Stone)
