from .Block import *

class Stone(Block):
    def getTex(self):
        return tex_coords((2, 1), (2, 1), (2, 1))

    def getName(self):
        return "minecraft:stone"

    def getDrop(self):
        return "minecraft:cobblestone"


handler.register(Stone)
