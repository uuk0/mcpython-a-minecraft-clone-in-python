from .Block import *

class leave_0(Block):
    def getTex(self):
        return tex_coords((5, 2), (5, 2), (5, 2))

    def getName(self):
        return "minecraft:leave_0"

    def getDrop(self):
        return self.getName()

handler.register(leave_0)