from .Block import *
import random

class leave_0(Block):
    def getTex(self):
        return tex_coords((5, 2), (5, 2), (5, 2))

    def getName(self):
        return "minecraft:leave_0"

    def getDrop(self):
        return "minecraft:sapling"

    def getDropAmount(self):
        return 0 if random.randint(1, 7) < 6 else 1

handler.register(leave_0)