from .Block import *

class Dirt(Block):
    def getTex(self):
        return tex_coords((0, 1), (0, 1), (0, 1))

    def getName(self):
        return "minecraft:dirt"

    def update(self, model, window):
        (x, y, z) = self.pos
        if not (x, y + 1, z) in model.world:
            model.add_block(self.pos, "minecraft:grass", creat=True)

    def getHardness(self):
        return 10


handler.register(Dirt)
