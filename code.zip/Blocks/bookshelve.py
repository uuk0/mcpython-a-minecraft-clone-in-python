from .Block import *
import random

class Bookshelve(Block):
    def getTex(self):
        return tex_coords((3, 3), (3, 3), (5, 4))

    def getName(self):
        return "minecraft:bookshelve"

    def getDrop(self):
        return "minecraft:book"

    def getDropAmount(self):
        return random.randint(1, 4)

handler.register(Bookshelve)
