from .Block import *
from TickHandler import handler as tickhandler
from .fallingblock import *

class Sand(FallingBlock):
    def getTex(self):
        return tex_coords((1, 1), (1, 1), (1, 1))

    def getName(self):
        return "minecraft:sand"

handler.register(Sand)
