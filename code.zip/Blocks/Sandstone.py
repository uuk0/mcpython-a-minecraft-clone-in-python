from .Block import *

class Sandstone(Block):
    def getTex(self):
        return tex_coords((2, 2), (2, 2), (2, 2))

    def getName(self):
        return "minecraft:sandstone"

handler.register(Sandstone)
