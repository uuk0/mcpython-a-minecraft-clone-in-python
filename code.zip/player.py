from moduls import *

from oredictnames import *

from Inventorys import *

import Item

from crafting import craftinghandler

from Inventorys import *
from Inventorys.Inventory import Slot, handler as invhandler, InventoryHandler

class player:
    def __init__(self, window):
        self.inventory = PlayerInventory(window, self)
        self.mode = 1 #0:nichts, 1:hotbar, 2:survival_inventory, 3:creativ_inventory, 4: creativ_tab [self.creativ_tab_id], 5: crafting_table
        self.gamemode = 0 #0:surivival, 1:creativ, 2:hardcore, 3:spectator
        self.falling = False
        self.fallhigh = 0
        self.harts = 10
        self.window = window
        self.creativ_tab_id = None
        self.block = None
        invhandler.show(0)
        self.inventorys = [self.inventory.hotbar,
                           self.inventory.rows,
                           self.inventory.armor
                           ]

    def addToFreePlace(self, name, amount=1, start=0):
        for i in self.inventorys:
            for e in i.slots:
                if e.id < start:
                    pass
                elif not e.item:
                    e.setItem(name, amount=amount)
                    return True
                elif e.item.getName() == name:
                    if e.amount + amount - 1 < e.item.getMaxStackSize():
                        e.amount += amount
                        return True
                    elif e.amount < e.getMaxStackSize():
                        amount = amount - (e.getMaxStackSize() - e.amount)
                        e.amount = e.getMaxStackSize()
        return False

    def setPlace(self, id, name):
        invhandler.sfromid[id].setItem(name)

    def getPlace(self, id):
        return invhandler.sfromid[id].item
            
    def getSlot(self, id):
        return invhandler.sfromid[id]

    def update(self):
        if self.harts == 0 and self.gamemode != 3 and self.gamemode != 1:
            self.window.kill("player hearts go down")



class PlayerInventory:
    def __init__(self, window, master):
        self.window = window; self.master = master
        self.hotbar = player_hotbar.hotbar()
        self.rows = player_rows.rows()
        self.armor = player_armor.armor()
        self.crafting = player_crafting.crafting()
        self.slot_moving = None
        self.slot_moving_pos = (0, 0)
        self.slot_moving_start = (0, 0)
        self.ismovingItem = False

    def draw(self):
        if self.master.mode == 3:
            self.img3.x = 180
            self.img3.y = 10
            self.img3.draw()
        if self.master.mode == 2:
            self.img1.x = 180
            self.img1.y = 10
            self.img1.draw()
        elif self.master.mode == 1:
            #if self.master.gamemode != 1:
            self.img2.x = 180
            self.img2.y = 10
            self.img2.draw()
        elif self.master.mode != 0 and self.master.mode != 3:
            print("[ERROR] unknown inventory-mode "+str(self.master.mode))
            raise RuntimeError()
        if self.master.mode != 0:
            for e in self.hotbar_slots:
                e.draw()
        if self.master.mode == 2 or self.master.mode == 3 or self.master.mode == 5:
            for r in self.rows:
                for e in r:
                    e.draw()
        if self.master.mode == 2:
            for e in self.armor:
                e.draw()
            for e in self.crafting_in + self.crafting_out + self.offhand:
                e.draw()
        if self.master.mode == 5:
            self.player.block.drawInventory()

    def on_mouse_drag(self, x, y, dx, dy, buttons, modifiers):
        pass
    """
        if self.slot_moving == None: return
        self.slot_moving.setPos(x + dx, y + dy)
        slot = self.slot_moving
        self.slot_moving_pos = (slot.x, slot.y,)"""

    def on_mouse_press(self, x, y, button, modifiers):
        if not self.ismovingItem:
            x, y = x - 20, y + 3
            if button == pyglet.window.mouse.LEFT:
                slot = self.getPress(x, y)
                if slot != None:
                    self.slot_moving = slot
                    self.slot_moving_pos = (slot.x, slot.y,)
                    self.slot_moving_start = (slot.x, slot.y,)
                else:
                    self.slot_moving = None
                self.ismovingItem = True
                if slot == self.crafting.slots[4]:
                    craftinghandler.removeOutput_player(self.master)
                #print("[DEBUG] carry item")
            elif button == pyglet.window.mouse.MIDDLE and self.master.gamemode == 1:
                slot = self.getPress(x, y)
                if slot != None:
                    slot.amount = slot.item.getMaxStackSize()
        else:
            x, y = x - 20, y + 3
            if button == pyglet.window.mouse.LEFT:
                slot = self.getPress(x+10, y+10)
                if self.slot_moving != None:
                    if slot == None or slot.mode == "o":
                        self.slot_moving.setPos(*self.slot_moving_start)
                    elif slot.item != None and self.slot_moving.item and slot.item.getName() == self.slot_moving.item.getName() and slot.mode != "o":
                        if slot.amount + self.slot_moving.amount > slot.item.getMaxStackSize():
                            oa = slot.amount
                            slot.amount = slot.item.getMaxStackSize()
                            self.slot_moving.amount -= oa
                            if slot in self.crafting_in:
                                craftinghandler.check_player(self.master)
                            elif slot in self.crafting_in:
                                craftinghandler.check_player(self.master)
                            return
                        else:
                            slot.amount = slot.amount + self.slot_moving.amount
                            self.slot_moving.setItem(None)
                            self.slot_moving.setPos(*self.slot_moving_start)
                        if slot in self.crafting_in:
                            craftinghandler.check_player(self.master)
                    else:
                        item = slot.item; amount = slot.amount
                        slot.setItem(self.slot_moving.item, self.slot_moving.amount)
                        self.slot_moving.setItem(item, amount)
                        self.slot_moving.setPos(self.slot_moving_start[0], self.slot_moving_start[1])
                        if slot in self.crafting.slots:
                            craftinghandler.check_player(self.master)
                    self.slot_moving = None
                self.ismovingItem = False
            elif button == pyglet.window.mouse.RIGHT:
                slot = self.getPress(x+10, y+10)
                if self.slot_moving != None:
                    if slot == None or slot.mode == "o":
                        return
                    elif slot.item != None and slot.item.getName() == self.slot_moving.item.getName() and slot.mode != "o":
                        if slot.amount + 1 <= slot.item.getMaxStackSize():
                            slot.amount += 1
                            self.slot_moving.amount -= 1
                            if self.slot_moving.amount == 0:
                                self.ismovingItem = False
                                self.slot_moving.setItem(None)
                                self.slot_moving.setPos(*self.slot_moving_start)
                        if slot in self.crafting_in:
                            craftinghandler.check_player(self.master)
                    else:
                        slot.setItem(self.slot_moving.item)
                        slot.amount = 1
                        self.slot_moving.amount -= 1
                        if self.slot_moving.amount == 0:
                            self.ismovingItem = False
                            self.slot_moving.setItem(None)
                            self.slot_moving.setPos(*self.slot_moving_start)
                    
            

    def on_mouse_release(self, x, y, button, modifiers):
        pass

    def getPress(self, x, y):
        self.scor = {}
        for e in invhandler.shown:
            for e in invhandler.inventoryinst[e].slots:
                self.scor[(e.x, e.y)] = e

        slothigh, slotwight = 50, 40

        for xa, ya in self.scor.keys():
            if x >= xa and x <= xa + slotwight and y >= ya and y <= ya + slothigh and self.scor[(xa, ya)] != self.slot_moving:
                return self.scor[(xa, ya)]


    def on_shift(self):
        (mx, my) = self.master.window.mousepos
        slot = self.getPress(mx, my)
        if slot != None and slot.item != None:
            if slot in self.hotbar_slots:
                flag = self.master.addToFreePlace(slot.item.getName(), amount=slot.amount, start=9)
            else:
                flag = self.master.addToFreePlace(slot.item.getName(), amount=slot.amount)
            if flag:
                slot.setItem(None)
            
