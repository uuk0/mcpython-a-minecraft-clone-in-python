from moduls import *

from oredictnames import *

import Item

from crafting import craftinghandler

class player:
    def __init__(self, window):
        self.inventory = PlayerInventory(window, self)
        self.mode = 1 #0:nichts, 1:hotbar, 2:survival_inventory, 3:creativ_inventory, 4: creativ_tab [self.creativ_tab_id]
        self.gamemode = 0 #0:surivival, 1:creativ, 2:hardcore, 3:spectator
        self.falling = False
        self.fallhigh = 0
        self.harts = 10
        self.window = window
        self.creativ_tab_id = None

    def draw(self):
        self.inventory.draw()

    def addToFreePlace(self, name, amount=1, start=0):
        item = Item.handler.getClass(name)
        if item == None: return False
        if start < 9:
            for place in self.inventory.hotbar_slots[start:]:
                if (place.item == None or place.item.getName() == name) and (place.item == None or place.item.getMaxStackSize() - amount + 1 > place.amount):
                    if place.item == None:
                        if place.setItem(Item.handler.getClass(name)()):
                            return True
                    else:
                        place.amount += amount
                        return True
        for p in self.inventory.rows:
            for place in p:
                if (place.item == None or place.item.getName() == name) and (place.item == None or place.item.getMaxStackSize() - amount + 1 > place.amount):
                    if place.item == None:
                        if place.setItem(Item.handler.getClass(name)()):
                            return True
                    else:
                        place.amount += amount
                        return True
        return False

    def setPlace(self, id, name):
        if id < 9:
            self.inventory.hotbar_slots[
                id].setItem(Item.handler.getClass(name)())
        elif id < 18:
            self.inventory.rows[0][
                id - 9].setItem(Item.handler.getClass(name)())
        elif id < 27:
            self.inventory.rows[1][
                id - 18].setItem(Item.handler.getClass(name)())
        elif id < 36:
            self.inventory.rows[2][
                id - 27].setItem(Item.handler.getClass(name)())
        elif id < 40:
            self.inventory.armor[
                id - 36].setItem(Item.handler.getClass(name)())
        elif id < 44:
            self.inventory.crafting_in[id - 40].setItem(Item.handler.getClass(name)())
        elif id < 45:
            self.inventory.crafting_out[id - 44].setItem(Item.handler.getClass(name)())
        elif id < 46:
            self.inventory.offhand[id - 45].setItem(Item.handler.getClass(name)())
        else:
            print("[ERROR] no place found id="+str(id))

    def getPlace(self, id):
        if id < 9:
            return self.inventory.hotbar_slots[
                id].item
        elif id < 18:
            return self.inventory.rows[0][
                id - 9].item
        elif id < 27:
            return self.inventory.rows[1][
                id - 18].item
        elif id < 36:
            return self.inventory.rows[2][
                id - 27].item
        elif id < 40:
            return self.inventory.armor[
                id - 36].item
        elif id < 44:
            return self.inventory.crafting_in[id - 40].item
        elif id < 45:
            return self.inventory.crafting_out[id - 44].item
        elif id < 46:
            return self.inventory.offhand[id - 45].item
        else:
            print("[ERROR] no place found id="+str(id))
            
    def getSlot(self, id):
        if id < 9:
            return self.inventory.hotbar_slots[
                id]
        elif id < 18:
            return self.inventory.rows[0][
                id - 9]
        elif id < 27:
            return self.inventory.rows[1][
                id - 18]
        elif id < 36:
            return self.inventory.rows[2][
                id - 27]
        elif id < 40:
            return self.inventory.armor[
                id - 36]
        elif id < 44:
            return self.inventory.crafting_in[id - 40]
        elif id < 45:
            return self.inventory.crafting_out[id - 44]
        elif id < 46:
            return self.inventory.offhand[id - 45]
        else:
            print("[ERROR] no place found id="+str(id))

    def update(self):
        if self.harts == 0 and self.gamemode != 3 and self.gamemode != 1:
            self.window.kill("player hearts go down")

class Slot:
    def __init__(self, x, y, oredictallow=None, mode="a"):
        self.image = None
        self.item = None
        self.x = x
        self.y = y
        self.amount = 0
        self.oredictallow = oredictallow
        if self.oredictallow != None and type(self.oredictallow) != list:
            self.oredictallow = [self.oredictallow]
        self.amountlabel = pyglet.text.Label('', font_name='Arial', font_size=10,
            x=self.x + 53, y=self.y - 3, anchor_x='left', anchor_y='top',
            color=(0, 0, 0, 255))
        self.mode = mode

    def setItem(self, item, amount=1):
        if item == None:
            self.image = None
            self.amount = 0
        else:
            if type(item) == str:
                item = Item.handler.getClass(item)()
            if self.oredictallow != None:
                flag = False
                for e in self.oredictallow:
                    if e in item.getOreDictNames():
                        flag = True
                if not flag:
                    print("[ERROR] try to add a item that is not definited to inventory")
                    return False
            self.image = pyglet.sprite.Sprite(
                        pyglet.image.load(item.getTexturFile()))
            self.image.x = self.x
            self.image.y = self.y
            self.image.scale = 0.25
        self.item = item
        self.amount = amount
        if item == None:
            self.amount = 0
        return True

    def draw(self):
        if self.image != None:
            self.image.draw()
            self.amountlabel.x = self.x + 33
            self.amountlabel.y = self.y + 2
            self.amountlabel.text = str(self.amount)
            self.amountlabel.draw()

    def setPos(self, x, y):
        self.x = x
        self.y = y
        if self.image != None:
            self.image.x = x
            self.image.y = y

    def getData(self):
        return (self.item, self.amount)

    def setAmount(self, amount):
        if amount == 0:
            self.setItem(None)
        else:
            self.amount = amount

    def getDestroyHardness(self):
        if self.item == None:
            return 1
        else:
            return self.item.getToolHardness()

class PlayerInventory:
    def __init__(self, window, master):
        self.window = window; self.master = master
        self.img1 = pyglet.sprite.Sprite(
            pyglet.image.load("./texturs/inventory_clear.png"))
        self.img2 = pyglet.sprite.Sprite(
            pyglet.image.load("./texturs/hotbar_image.png"))
        self.img3 = pyglet.sprite.Sprite(
            pyglet.image.load("./texturs/gui/container/creative_inventory/tab_inventory.png"))

        y = 27

        self.hotbar_slots = [Slot(197, y), Slot(239, y), Slot(281, y), Slot(323, y), Slot(365, y),
                             Slot(407, y), Slot(449, y), Slot(491, y), Slot(533, y)]

        y = 76
        self.rows = [[Slot(197, y), Slot(239, y), Slot(281, y), Slot(323, y), Slot(365, y),
                      Slot(407, y), Slot(449, y), Slot(491, y), Slot(533, y)]]

        y = 120
        self.rows.append([Slot(197, y), Slot(239, y), Slot(281, y), Slot(323, y), Slot(365, y),
                      Slot(407, y), Slot(449, y), Slot(491, y), Slot(533, y)])

        y = 164
        self.rows.append([Slot(197, y), Slot(239, y), Slot(281, y), Slot(323, y), Slot(365, y),
                      Slot(407, y), Slot(449, y), Slot(491, y), Slot(533, y)])

        self.armor = [Slot(197, 210, oredictallow=OreDict.ARMOR_FOOT),
                      Slot(197, 250, oredictallow=OreDict.ARMOR_LEG),
                      Slot(197, 291, oredictallow=OreDict.ARMOR_BODY),
                      Slot(197, 333, oredictallow=OreDict.ARMOR_HEAD)]
        self.crafting_in = [Slot(406, 312),
                            Slot(448, 312),
                            Slot(406, 270),
                            Slot(448, 270)]
        self.crafting_out = [Slot(531, 287, mode="o")]
        self.offhand = [Slot(354, 210)]
        self.slot_moving = None
        self.slot_moving_pos = (0, 0)
        self.slot_moving_start = (0, 0)
        self.scor = {}
        for e in self.hotbar_slots + self.rows[0] + self.rows[1] + self.rows[2] + self.armor + self.crafting_in + self.crafting_out + self.offhand:
            self.scor[(e.x, e.y)] = e
        self.ismovingItem = False

    def draw(self):
        if self.master.mode == 3:
            self.img3.x = 180
            self.img3.y = 10
            self.img3.draw()
        if self.master.mode == 2:
            self.img1.x = 180
            self.img1.y = 10
            self.img1.draw()
        elif self.master.mode == 1:
            #if self.master.gamemode != 1:
            self.img2.x = 180
            self.img2.y = 10
            self.img2.draw()
        elif self.master.mode != 0 and self.master.mode != 3:
            print("[ERROR] unknown inventory-mode "+str(self.master.mode))
            raise RuntimeError()
        if self.master.mode != 0:
            for e in self.hotbar_slots:
                e.draw()
        if self.master.mode == 2 or self.master.mode == 3:
            for r in self.rows:
                for e in r:
                    e.draw()
        if self.master.mode == 2:
            for e in self.armor:
                e.draw()
            for e in self.crafting_in + self.crafting_out + self.offhand:
                e.draw()

    def on_mouse_drag(self, x, y, dx, dy, buttons, modifiers):
        pass
    """
        if self.slot_moving == None: return
        self.slot_moving.setPos(x + dx, y + dy)
        slot = self.slot_moving
        self.slot_moving_pos = (slot.x, slot.y,)"""

    def on_mouse_press(self, x, y, button, modifiers):
        if not self.ismovingItem:
            x, y = x - 20, y + 3
            if button == pyglet.window.mouse.LEFT:
                slot = self.getPress(x, y)
                if slot != None:
                    self.slot_moving = slot
                    self.slot_moving_pos = (slot.x, slot.y,)
                    self.slot_moving_start = (slot.x, slot.y,)
                else:
                    self.slot_moving = None
                self.ismovingItem = True
                if slot in self.crafting_out:
                    craftinghandler.removeOutput_player(self.master)
                #print("[DEBUG] carry item")
            elif button == pyglet.window.mouse.MIDDLE and self.master.gamemode == 1:
                slot = self.getPress(x, y)
                if slot != None:
                    slot.amount = slot.item.getMaxStackSize()
        else:
            x, y = x - 20, y + 3
            if button == pyglet.window.mouse.LEFT:
                slot = self.getPress(x+10, y+10)
                if self.slot_moving != None:
                    if slot == None or slot.mode == "o":
                        self.slot_moving.setPos(*self.slot_moving_start)
                    elif slot.item != None and slot.item.getName() == self.slot_moving.item.getName() and slot.mode != "o":
                        if slot.amount + self.slot_moving.amount > slot.item.getMaxStackSize():
                            oa = slot.amount
                            slot.amount = slot.item.getMaxStackSize()
                            self.slot_moving.amount -= oa
                            if slot in self.crafting_in:
                                craftinghandler.check_player(self.master)
                            return
                        else:
                            slot.amount = slot.amount + self.slot_moving.amount
                            self.slot_moving.setItem(None)
                            self.slot_moving.setPos(*self.slot_moving_start)
                        if slot in self.crafting_in:
                            craftinghandler.check_player(self.master)
                    else:
                        item = slot.item; amount = slot.amount
                        slot.setItem(self.slot_moving.item, self.slot_moving.amount)
                        self.slot_moving.setItem(item, amount)
                        self.slot_moving.setPos(self.slot_moving_start[0], self.slot_moving_start[1])
                        if slot in self.crafting_in:
                            craftinghandler.check_player(self.master)
                    self.slot_moving = None
                self.ismovingItem = False
            elif button == pyglet.window.mouse.RIGHT:
                slot = self.getPress(x+10, y+10)
                if self.slot_moving != None:
                    if slot == None or slot.mode == "o":
                        return
                    elif slot.item != None and slot.item.getName() == self.slot_moving.item.getName() and slot.mode != "o":
                        if slot.amount + 1 <= slot.item.getMaxStackSize():
                            slot.amount += 1
                            self.slot_moving.amount -= 1
                            if self.slot_moving.amount == 0:
                                self.ismovingItem = False
                                self.slot_moving.setItem(None)
                                self.slot_moving.setPos(*self.slot_moving_start)
                        if slot in self.crafting_in:
                            craftinghandler.check_player(self.master)
                    else:
                        slot.setItem(self.slot_moving.item)
                        slot.amount += 1
                        self.slot_moving.amount -= 1
                        if self.slot_moving.amount == 0:
                            self.ismovingItem = False
                            self.slot_moving.setItem(None)
                            self.slot_moving.setPos(*self.slot_moving_start)
                    
            

    def on_mouse_release(self, x, y, button, modifiers):
        pass

    def getPress(self, x, y):
        slothigh, slotwight = 50, 40

        for xa, ya in self.scor.keys():
            if x >= xa and x <= xa + slotwight and y >= ya and y <= ya + slothigh and self.scor[(xa, ya)] != self.slot_moving:
                return self.scor[(xa, ya)]


    def on_shift(self):
        (mx, my) = self.master.window.mousepos
        slot = self.getPress(mx, my)
        if slot != None and slot.item != None:
            if slot in self.hotbar_slots:
                flag = self.master.addToFreePlace(slot.item.getName(), amount=slot.amount, start=9)
            else:
                flag = self.master.addToFreePlace(slot.item.getName(), amount=slot.amount)
            if flag:
                slot.setItem(None)
            
