from Blocks import *
blockhandler = handler
from Item import *
itemhandler = handler
from oredictnames import *
import Inventorys

class Grid:
    crafting_1x1 = "mcpython:interfaceses:crafting:1x1"
    crafting_2x2 = "mcpython:interfaceses:crafting:2x2"
    crafting_2x1 = "mcpython:interfaceses:crafting:2x1"
    crafting_1x2 = "mcpython:interfaceses:crafting:1x2"
    crafting_3x3 = "mcpython:interfaceses:crafting:3x3"
    crafting_3x2 = "mcpython:interfaceses:crafting:3x2"
    crafting_3x1 = "mcpython:interfaceses:crafting:3x1"
    crafting_2x3 = "mcpython:interfaceses:crafting:2x3"
    crafting_1x3 = "mcpython:interfaceses:crafting_1x3"
    crafting_smelting = "mcpython:interfaceses:smelting:1to1"

class Recipi:
    def __init__(self, grid, input, output, inputamount, outputamount, *args, **kwargs):
        self.grid = grid
        self.input = input
        self.inputamount = inputamount
        self.output = output
        self.outputamount = outputamount
        self.args = args
        self.kwargs = kwargs

        craftinghandler.register(self)

class craftinghandler:
    def __init__(self):
        self.recipis = {}
        for e in Grid.__dict__.values():
            self.recipis[e] = []
        self.nrecipi = None
        self.nrecipislots = []

    def register(self, recipi):
        if not recipi.grid in self.recipis.keys():
            print("[ERROR] try to register a recipi in an unknown grid")
        self.recipis[recipi.grid].append(recipi)

    def check_player(self, player):
        self.updateOutput_player(player)

    def removeOutput_player(self, player):
        if not self.nrecipi:
            print("[ERROR] during removing output: no recipi found")
            return
        if self.nrecipi.grid == Grid.crafting_1x1:
            player.inventory.crafting.slots[self.nrecipislots[0]].amount -= self.nrecipi.inputamount[0]
        elif self.nrecipi.grid == Grid.crafting_2x2:
            player.inventory.crafting.slots[self.nrecipislots[0]].amount -= self.nrecipi.inputamount[0]
            player.inventory.crafting.slots[self.nrecipislots[1]].amount -= self.nrecipi.inputamount[1]
            player.inventory.crafting.slots[self.nrecipislots[2]].amount -= self.nrecipi.inputamount[2]
            player.inventory.crafting.slots[self.nrecipislots[3]].amount -= self.nrecipi.inputamount[3]
        elif self.nrecipi.grid == Grid.crafting_1x2 or self.nrecipi.grid == Grid.crafting_2x1:
            Inventorys.handler.inventoryslotsinst[self.nrecipislots[0]].amount -= self.nrecipi.inputamount[0]
            Inventorys.handler.inventoryslotsinst[self.nrecipislots[1]].amount -= self.nrecipi.inputamount[1]
    
    def updateOutput_player(self, player):
        inv = player.inventory.crafting
        for c in self.recipis[Grid.crafting_1x1]:
            for i, s in enumerate(inv.slots[:4]):
                if (s.item and s.item.getName() == c.input[0] and s.amount >= c.inputamount[0]) or (c.input[0] == None and not s.item):
                    flag = True
                    for s1 in inv.slots[:i] + inv.slots[i+1:4]:
                        if s1.item:
                            flag = False
                    if flag:
                        self.nrecipi = c
                        self.nrecipislots = [i]
                        inv.slots[4].setItem(c.output[0])
                        inv.slots[4].amount = c.outputamount[0]
                        return
        for c in self.recipis[Grid.crafting_2x2]:
            flag = True
            for i, s in enumerate(inv.slots[:4]):
                if not (s.item and s.item.getName() == c.input[i] and s.amount >= c.inputamount[i]):
                    if not s.item or not c.input[i] in s.item.getOreDictNames():
                        flag = False
            if flag:
                self.nrecipi = c
                self.nrecipislots = [0, 1, 2, 3]
                inv.slots[4].setItem(c.output[0])
                inv.slots[4].amount = c.outputamount[0]
                return
        for c in self.recipis[Grid.crafting_2x1]:
            for sl in [inv.slots[:2], inv.slots[2:]]:
                flag = True
                for i, s in sl:
                    if not (s.item and s.item.getName() == c.input[i] and s.amount >= c.inputamount[i]):
                        if not s.item or not c.input[i] in s.item.getOreDictNames():
                            flag = False
                if flag:
                    self.nrecipi = c
                    self.nrecipislots = [sl[0].id, sl[1].id]
                    inv.slots[4].setItem(c.output[0])
                    inv.slots[4].amount = c.outputamount[0]
                    return
        for c in self.recipis[Grid.crafting_1x2]:
            sll = [[inv.slots[0], inv.slots[2]], [inv.slots[1], inv.slots[3]]]
            for si in (0, 1):
                sl = sll[si]
                flag = True
                for i, s in enumerate(sl):
                    if not (s.item and s.item.getName() == c.input[i] and s.amount >= c.inputamount[i]):
                        if not s.item or not c.input[i] in s.item.getOreDictNames():
                            flag = False
                if flag:
                    self.nrecipi = c
                    self.nrecipislots = [sl[0].id, sl[1].id]
                    inv.slots[4].setItem(c.output[0])
                    inv.slots[4].amount = c.outputamount[0]
                    return

        self.nrecipi = None
        self.nrecipislots = []
        inv.slots[4].setItem(None)


craftinghandler = craftinghandler()


Recipi(Grid.crafting_1x1, ["minecraft:wood_log_0"], ["minecraft:wood_plank_1"], [1], [4])
Recipi(Grid.crafting_1x1, ["minecraft:wood_log_1"], ["minecraft:wood_plank_2"], [1], [4])
Recipi(Grid.crafting_1x1, ["minecraft:wood_log_2"], ["minecraft:wood_plank_0"], [1], [4])

Recipi(Grid.crafting_1x1, ["minecraft:grass"], ["minecraft:dirt"], [1], [1])

Recipi(Grid.crafting_2x2, [OreDict.WOOD_PLANK] * 4, ["minecraft:crafting_table"], [1] * 4, [1])
Recipi(Grid.crafting_2x2, ["minecraft:stone"] * 4, ["minecraft:stone_brick"], [1] * 4, [4])
Recipi(Grid.crafting_2x2, ["minecraft:sand"] * 4,  ["minecraft:sandstone"], [1] * 4, [4])

for e in ["diamond", "gold", "iron"]:
    Recipi(Grid.crafting_1x1, ["minecraft:"+e+"_block"], ["minecraft:"+e], [1], [9])
for e in ["gold", "iron"]:
    Recipi(Grid.crafting_1x1, ["minecraft:"+e], ["minecraft:"+e+"_nugget"], [1], [9])

Recipi(Grid.crafting_1x2, [OreDict.WOOD_PLANK] * 2, ["minecraft:stick"], [1, 1], [4])

Recipi(Grid.crafting_3x3, ["minecraft:cobblestone", "minecraft:cobblestone", "minecraft:cobblestone",
                           "minecraft:cobblestone", None,                    "minecraft:cobblestone",
                           "minecraft:cobblestone", "minecraft:cobblestone", "minecraft:cobblestone"],
       "minecraft:furnes", [1]*9, [1])