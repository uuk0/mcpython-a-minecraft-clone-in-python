from Block import handler as blockhandler
from Item  import handler as itemhandler

class Grid:
    crafting_1x1 = "mcpython:interfaceses:crafting:1x1"
    crafting_2x2 = "mcpython:interfaceses:crafting:2x2"
    crafting_2x1 = "mcpython:interfaceses:crafting:2x1"
    crafting_1x2 = "mcpython:interfaceses:crafting:1x2"

class Recipi:
    def __init__(self, grid, input, output, inputamount, outputamount):
        self.grid = grid
        self.input = input
        self.inputamount = inputamount
        self.output = output
        self.outputamount = outputamount

        craftinghandler.register(self)

class craftinghandler:
    def __init__(self):
        self.recipis = {}
        for e in Grid.__dict__.values():
            self.recipis[e] = []
        self.nrecipi = None

    def register(self, recipi):
        if not recipi.grid in self.recipis.keys():
            print("[ERROR] try to register a recipi in an unknown grid")
        self.recipis[recipi.grid].append(recipi)

    def check_player(self, player):
        inv = player.inventory
        crafting = inv.crafting_in
        #print(self.recipis)
        
        for e in self.recipis[Grid.crafting_1x1]:
            for p in crafting:
                if p.item != None and p.item.getName() == e.input[0] and e.inputamount[0] >= p.amount:
                    self.nrecipi = e
                    self.updateOutput_player(player)
                    return
        for e in self.recipis[Grid.crafting_2x2]:
            flag = True
            for i, p in crafting:
                if p.item == None or not (p.item.getName() == e.input[i] and e.inputamount[i] >= p.amount):
                    flag = False
            if flag:
                self.nrecipi = e
                self.updateOutput_player(player)
                return
        for e in self.recipis[Grid.crafting_2x1]:
            c = [[crafting[0], crafting[1]], [crafting[2], crafting[3]]]
            for c0 in c:
                flag = True
                for c in c0:
                    if p.item == None or not (p.item.getName() == e.input[i] and e.inputamount[i] >= p.amount):
                        flag = False
                if flag:
                    self.nrecipi = e
                    self.updateOutput_player(player)
                    return
        for e in self.recipis[Grid.crafting_2x1]:
            c = [[crafting[0], crafting[2]], [crafting[1], crafting[3]]]
            for c0 in c:
                flag = True
                for c in c0:
                    if p.item == None or not (p.item.getName() == e.input[i] and e.inputamount[i] >= p.amount):
                        flag = False
                if flag:
                    self.nrecipi = e
                    self.updateOutput_player(player)
                    return
        self.nrecipi = None
        self.updateOutput_player(player)

    def removeOutput_player(self, player):
        inv = player.inventory
        crafting = inv.crafting_in
        for e in self.recipis[Grid.crafting_1x1]:
            for p in crafting:
                if p.item != None and p.item.getName() == e.input[0] and e.inputamount[0] >= p.amount:
                    self.nrecipi = e
                    self._removeOutput_player(player, [p])
                    return
        for e in self.recipis[Grid.crafting_2x2]:
            flag = True
            for i, p in crafting:
                if p.item == None or not (p.item.getName() == e.input[i] and e.inputamount[i] >= p.amount):
                    flag = False
            if flag:
                self.nrecipi = e
                self._removeOutput_player(player, crafting)
                return
        for e in self.recipis[Grid.crafting_2x1]:
            c = [[crafting[0], crafting[1]], [crafting[2], crafting[3]]]
            for c0 in c:
                flag = True
                for c in c0:
                    if p.item == None or not (p.item.getName() == e.input[i] and e.inputamount[i] >= p.amount):
                        flag = False
                if flag:
                    self.nrecipi = e
                    self._removeOutput_player(player, c0)
                    return
        for e in self.recipis[Grid.crafting_2x1]:
            c = [[crafting[0], crafting[2]], [crafting[1], crafting[3]]]
            for c0 in c:
                flag = True
                for c in c0:
                    if p.item == None or not (p.item.getName() == e.input[i] and e.inputamount[i] >= p.amount):
                        flag = False
                if flag:
                    self.nrecipi = e
                    self._removeOutput_player(player, c0)
                    return

    def _removeOutput_player(self, player, gridplaces):
        if self.nrecipi == None: return
        for i, e in enumerate(self.nrecipi.inputamount):
            gridplaces[i].amount -= e
            if gridplaces[i].amount == 0:
                gridplaces[i].setItem(None)
    
    def updateOutput_player(self, player):
        if self.nrecipi == None:
            player.inventory.crafting_out[0].setItem(None)
        else:
            player.inventory.crafting_out[0].setItem(self.nrecipi.output[0])
            player.inventory.crafting_out[0].amount = self.nrecipi.outputamount[0]

craftinghandler = craftinghandler()


Recipi(Grid.crafting_1x1, ["minecraft:wood_log_0"], ["minecraft:wood_plank_1"], [1], [4])
Recipi(Grid.crafting_1x1, ["minecraft:wood_log_1"], ["minecraft:wood_plank_2"], [1], [4])
Recipi(Grid.crafting_1x1, ["minecraft:wood_log_2"], ["minecraft:wood_plank_0"], [1], [4])

Recipi(Grid.crafting_1x1, ["minecraft:grass"], ["minecraft:dirt"], [1], [1])
