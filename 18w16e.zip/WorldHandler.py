#from old_worldhandler import *
import biomes

class World:
    def __init__(self, model, seed, type, subtypes=[]):
        self.model = model
        self.seed = seed
        self.type = type
        self.subtypes = subtypes
        self.biomes = []

    def generateChunk(self, x, z):
        if self.type == "0":
            if self.subtypes[0] == "0":
                biome = biomes.FlatBiomeSandstone([], self.seed)
                for ix in range(-8, 9):
                    for iz in range(-8, 9):
                        biome.poslist.append([x+ix, z+iz])
                self.biomes.append(biome)
                biome.GenerateBiome(self.model)
            elif self.subtypes[0] == "1":
                biome = biomes.FlatBiomeDirt([], self.seed)
                for ix in range(-8, 9):
                    for iz in range(-8, 9):
                        biome.poslist.append([x+ix, z+iz])
                self.biomes.append(biome)
                biome.GenerateBiome(self.model)
        elif self.type == "1":
            biome = biomes.BaseBiome([], self.seed)
            for ix in range(-8, 9):
                for iz in range(-8, 9):
                    biome.poslist.append([x + ix, z + iz])
            self.biomes.append(biome)
            biome.GenerateBiome(self.model)

