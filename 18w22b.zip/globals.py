
window = None
model = None
player = None
inventoryhandler = None