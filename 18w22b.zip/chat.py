import Item, Blocks, entity
from moduls import *

import pyperclip, structures, pickle

from pyglet.window import key

from crafting import craftinghandler

import WorldHandler

from Inventorys.Inventory import handler as invhandler

from mathhelper import *

from constans import *

import WorldSaver, config

import crafting

from EventHandler import eventhandler

import pyglet.window.key
import globals as G
import entity, math, random

KeyToValue = {key.A:"a", key.B:"b", key.C:"c", key.D:"d", key.E:"e", key.F:"f", key.G:"g", key.H:"h", key.I:"i",
              key.J:"j", key.K:"k", key.L:"l", key.M:"m", key.N:"n", key.O:"o", key.P:"p", key.Q:"q", key.R:"r",
              key.S:"s", key.T:"t", key.U:"u", key.V:"v", key.W:"w", key.X:"x", key.Y:"y", key.Z:"z", key._0:"0",
              key._1:"1", key._2:"2", key._3:"3", key._4:"4", key._5:"5", key._6:"6", key._7:"7", key._8:"8",
              key._9:"9", key.COMMA:",", key.MINUS:"-", key.PLUS:"+", key.SPACE:" ", key.PLUS:"+", key.MINUS:"-",
              46:".", 35:"#", 60:"<", 949187772416:"´"}

Upper = {"1":"!", "2":"\"", "3":"§", "4":"$", "5":"%", "6":"&", "7":"/",
         "8":"(", "9":")", "0":"=", "+":"*", "-":"_", ",":";", ".":":",
         "#":"'", "<":">", "´":"`"}

AltGr = {"2":"²", "3":"³", "7":"{", "8":"[", "9":"]", "0":"}", "q":"@", "e":"€", "m":"µ", "+":"~",
         "<":"|"}

PlayerRegister = {}

def register():
    PlayerRegister = {config.CONFIGS["PLAYER_NAME"]:G.player.model}

def getSelector(text, pos, entity):
    if text == "@s":
        return [entity]
    elif text == "@p":
        n = [None, None]
        for e in PlayerRegister.values():
            dx = e.position[0] - pos[0]
            dy = e.position[1] - pos[1]
            dz = e.position[2] - pos[2]
            if dx < 0:
                dx = -dx
            if dy < 0:
                dy = -dy
            if dz < 0:
                dz = -dz
            d = math.sqrt(dx * dx + dy * dy + dz * dz)
            if n[0] == None or d < n[0]:
                n = [d, e]
        if n == [None, None] or n[0] > d:
            return []
        return n[1]
    elif text == "@a":
        return PlayerRegister.values()
    elif text == "@r":
        return random.choice(PlayerRegister.values())

class chat:
    def __init__(self):
        self.chat = []
        self.opened = False
        self.window = None
        self.chattext = ""
        self.commandhistory = []
        self.commandhistoryindex = -1

    def printIn(self, msg):
        self.chat.append(msg)
        if len(self.chat) > 100:
            chat.pop(0)
        print("[CHAT] "+msg)

    def warn(self, msg):
        print("[CHAT/WARNING] "+msg)

    def open(self):
        self.opened = True

    def addKey(self, symbol, mod):
        if symbol == key.BACKSPACE:
            self.chattext = self.chattext[:-1]
        elif symbol == key.ENTER:
            self.execute(self.chattext, G.window.position, G.player.model)
            self.chattext = ""
            self.opened = False
            self.commandhistory.append(self.chattext)
            G.window.set_menü("game")
        elif mod & key.MOD_CTRL and symbol == key.C:
            pyperclip.copy(self.chattext)
            print("copiing...")
        elif mod & key.MOD_CTRL and symbol == key.V:
            self.chattext += pyperclip.paste()
            print("pasting....")
        elif symbol in KeyToValue.keys():
            value = KeyToValue[symbol]
            if mod & key.MOD_SHIFT:
                if value in Upper.keys():
                    value = Upper[value]
                else:
                    value = value.upper()
            elif mod & key.MOD_CTRL:
                value = AltGr[value]
            self.chattext += value
        else:
            f = open("./exceptions.txt", mode="a")
            f.write("\nunknown key found: "+str(symbol)+":"+str(mod)+"\n")
            f.close()

    def draw(self):
        self.window.chatlabel.text = self.chattext
        self.window.chatlabel.draw()

    def execute(self, msg, pos, entity):
        if msg[0] != "/":
            self.printIn(msg)
            return
        splitted = msg.split(" ")
        #fehlt: datapack, function, locate, reload, scoreboard, me, say, tellraw, advancement, bossbar, data, effect, enchant, execute, experience, particel, playsound, recipi, scoreboard, spreadplayers, stopsound, tag, team
        if splitted[0] == "/debug":
            config.CONFIGS["debug"] = not config.CONFIGS["debug"]
        elif splitted[0] == "/help":
            self.printIn("[FEATURE] not implemented: /help")
        elif splitted[0] == "/seed":
            self.printIn(G.window.world.seed)
        elif (splitted[0] == "/msg" or splitted[0] == "/tell" or splitted[0] == "/w") and G.window.world.hubtype == 2 or G.window.world.hubtype == 3:
            player = getSelector(splitted[1], pos, entity)
            if hasattr(player, "writeToChat") and callable(player.writeToChat):
                player.writeToChat(splitted[2])
        elif splitted[0] == "/clear":
            if len(splitted) > 1:
                player = getSelector(splitted[1], pos, entity)
            else:
                player = getSelector("@s", pos, entity)
            for player in player[:]:
                if hasattr(player, "inst"):
                    player = player.getInst().inventory
                    for e in player.hotbar.slots + player.rows.slots + player.armor.slots + player.crafting.slots:
                        e.setItem(None)
        elif splitted[0] == "/gamemode":
            id = int(splitted[1])
            if len(splitted) > 2:
                player = getSelector(splitted[2], pos, entity)
            else:
                player = getSelector("@s", pos, entity)
            for player in player[:]:
                if hasattr(player, "inst"):
                    player = player.getInst()
                    player.gamemode = id
        elif splitted[0] == "/give":
            player = getSelector(splitted[1], pos, entity)
            item = Item.handler.getClass(splitted[2])
            if len(splitted) > 3:
                amount = int(splitted[3])
            else:
                amount = 1
            if len(splitted) > 4:
                data = splitted[3]
                item.setStoreData(data)
            for player in player[:]:
                if hasattr(player, "inst"):
                    player = player.getInst()
                    player.addToFreePlace(item, amount=amount)
        elif splitted[0] == "/kill":
            if len(splitted) > 1:
                player = getSelector(splitted[1], pos, entity)
            else:
                player = getSelector("@s", pos, entity)
            for player in player[:]:
                if hasattr(player, "inst"):
                    player.kill()
        elif splitted[0] == "/replaceitem" and (G.window.world.hubtype == 3 or G.window.world.hubtype == 1):
            e = getSelector(splitted[1], pos, entity)
            invs = e.getInventory()
            id = 0
            for invs in invs[:]:
                for i in invs:
                    if id == int(splitted[2]):
                        i.setItem(splitted[3], int(splitted[4]))
                    id += 1
        elif splitted[0] == "/spawnpoint":
            if len(splitted) > 1:
                player = getSelector(splitted[1], pos, entity)
            else:
                player = getSelector("@s", pos, entity)
            for player in player[:]:
                if hasattr(player, "inst"):
                    pos = (int(splitted[1]), int(splitted[2]), int(splitted[3]))
                    player.getInst().window.startpos = pos
                    player.getInst().window.world.spawnpoint = pos
        elif splitted[0] == "/teleport" or splitted[0] == "/tp":
            player = getSelector(splitted[1], pos, entity)
            pos = (int(splitted[2]), int(splitted[3]), int(splitted[4]))
            for player in player[:]:
                player.setPosition(pos)
        else:
            eventhandler.call("on_unknown_command_executed", msg, pos, entity)



"""class chat:
    def __init__(self):
        self.chat = []
        self.opened = False
        self.window = None
        self.text = ""
        self.last_commants = []
        self.command_id = -1

    def printIn(self, msg):
        self.chat.append(msg)
        if len(self.chat) > 100:
            chat.pop(0)
        print("[CHAT] "+msg)

    def warn(self, msg):
        print("[CHAT/WARNING] "+msg)

    def open(self):
        self.opened = True

    def addKey(self, symbol, mod):
        key = pyglet.window.key
        if mod & key.MOD_CTRL and key.C:
            pyperclip.copy(self.text)
            print("copiing...")
        elif mod & key.MOD_CTRL and key.V:
            self.text = pyperclip.paste()
            print("pasting....")
        elif symbol == key.ENTER:
            self.excecute(self.text)
            self.text = ""
            self.window.keyEvent = "window"
            self.opened = False
            self.last_commants.append(self.text)
            self.text = ""
        elif symbol == key.BACKSPACE:
            self.text = self.text[:-1]
        elif symbol == key._7 and (mod & key.MOD_SHIFT):
            self.text += "/"
        elif symbol == key.ESCAPE:
            print("[WARNING] keyhandler does give 'esc'-key to chat.")
        elif symbol == key.MINUS and (mod & key.MOD_SHIFT):
            self.text += "_"
        elif symbol == key.PLUS and (mod & key.MOD_SHIFT):
            self.text += "*"
        elif symbol == key.PLUS and (mod & 108):
            self.text += "~"
        elif symbol == key.MOD_SHIFT:
            return #vorbereitend
        elif symbol == key.UP:
            self.command_id += 1
            if self.command_id == len(self.last_commants):
                self.command_id = len(self.last_commants) - 1
            self.text = self.last_commants[self.command_id]
        elif symbol == key.DOWN:
            self.command_id -= 1
            if self.command_id == -1:
                self.text = ""
            else:
                self.text = self.last_commants[self.command_id]
        else:
            if symbol in KeyToValue.keys():
                k = KeyToValue[symbol]
                if (mod & key.MOD_SHIFT):
                    k = k.upper()
                self.text += k
            else:
                print("[WARN] unknown char key "+str(symbol))

    def draw(self):
        if self.opened:
            self.window.keyEvent = "chat"
        else:
            self.window.keyEvent = "window"
        self.window.chatlabel.text = self.text
        self.window.chatlabel.draw()

    def excecute(self, msg):
        if not self.opened: return
        command = msg
        sc = command.split(" ")
        if command == "/help":
            print("error::not_implemented")
        elif sc[0] == "/give":
            name = str(sc[1])
            amount = 1 if len(sc) == 2 else int(sc[2])
            self.window.player.addToFreePlace(name, amount)
        elif sc[0] == "/clear":
            for s in self.window.player.inventory.hotbar.slots:
                s.setItem(None)
            for s in self.window.player.inventory.rows.slots:
                s.setItem(None)
            for s in self.window.player.inventory.armor.slots:
                s.setItem(None)
            for s in self.window.player.inventory.crafting.slots:
                s.setItem(None)
        elif sc[0] == "/kill":
            self.window.kill("player fell out of the world")
        elif sc[0] == "/gamemode":
            self.window.player.gamemode = int(sc[1])
            if sc[1] == "0" or sc[1] == "2":
                self.window.flying = False
            elif sc[1] == "3":
                self.window.flying = True
        elif sc[0] == "/tp":
            self.window.position = (int(sc[1]), int(sc[2]), int(sc[3]))
        elif sc[0] == "/setblock":
            self.window.model.add_block((int(sc[1]), int(sc[2]), int(sc[3])), sc[4])
        elif sc[0] == "/fill":
            print("filling...")
            sx = int(sc[1]); sy = int(sc[2]); sz = int(sc[3])
            ex = int(sc[4]); ey = int(sc[5]); ez = int(sc[6])
            block = sc[7]
            if sx > ex:
                d = sx
                sx = ex
                ex = d
            if sy > ey:
                d = sy
                sy = ey
                ey = d
            if sz > ez:
                d = sz
                sz = ez
                ez = d
            print(sx, ex, sy, ey, sz, ez)
            for x in range(sx, ex+1):
                for y in range(sy, ey+1):
                    for z in range(sz, ez+1):
                        print(x, y, z)
                        self.window.model.add_block((x, y, z), block, save=False)
        elif sc[0] == "/setPlace":
            amount = 1 if len(sc) == 1 else int(sc[1])
            self.window.player.setPlace(int(sc[1]), sc[2], amount)
        elif sc[0] == "/save":
            self.window.worldname = sc[1] if len(sc) > 0 else self.window.worldname
            WorldSaver.saveWorld(self.window.model, self.window.worldname)
            self.window.worldname = sc[1]
        elif sc[0] == "/change":
            start = int(sc[1])
            end = int(sc[2])
            slotA = self.window.player.getSlot(start).getData()
            slotB = self.window.player.getSlot(end).getData()
            self.window.player.getSlot(end).setItem(slotA[0])
            self.window.player.getSlot(end).setAmount(slotA[1])
            self.window.player.getSlot(start).setItem(slotB[0])
            self.window.player.getSlot(start).setAmount(slotB[1])
        elif sc[0] == "/info":
            vector = self.window.get_sight_vector()
            block, previous = self.window.model.hit_test(self.window.position, vector)
            if block:
                print(self.window.model.world[block].getInfoData())
        elif sc[0] == "/nbtNameInfo":
            vector = self.window.get_sight_vector()
            block, previous = self.window.model.hit_test(self.window.position, vector)
            if block:
                print(self.window.model.world[block].getNBTNames())
        elif sc[0] == "/nbtchange":
            vector = self.window.get_sight_vector()
            block, previous = self.window.model.hit_test(self.window.position, vector)
            if block:
                print(self.window.model.world[block].setNBT(sc[1], config.convertOption(sc[2])))
            self.excecute("/texupdate")
        elif sc[0] == "/nbtread":
            vector = self.window.get_sight_vector()
            block, previous = self.window.model.hit_test(self.window.position, vector)
            if block:
                print(self.window.model.world[block].getNBT(sc[1]))
        elif sc[0] == "/texupdate":
            vector = self.window.get_sight_vector()
            block, previous = self.window.model.hit_test(self.window.position, vector)
            if block:
                print(self.window.model.world[block].generateTEX())
                self.window.model.hide_block(block)
                self.window.model.show_block(block)
        elif sc[0] == "/changeinventory":
            if sc[1] == "1":
                id = int(sc[2])
                x, y = int(sc[3]), int(sc[4])
                slot = self.window.player.getSlot(id)
                slot.setPos(x, y)
        elif sc[0] == "/itemnbtread":
            if self.window.player.inventory.hotbar_slots[self.window.hotbarelement] != None:
                print(self.window.player.inventory.hotbar_slots[self.window.hotbarelement].item.blocknbt,
                      self.window.player.inventory.hotbar_slots[self.window.hotbarelement].item.getName())
        elif sc[0] == "/updatecrafting":
            craftinghandler.check_player(self.window.player)
        elif sc[0] == "/itemnameread":
            try:
                print(self.window.player.inventory.hotbar_slots[self.window.hotbarelement].item.id)
            except:
                print("no item found")
        elif sc[0] == "/getOpenGuis":
            print(invhandler.inventoryinst)
        elif sc[0] == "/resetInventory":
            invhandler.shown = [0]
        elif sc[0] == "/generate":
            sector = sectorize(self.window.position)
            self.window.world.generateChunk(sector[0]*16, sector[2]*16)
        elif sc[0] == "/load":
            self.window.worldname = None
            name = sc[1]
            WorldSaver.loadWorld(self.window.model, name)
            self.window.worldname = name
        elif sc[0] == "/generatechunk":
            sector = (int(sc[1]), int(sc[2]))
            l = WorldHandler.generateChunkA(sector[0] * SECTOR_SIZE, sector[2] * SECTOR_SIZE, (16, 16),
                                            self.window.model)
            for e in l:
                self.window.model.add_block(*e[1:])
        elif sc[0] == "/movecamera":
            self.window.rotation = (int(sc[1]), int(sc[2]))
        elif sc[0] == "/gamerule":
            name = sc[1]
            value = sc[2]
            config.convertOption(value)
            config.CONFIGS[name] = value
        elif sc[0] == "/resetslots":
            for e in invhandler.inventoryslotsinst.keys():
                invhandler.inventoryslotsinst[e].reset()
        elif sc[0] == "/list":
            if len(sc) == 1:
                print("[ERROR] syntax error: command lenght incorrect")
                eventhandler.call("on_unknown_command_executed", sc)
                return
            if sc[1] == "blocks":
                print(Blocks.handler.blocks)
            elif sc[1] == "items":
                print(Item.handler.nametoitem)
            elif sc[1] == "recipis":
                for e in crafting.craftinghandler.recipis.keys():
                    print("recipi "+str(e)+":")
                    for r in crafting.craftinghandler.recipis[e]:
                        print("    Recipi{grid="+str(e)+", inputs="+str(r.input)+str(r.inputamount)+", outputs="+str(r.output)+str(r.outputamount)+", args="+str(r.args)+
                              ", kwargs="+str(r.kwargs)+"}")
            elif sc[1] == "commands":
                self.excecute("/help")
            elif sc[1] == "events":
                print(eventhandler.activecalls)
        elif sc[0] == "/reload":
            shown = self.window.model.shown_sectors[:]
            for e in self.window.model.shown_sectors:
                if e in self.window.model.shown_sectors:
                    self.window.model.hide_sector(e)
            print(shown)
            self.window.model.change_sectors(None, sectorize(self.window.position))
        elif sc[0] == "/savestructur":
            name = sc[1]
            sx = int(sc[2]); sy = int(sc[3]); sz = int(sc[4])
            ex = int(sc[5]); ey = int(sc[6]); ez = int(sc[7])
            copyair = bool(sc[8]) if len(sc) > 8 else False
            if sx > ex:
                d = sx
                sx = ex
                ex = d
            if sy > ey:
                d = sy
                sy = ey
                ey = d
            if sz > ez:
                d = sz
                sz = ez
                ez = d
            if len(sc) > 9:
                rx, ry, rz = int(sc[9]) - sx, int(sc[10]) - sy, int(sc[11]) - sz
            else:
                rx, ry, rz = 0, 0, 0
            commands = []
            for x in range(sx, ex):
                for y in range(sy, ey):
                    for z in range(sz, ez):
                        if not (x, y, z) in self.window.model.world:
                            if copyair:
                                commands.append([1, (x-sx-rx, y-sy-ry, z-sz-rz)])
                        else:
                            commands.append([0, self.window.model.world[(x, y, z)].getName(), (x-sx-rx, y-sy-ry, z-sz-rz)])
                            for e in self.window.model.world[(x, y, z)].getNBTNames():
                                commands.append([1, (x-sx-rx, y-sy-ry, z-sz-rz), e, self.window.model.world[(x, y, z)].getNBT(e)])
            f = open("./assets/structures/"+name+".structur", mode="wb")
            pickle.dump({"version":structures.STRUCTUR_VERSION,
          "size":(ex-sx, ey-sy, ez-sz),
          "blocks":commands,
          "name":name}, f)
            f.close()
        elif sc[0] == "/gamestatechange":
            self.window.set_menü(sc[1])
        elif sc[0] == "/backup":
            name = sc[1] if len(sc) > 1 else self.window.worldname + "_backup_"+str(time.time())
            oname = self.window.worldname
            WorldSaver.saveWorld(self.window.model, name)
            WorldSaver.saveWorld(self.window.model, oname)
        elif sc[0] == "/summon":
            name = sc[1]
            x, y, z, = int(sc[2]), int(sc[3]), int(sc[4])
            self.window.model.add_entity(name, (x, y, z))
        elif sc[0] == "/paststructur":
            name = sc[1]
            x, y, z = int(sc[2]), int(sc[3]), int(sc[4])
            structures.handler.structurs[name].past(self.window.model, x, y, z)
        elif sc[0] == "/time":
            if sc[1] == "set":
                if sc[2] == "day":
                    sc[2] = 100
                elif sc[2] == "night":
                    sc[2] = 1000
                self.window.gametime = int(sc[2])
            elif sc[1] == "add":
                self.window.gametime += int(sc[2])
        else:
            print("[CHAT] "+str(msg))
            eventhandler.call("on_unknown_command_executed", sc)
            self.window.set_menü("game")
            return
        eventhandler.call("on_command_executed", sc)
        self.window.set_menü("game")"""

chat = chat()
