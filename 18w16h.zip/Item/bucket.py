from .Item import *

class Bucket(Item):
    def getName(self):
        return "minecraft:bucket"

    def getTexturFile(self):
        return "./assets/textures/items/bucket.png"

    def on_destroy_with(self, block):
        if block.getName() == "minecraft:water" and self.slot:
            self.slot.setItem("minecraft:water_bucket")

    def getHoldAbleLiquids(self):
        return ["minecraft:water"]

    def getMaxStackSize(self):
        return 16

handler.register(Bucket)

class WaterBucket(Item):
    def getName(self):
        return "minecraft:water_bucket"

    def getTexturFile(self):
        return "./assets/textures/items/water_bucket.png"

    def getLiquidHoldName(self):
        return "minecraft:water"

    def getMaxStackSize(self):
        return 1

handler.register(WaterBucket)

liquidhandler.register(WaterBucket, "minecraft:water")


