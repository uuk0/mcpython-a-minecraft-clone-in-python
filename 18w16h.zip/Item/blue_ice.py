from .Item import *

class BlueIce(Item):
    def getName(self):
        return "minecraft:blue_ice"

    def getTexturFile(self):
        return "./assets/textures/items/blue_ice.png"

handler.register(BlueIce)
