import Blocks, Item, Random

class LootChest:
    def __init__(self, position, randomargs=[]):
        randomargs.append(position)
        self.chest = Blocks.chest(position)
        self.randomargs = randomargs
        for i, e in enumerate(self.getItems()):
            s = self.chest.inv.slots[i]
            s.setItem(e[0], e[1])

    def getItems(self):
        return [] #element: [name, amount]

class StartChest(LootChest):
    def getItems(self):
        return [["minecraft:wood_shovel", 1], ["minecraft:wood_axe", 1], ["minecraft:wood_pick_axe", 1],
                ["minecraft:stick", 4]]