from .Block import *
from oredictnames import OreDict
from destroyGroup import *

class Dirt(Block):
    def getTex(self):
        return tex_coords((0, 1), (0, 1), (0, 1))

    def getName(self):
        return "minecraft:dirt"

    def update(self, model, window):
        (x, y, z) = self.pos
        if not (x, y + 1, z) in model.world:
            model.add_block(self.pos, "minecraft:grass", creat=True, save=False)

    def getOreDictNames(self):
        return [OreDict.DIRT]

    def getDestroyGroups(self):
        return [destroyGroups.SHOVEL]


handler.register(Dirt)
