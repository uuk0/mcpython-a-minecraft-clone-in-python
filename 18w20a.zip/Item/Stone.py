from .Item import *

class Stone(Item):
    def getName(self):
        return "minecraft:stone"

    def getTexturFile(self):
        return "./assets/textures/items/stone.png"

handler.register(Stone)
