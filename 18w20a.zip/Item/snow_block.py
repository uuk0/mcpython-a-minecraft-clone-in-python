from .Item import *

class Snow(Item):
    def getName(self):
        return "minecraft:snow_block"

    def getTexturFile(self):
        return "./assets/textures/items/snow.png"

handler.register(Snow)
