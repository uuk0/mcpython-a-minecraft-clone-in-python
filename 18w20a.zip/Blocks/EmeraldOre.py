from .Block import *

class EmeraldOre(Block):
    def getTex(self):
        return tex_coords((8, 5), (8, 5), (8, 5))

    def getName(self):
        return "minecraft:emerald_ore"

    def getDrop(self, item):
        return "minecraft:emerald_ore"

    def getDropAmount(self, item):
        return 1

    def isBreakAbleWithItem(self, item):
        if item and item.getName() == "minecraft:iron_pick_axe" or item.getName() == "minecraft:diamond_pick_axe":
            return True
        return False

    def getDestroyGroups(self):
        return [destroyGroups.PIKAXE]

handler.register(EmeraldOre)
