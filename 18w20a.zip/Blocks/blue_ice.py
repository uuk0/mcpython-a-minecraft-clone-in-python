from .Block import *

class BlueIce(Block):
    def getTex(self):
        return tex_coords((13, 13), (13, 13), (13, 13))

    def getName(self):
        return "minecraft:blue_ice"

handler.register(BlueIce)
