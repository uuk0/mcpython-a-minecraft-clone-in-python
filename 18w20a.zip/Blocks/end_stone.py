from .Block import *
from oredictnames import OreDict
from destroyGroup import *

class Endstone(Block):
    def getTex(self):
        return tex_coords((12, 12), (12, 12), (12, 12))

    def getName(self):
        return "minecraft:endstone"

    def getDestroyGroups(self):
        return [destroyGroups.PIKAXE]


handler.register(Endstone)

class Endbrick(Block):
    def getTex(self):
        return tex_coords((12, 11), (12, 11), (12, 11))

    def getName(self):
        return "minecraft:endbrick"

    def getDestroyGroups(self):
        return [destroyGroups.PIKAXE]


handler.register(Endbrick)
