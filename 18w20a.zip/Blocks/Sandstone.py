from .Block import *

class Sandstone(Block):
    def getTex(self):
        return tex_coords((2, 2), (2, 2), (2, 2))

    def getName(self):
        return "minecraft:sandstone"

    def getDestroyGroups(self):
        return [destroyGroups.PIKAXE]

handler.register(Sandstone)
