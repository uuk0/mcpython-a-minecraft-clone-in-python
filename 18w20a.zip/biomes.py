import Item, Blocks, Random, structures

class BiomeHandler:
    def __init__(self):
        self.biomes = {}
        self.prefixes = []

    def getBiome(self, name):
        if type(name) == str:
            if name in self.biomes:
                return self.biomes[name]
            for pre in self.prefixes:
                if pre+":"+name in self.biomes:
                    return self.biomes[pre+":"+name]
            return None
        else:
            return name

class Biome:
    def __init__(self, poslist, seed):
        self.poslist = poslist
        self.generated = []
        self.blocked = []
        self.seed = seed

    def getTemperatur(self):
        return None

    def getStructures(self):
        return []

    def getStoneArgs(self): #!
        return ["minecraft:stone"]

    def getHighDiffrents(self, x, z):
        return 0

    def GenerateBiome(self, model):
        hights = model.high_data
        worldsize = (16, 16)
        for p in self.poslist:
            if not p in self.generated:
                #print(p, len(self.poslist))
                #if p in model.high_data.keys():
                    #high = model.high_data[p]
                #else:
                (x, z) = p
                high = self.getHight(model, x, z)
                model.add_block((x, 0, z), "minecraft:bedrock", immediate=False, save=False)
                for y in range(1, 5):
                    if round(Random.randint(model.window.seed, [x, z, high, y]) * 5) == 1:
                        model.add_block((x, y, z), "minecraft:bedrock", immediate=False, save=False)
                    else:
                        model.add_block((x, y, z), self.getMaterial(x, y, z, high), immediate=False, save=False)
                for y in range(5, int(high / 1.5)):
                    if self.hasOre(x, y, z, high):
                        model.add_block((x, y, z), self.getOre(x, y, z), immediate=False, save=False)
                    else:
                        model.add_block((x, y, z), self.getMaterial(x, y, z, high), immediate=False, save=False)
                for y in range(int(high / 1.5), high):
                    model.add_block((x, y, z), self.getMaterial(x, y, z, high), immediate=False, save=False)
                structur = self.getStructur(p, high)
                if structur != None and not (x, z) in self.blocked:
                    while ((x, high-1, z)) not in model.world:
                        high -= 1
                    structur.past(model, x, high, z)
                    for ix in range(x, x+structur.size[0]):
                        for iz in range(z, z+structur.size[1]):
                            self.blocked.append((ix, iz))
                self.generated.append(p)
            else:
                pass
        model.high_data = hights

    def getMaterial(self, x, y, z, high):
        pass

    def getOre(self, x, y, z):
        pass

    def getStructur(self, pos, high):
        return None

    def hasOre(self, x, y, z, high):
        return False

    def getName(self):
        return ""

    def getStartHigh(self):
        return 10

    def getHight(self, model, x, z):
        worldsize = [16, 16]
        hights = model.high_data
        l1 = hights[(x, z - 1)] if z > -worldsize[0] and (x, z - 1) in hights else None
        l2 = hights[(x - 1, z)] if x > -worldsize[0] and (x - 1, z) in hights else None
        l3 = hights[(x + 1, z)] if x < worldsize[0] and (x + 1, z) in hights else None
        l4 = hights[(x, z + 1)] if z < worldsize[0] and (x, z + 1) in hights else None
        if l1 == l2 == l3 == l4 == None:
            y = self.getStartHigh()
        else:
            values = []
            for e in [l1, l2, l3, l4]:
                if e:
                    values.append(e)
            if len(values) == 0:
                y = round(Random.randint(model.window.seed, [x, z, worldsize[0], worldsize[1]]) * 10 + 10)
            else:
                all = 0
                for e in values:
                    all += e
                h = self.getHighDiffrents(x, z)
                y = round(all / len(values)) + (round(
                    Random.randint(model.window.seed, [x, z, worldsize[0], worldsize[
                        1]]) - h if h != 0 else 0))
                if y < 5:
                    y = 5
        model.high_data[(x, z)] = y
        return y

class FlatBiomeSandstone(Biome):
    def getHighDiffrents(self, x, z):
        return 0

    def getMaterial(self, x, y, z, high):
        return "minecraft:sandstone"

    def getTemperatur(self):
        return 0

    def getHight(self, model, x, z):
        return 10

class FlatBiomeDirt(Biome):
    def getHighDiffrents(self, x, z):
        return 0

    def getMaterial(self, x, y, z, high):
        return "minecraft:dirt" if y != high else "minecraft:grass"

    def getTemperatur(self):
        return 0

    def getHight(self, model, x, z):
        return 10

class BaseBiome(Biome):
    def getHighDiffrents(self, x, z):
        return round(Random.randint(self.seed, [x, z, 123]) * 2) - 1 if round(Random.randint(self.seed, [x, z, 0]) * 8) > 4 else 0

    def getTemperatur(self):
        return 1

    def getOre(self, x, y, z):
        return Random.choice(self.seed, [x, y, z], ["minecraft:iron_ore", "minecraft:coal_ore", "minecraft:diamond_ore", "minecraft:gold_ore",
                                                    "minecraft:emerald_ore"])

    def hasOre(self, x, y, z, high):
        r = round(Random.randint(self.seed, [x, y, z, high]) * 10) == 1 and high / 1.5 > y
        return r

    def getMaterial(self, x, y, z, high):
        return "minecraft:stone" if high / 1.5 * Random.randint(self.seed, [x, y, z, high]) > y else ("minecraft:dirt" if y != high-1 else "minecraft:grass")

    def getName(self):
        return "mcpython:biome_base"

    def getStructures(self):
        return ["tree_0"]

    def getStructur(self, pos, high):
        r = round(Random.randint(self.seed, [pos, high]) * 20)
        #print(r)
        if r == 1:
            return structures.handler.structurs["tree_0"]
        return None

    def getStartHigh(self):
        return 20

class ColdTaiga(Biome): #missing: snow layers, snowing, grass, farn, flowers, mushrooms, wolfs, kaninchen
    def getName(self):
        return "minecraft:biome:cold_taiga"

    def getStructures(self):
        return ["tree_2", "tree_2_M"]


