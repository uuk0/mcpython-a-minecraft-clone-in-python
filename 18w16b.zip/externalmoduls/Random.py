import math

def randomize(value): #function to do some math with an given value to change it
    value *= 7
    value = math.sqrt(value if value >= 0 else -value/3)
    value = math.asin(math.cos(value if value >= 0 else -value))
    value *= 219
    value /= 566
    return value if value >= 0 else -value

def randint(seed, values):
    i = round(randomize(seed)*10)
    value = 1
    for e in values:
        ee = randomize(e*value)
        if ee <= 0.25:
            value *= e
        elif ee <= 0.5:
            value /= e
        elif ee <= 0.75:
            value += e
        else:
            value -= e
    value = randomize(value)
    while value > 1:
        value -= 1
    while value < 0:
        value += 1
    return value

def choice(seed, data, list):
    return list[round(randint(seed, data))]