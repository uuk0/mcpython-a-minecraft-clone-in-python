from .Block import *
import random

class Bookshelve(Block):
    def getTex(self):
        return tex_coords((1, 7), (1, 7), (4, 7))

    def getName(self):
        return "minecraft:bookshelve"

    def getDrop(self, item):
        return "minecraft:book"

    def getDropAmount(self, item):
        return random.randint(1, 3)

    def getDestroyGroups(self):
        return [destroyGroups.AXE]

handler.register(Bookshelve)
