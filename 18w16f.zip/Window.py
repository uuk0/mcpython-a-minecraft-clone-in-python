print("[INFO] definiting Window-class")

from Model import *

from pyglet.window import key

import Block

from Block import Blocks

from chat import *

from TickHandler import handler as tickhandler

from player import *

import Item

import config

import EventHandler, lootchest, WorldHandler

class Window(pyglet.window.Window):

    def __init__(self, *args, **kwargs):
        self.WorldName = ""
        super(Window, self).__init__(*args, **kwargs)
        self.state = ""

        # Whether or not the window exclusively captures the mouse.
        self.exclusive = False

        # When flying gravity has no effect and speed is increased.
        self.flying = False

        # Strafing is moving lateral to the direction you are facing,
        # e.g. moving to the left or right while continuing to face forward.
        #
        # First element is -1 when moving forward, 1 when moving back, and 0
        # otherwise. The second element is -1 when moving left, 1 when moving
        # right, and 0 otherwise.
        self.strafe = [0, 0]

        # Current (x, y, z) position in the world, specified with floats. Note
        # that, perhaps unlike in math class, the y-axis is the vertical axis.
        self.position = self.startpos = (0, 0, 0)

        # First element is rotation of the player in the x-z plane (ground
        # plane) measured from the z-axis down. The second is the rotation
        # angle from the ground plane up. Rotation is in degrees.
        #
        # The vertical plane rotation ranges from -90 (looking straight down) to
        # 90 (looking straight up). The horizontal rotation range is unbounded.
        self.rotation = (0, 0)

        # Which sector the player is currently in.
        self.sector = None

        # The crosshairs at the center of the screen.
        self.reticle = None

        # Velocity in the y (upward) direction.
        self.dy = 0

        # A list of blocks the player can place. Hit num keys to cycle.
        #self.inventory = [Blocks.Grass, Blocks.Sand, Blocks.Brick, Blocks.Stone, Blocks.Dirt, Blocks.CobbelStone]
        self.hotbarelement = 0

        # The current block the user can place. Hit num keys to cycle.
        #self.block = self.inventory[0]

        # Convenience list of num keys.
        self.num_keys = config.CONFIGS["init"]["KEYBINDS"]['inventoryslots:keys']
        self.num_keys = config.CONFIGS["init"]["KEYBINDS"]['inventoryslots:keys']

        # Instance of the model that handles the world.
        self.model = Model(self)

        # The label that is displayed in the top left of the canvas.
        self.label = pyglet.text.Label('', font_name='Arial', font_size=18,
            x=10, y=self.height - 10, anchor_x='left', anchor_y='top',
            color=(0, 0, 0, 255))

        self.label2 = pyglet.text.Label('', font_name='Arial', font_size=18,
            x=10, y=self.height - 30, anchor_x='left', anchor_y='top',
            color=(0, 0, 0, 255))

        self.chatlabel = pyglet.text.Label('', font_name='Arial', font_size=18,
            x=30, y=50, anchor_x='left', anchor_y='top',
            color=(0, 0, 0, 255))

        self.player = player(self)
        playerinst = self.player

        self.world = None

        #time to manage destroy-system
        self.mouseclicktime = 0
        self.isclicked = False
        self.clickingblock = None
        self.clickstarttime = 0

        #mousepos for playerinventory
        self.mousepos = (0, 0)

        #helper vars for braking system
        self.braking_start = None

        self.turning_strafe = [0, 0]

        # This call schedules the `update()` method to be called
        # TICKS_PER_SEC. This is the main game event loop.
        pyglet.clock.schedule_interval(self.update, 1.0 / TICKS_PER_SEC)
        pyglet.clock.schedule_interval(tickhandler._run, 0.5)
        pyglet.clock.schedule_interval(EventHandler.eventhandler.update, 1.0 / TICKS_PER_SEC)

        self.keyEvent = None
        self.last_generate = 1000

        self.menü = None
        self.menünames = config.CONFIGS["init"]["GAME_STATES"]
        self.menüeventbinds = []
        self.camerastate = 0 #0: normal, 1: viewing player from out

        self.worlds = {}
        self.worldlist = []

        self.demoinfosprite = pyglet.sprite.Sprite(texturGroups.handler.groups["./assets/textures/gui/demomsg.png"])
        self.demoinfosprite.x = 100
        self.demoinfosprite.y = 100
        self.esc_menü_back_to_gamesprite = pyglet.sprite.Sprite(texturGroups.handler.groups["./assets/textures/gui/optionbackground_A.png"])
        self.esc_menü_back_to_gamesprite.x = 200
        self.esc_menü_back_to_gamesprite.y = 400
        self.esc_menü_quitsprite = pyglet.sprite.Sprite(texturGroups.handler.groups["./assets/textures/gui/optionbackground_F.png"])
        self.esc_menü_quitsprite.x = 200
        self.esc_menü_quitsprite.y = 200
        self.option_background = pyglet.sprite.Sprite(texturGroups.handler.groups["./assets/textures/gui/options_background.png"])
        self.game_start_worldselect = pyglet.sprite.Sprite(texturGroups.handler.groups["./assets/textures/gui/startgui_singelplayer.png"])
        self.game_start_worldselect.x = 200
        self.game_start_worldselect.y = 400
        self.game_start_quit_sprite = pyglet.sprite.Sprite(texturGroups.handler.groups["./assets/textures/gui/startgui_quitgame.png"])
        self.game_start_quit_sprite.x = 400
        self.game_start_quit_sprite.y = 275
        self.world_select_creat_new_sprite = pyglet.sprite.Sprite(texturGroups.handler.groups["./assets/textures/gui/worldselect_creat_new.png"])
        self.world_select_creat_new_sprite.x = 400
        self.world_select_creat_new_sprite.y = 80
        self.world_select_canceled_sprite = pyglet.sprite.Sprite(texturGroups.handler.groups["./assets/textures/gui/worldselect_cancel.png"])
        self.world_select_canceled_sprite.x = 400
        self.world_select_canceled_sprite.y = 40

        self.demolabel = pyglet.text.Label('', font_name='Arial', font_size=18,
            x=600, y=550, anchor_x='left', anchor_y='top',
            color=(0, 0, 0, 255))
        self.demostarttime = time.time()
        self.loading_label = pyglet.text.Label('Please Wait...', font_name='Arial', font_size=18,
                                           x=600, y=550, anchor_x='left', anchor_y='top',
                                           color=(0, 0, 0, 255))

        if config.CONFIGS["init"]["GAMETYPE"] != "FULL":
            eventhandler.on_event("on_draw_2D", self.on_draw_2d_demo_label)
            print("demo mode")


        self.worldname = None
        self.seed = 0

    def set_menü(self, name):
        self.menünames = config.CONFIGS["init"]["GAME_STATES"]
        if name == None:
            name = "start_menü"
        if name not in self.menünames:
            print("[ERROR] invalid game state A: "+str(name), self.menünames)
        self.keyEvent = name
        for e in self.menüeventbinds:
            EventHandler.eventhandler.unregister_on_event(e)
        self.menüeventbinds = []
        if name == "game":
            self.menüeventbinds.append(eventhandler.on_event("on_draw_3D", self.on_draw_3d_game))
            self.menüeventbinds.append(eventhandler.on_event("on_draw_2D", self.on_draw_2d_game))
            self.menüeventbinds.append(eventhandler.on_event("on_key_press", self.on_key_press_game))
            self.menüeventbinds.append(eventhandler.on_event("on_key_release", self.on_key_release_game))
            self.menüeventbinds.append(eventhandler.on_event("on_mouse_motion", self.on_mouse_motion_game))
            self.menüeventbinds.append(eventhandler.on_event("on_mouse_press", self.on_mouse_press_game))
            self.set_exclusive_mouse(True)
        elif name == "chat":
            self.menüeventbinds.append(eventhandler.on_event("on_draw_3D", self.on_draw_3d_game))
            self.menüeventbinds.append(eventhandler.on_event("on_draw_2D", self.on_draw_2d_game))
            self.menüeventbinds.append(eventhandler.on_event("on_key_press", self.on_key_press_chat))
            self.set_exclusive_mouse(False)
        elif name == "demo_info":
            self.menüeventbinds.append(eventhandler.on_event("on_draw_3D", self.on_draw_3d_game))
            self.menüeventbinds.append(eventhandler.on_event("on_draw_2D", self.on_draw_2d_game))
            self.menüeventbinds.append(eventhandler.on_event("on_draw_2D", self.on_draw_2d_demo_info))
            self.menüeventbinds.append(eventhandler.on_event("on_mouse_press", self.on_mouse_press_demo_info))
            self.menüeventbinds.append(eventhandler.on_event("on_demo_info_purchase_now_clicked", self.on_demo_info_purchase_now_clicked))
            self.menüeventbinds.append(eventhandler.on_event("on_demo_info_continue_plaing_clicked", self.on_demo_info_continue_plaing_clicked))
            self.menüeventbinds.append(eventhandler.on_event("on_key_press", self.on_key_press_demo_info))
            self.set_exclusive_mouse(False)
        elif name == "esc_menü":
            self.menüeventbinds.append(eventhandler.on_event("on_draw_3D", self.on_draw_3d_game))
            self.menüeventbinds.append(eventhandler.on_event("on_draw_2D", self.on_draw_2d_esc_menü))
            self.menüeventbinds.append(eventhandler.on_event("on_key_press", self.on_key_press_esc_menü))
            self.menüeventbinds.append(eventhandler.on_event("on_mouse_press", self.on_mouse_press_esc_menü))
            self.set_exclusive_mouse(False)
        elif name == "start_menü":
            self.menüeventbinds.append(eventhandler.on_event("on_draw_2D", self.on_draw_2d_start_menü))
            self.menüeventbinds.append(eventhandler.on_event("on_mouse_press", self.on_mouse_press_start_menü))
            self.set_exclusive_mouse(False)
        elif name == "loading":
            self.menüeventbinds.append(eventhandler.on_event("on_draw_2D", self.on_draw_2d_loading))
            self.set_exclusive_mouse(True)
        elif name == "inventory":
            self.menüeventbinds.append(eventhandler.on_event("on_draw_3D", self.on_draw_3d_game))
            self.menüeventbinds.append(eventhandler.on_event("on_mouse_press", self.player.inventory.on_mouse_press))
            self.menüeventbinds.append(eventhandler.on_event("on_mouse_motion", self.player.inventory.on_mouse_motion))
            self.menüeventbinds.append(eventhandler.on_event("on_draw_2D", invhandler.draw))
            self.menüeventbinds.append(eventhandler.on_event("on_key_press", self.on_key_press_player_inventory))
            self.set_exclusive_mouse(False)
        elif name == "worldselect":
            self.menüeventbinds.append(eventhandler.on_event("on_draw_2D", self.on_draw_2d_world_select))
            self.menüeventbinds.append(eventhandler.on_event("on_mouse_press", self.on_mouse_press_world_select))
            self.set_exclusive_mouse(False)
            for e in os.listdir("./saves"):
                if e not in self.worlds.keys():
                    if not e in texturGroups.handler.groups.keys(): texturGroups.handler.register("./saves/"+e+"/logo.png", type=1, id=e)
                    self.worlds[e] = pyglet.sprite.Sprite(texturGroups.handler.groups[e])
            self.worldlist = list(self.worlds.keys())
            self.worldlist.sort()
            id = 700
            for e in self.worldlist:
                s = self.worlds[e]
                s.x = 100
                s.y = id
                id -= 10
        else:
            eventhandler.call("on_invalid_game_state", name)

    def on_demo_info_purchase_now_clicked(self, eventname):
        print("not implemented feature")
        self.set_menü("game")

    def on_demo_info_continue_plaing_clicked(self, eventname):
        self.set_menü("game")

    def set_exclusive_mouse(self, exclusive):
        """ If `exclusive` is True, the game will capture the mouse, if False
        the game will ignore the mouse.

        """
        super(Window, self).set_exclusive_mouse(exclusive)
        self.exclusive = exclusive

    def get_sight_vector(self):
        """ Returns the current line of sight vector indicating the direction
        the player is looking.

        """
        x, y = self.rotation
        # y ranges from -90 to 90, or -pi/2 to pi/2, so m ranges from 0 to 1 and
        # is 1 when looking ahead parallel to the ground and 0 when looking
        # straight up or down.
        m = math.cos(math.radians(y))
        # dy ranges from -1 to 1 and is -1 when looking straight down and 1 when
        # looking straight up.
        dy = math.sin(math.radians(y))
        dx = math.cos(math.radians(x - 90)) * m
        dz = math.sin(math.radians(x - 90)) * m
        return (dx, dy, dz)

    def get_motion_vector(self):
        """ Returns the current motion vector indicating the velocity of the
        player.

        Returns
        -------
        vector : tuple of len 3
            Tuple containing the velocity in x, y, and z respectively.

        """
        if any(self.strafe):
            x, y = self.rotation
            strafe = math.degrees(math.atan2(*self.strafe))
            y_angle = math.radians(y)
            x_angle = math.radians(x + strafe)
            if self.flying:
                m = math.cos(y_angle)
                dy = math.sin(y_angle)
                if self.strafe[1]:
                    # Moving left or right.
                    dy = 0.0
                    m = 1
                if self.strafe[0] > 0:
                    # Moving backwards.
                    dy *= -1
                # When you are flying up or down, you have less left and right
                # motion.
                dx = math.cos(x_angle) * m
                dz = math.sin(x_angle) * m
            else:
                dy = 0.0
                dx = math.cos(x_angle)
                dz = math.sin(x_angle)
        else:
            dy = 0.0
            dx = 0.0
            dz = 0.0
        return (dx, dy, dz)

    def update(self, dt):
        """ This method is scheduled to be called repeatedly by the pyglet
        clock.

        Parameters
        ----------
        dt : float
            The change in time since the last call.

        """
        if dt > 10:
            print("[ERROR] update-zyklus do need more time then normal ("+str(dt)+" secounds)")
        self.model.process_queue()
        sector = sectorize(self.position)
        if sector != self.sector:
            self.model.change_sectors(self.sector, sector)
            if self.sector is None:
                self.model.process_entire_queue()
            self.sector = sector
        m = 8
        dt = min(dt, 0.2)
        for _ in xrange(m):
            self._update(dt / m)

        if self.position[1] < -150:
            self.position = (self.position[0], 300, self.position[2])
        if self.position[1] > 310:
            self.position = (self.position[0], -140, self.position[2])
        if normalize(self.position) in self.model.world:
            self.player.harts -= 0.5
        WorldSaver.savePlayerData(self.worldname, self)

        op = self.position; ora = self.rotation
        self.player.update()
        eventhandler.call("on_player_move", self.position, self.rotation, instant=True)

        if self.braking_start != None:
            if self.player.gamemode == 1:
                vector = self.get_sight_vector()
                block, previous = self.model.hit_test(self.position, vector)
                b = self.model.world[block]
                self.model.remove_block(b.pos)
                self.braking_start = None
                return
            d = time.time() - self.braking_start
            vector = self.get_sight_vector()
            block, previous = self.model.hit_test(self.position, vector)
            i = self.player.inventory.hotbar.slots[self.hotbarelement].item
            if not block: return
            b = self.model.world[block]
            id = i.getDestroyMultiplierWithTool(b) if i else 1
            if d / id > b.getHardness() / 5 and b.isBreakAbleWithItem(i) and b.isBreakAble():
                self.player.addToFreePlace(b.getDrop(i), b.getDropAmount(i))
                self.model.remove_block(b.pos)
                self.braking_start = time.time()
            elif not b.isBreakAbleWithItem(i) or not b.isBreakAble():
                self.braking_start = time.time()

    def _update(self, dt):
        """ Private implementation of the `update()` method. This is where most
        of the motion logic lives, along with gravity and collision detection.

        Parameters
        ----------
        dt : float
            The change in time since the last call.

        """
        if self.turning_strafe[0] and config.CONFIGS["ALLOW_CAMERA_MOVING_WITH_ARROWS"]:
            self.rotation = (self.rotation[0] + self.turning_strafe[0] / 4, self.rotation[1])
        if self.turning_strafe[1] and config.CONFIGS["ALLOW_CAMERA_MOVING_WITH_ARROWS"]:
            if (-90 < self.rotation[1] and self.turning_strafe[1] == -1) or (90 > self.rotation[1] and self.turning_strafe[1] == 1):
                self.rotation = (self.rotation[0], self.rotation[1] + self.turning_strafe[1] / 4)
            else:
                self.turning_strafe[1] = None
        # walking
        speed = FLYING_SPEED if self.flying else WALKING_SPEED
        d = dt * speed # distance covered this tick.
        dx, dy, dz = self.get_motion_vector()
        # New position in space, before accounting for gravity.
        dx, dy, dz = dx * d, dy * d, dz * d
        # gravity
        if not self.flying:
            # Update your vertical speed: if you are falling, speed up until you
            # hit terminal velocity; if you are jumping, slow down until you
            # start falling.
            self.dy -= dt * GRAVITY
            self.dy = max(self.dy, -TERMINAL_VELOCITY)
            dy += self.dy * dt
        # collisions
        x, y, z = self.position
        if self.player.gamemode != 3:
            x, y, z = self.collide((x + dx, y + dy, z + dz), PLAYER_HEIGHT)
        else:
            x, y, z = x + dx, y + dy, z + dz
        self.position = (x, y, z)

    def collide(self, position, height):
        """ Checks to see if the player at the given `position` and `height`
        is colliding with any blocks in the world.

        Parameters
        ----------
        position : tuple of len 3
            The (x, y, z) position to check for collisions at.
        height : int or float
            The height of the player.

        Returns
        -------
        position : tuple of len 3
            The new position of the player taking into account collisions.

        """
        # How much overlap with a dimension of a surrounding block you need to
        # have to count as a collision. If 0, touching terrain at all counts as
        # a collision. If .49, you sink into the ground, as if walking through
        # tall grass. If >= .5, you'll fall through the ground.
        #pad = 0.25
        pad = 0
        p = list(position)
        np = normalize(position)
        for face in FACES:  # check all surrounding blocks
            for i in xrange(3):  # check each dimension independently
                if not face[i]:
                    continue
                # How much overlap you have with this dimension.
                d = (p[i] - np[i]) * face[i]
                if d < pad:
                    continue
                for dy in xrange(height):  # check each height
                    op = list(np)
                    op[1] -= dy
                    op[i] += face[i]
                    if tuple(op) not in self.model.world or not self.model.world[tuple(op)].hasHitbox():
                        continue
                    p[i] -= (d - pad) * face[i]
                    if face == (0, -1, 0) or face == (0, 1, 0):
                        # You are colliding with the ground or ceiling, so stop
                        # falling / rising.
                        self.dy = 0
                    break
        return tuple(p)

    def on_mouse_press(self, x, y, button, modifiers):
        """ Called when a mouse button is pressed. See pyglet docs for button
        amd modifier mappings.

        Parameters
        ----------
        x, y : int
            The coordinates of the mouse click. Always center of the screen if
            the mouse is captured.
        button : int
            Number representing mouse button that was clicked. 1 = left button,
            4 = right button.
        modifiers : int
            Number representing any modifying keys that were
            pressed when the
            mouse button was clicked.

        """
        EventHandler.eventhandler.call("on_mouse_press", x, y, button, modifiers, instant=True)

    def on_mouse_press_world_select(self, eventname, x, y, button, modifiers):
        if x > 400 and x < 694 and y > 82 and y < 116:
            self.set_menü("loading")
            self.set_exclusive_mouse(False)
            self.seed = input("worldseed: ")
            self.player.gamemode = int(input("gamemode: "))
            worldtype = str(input("Worldtype (0: superflat, 1: normal, 2:void): "))
            if worldtype == "0":
                biometype = str(input("BiomeType (0: sandstone, 1: dirt): "))
                if biometype in list("01"):
                    self.world = WorldHandler.World(self.model, self.seed, worldtype, [biometype])
                self.world.generateChunk(0, 0)
            elif worldtype == "1":
                self.world = WorldHandler.World(self.model, self.seed, worldtype, [])
                self.world.generateChunk(0, 0)
            elif worldtype == "2":
                self.world = WorldHandler.World(self.model, self.seed, worldtype, [])
                for x in range(-5, 6):
                    for z in range(-5, 6):
                        self.model.add_block((x, 0, z), "minecraft:cobblestone", save=False)
            self.model.change_sectors(None, sectorize(self.position))
            if config.CONFIGS["init"]["GAMETYPE"] != "gametype:full":
                self.set_menü("demo_info")
            else:
                self.set_menü("game")
        elif x > 401 and x < 528 and y > 40 and y < 75:
            self.set_menü("start_menü")
        elif (modifiers & key.MOD_SHIFT):
            print(x, y)

    def on_mouse_press_start_menü(self, eventname, x, y, button, modifiers):
        if x > 200 and x < 595 and y > 401 and y < 437:
            self.set_menü("worldselect")
        elif x > 400 and x < 595 and y > 275 and y < 315:
            self.close()
        elif (modifiers & key.MOD_SHIFT):
            print(x, y)

    def on_mouse_press_esc_menü(self, eventname, x, y, button, modifiers):
        if x > 200 and x < 595 and y > 401 and y < 437:
            self.set_menü("game")
        elif x > 200 and x < 596 and y > 202 and y < 236:
            print("[INFO] saving world...")
            WorldSaver.saveWorld(self.model, self.worldname)
            print("[INFO] saved!")
            for e in list(self.model.shown.keys()):
                self.model.hide_block(e)
            self.model.world = {}
            self.model.sectors = {}
            self.set_menü("start_menü")
        elif (modifiers & key.MOD_SHIFT):
            print(x, y)

    def on_mouse_press_demo_info(self, eventname, x, y, button, modifiers):
        if x > 114 and x < 341 and y > 133 and y < 170:
            eventhandler.call("on_demo_info_purchase_now_clicked")
        elif x > 350 and x < 574 and y > 132 and y < 170:
            eventhandler.call("on_demo_info_continue_plaing_clicked")
        elif (modifiers & key.MOD_SHIFT):
            print(x, y)

    def on_mouse_press_game(self, eventname, x, y, button, modifiers):
        if chat.opened:
            return
        if self.exclusive and self.player.gamemode != 3 and self.player.gamemode != 2:
            vector = self.get_sight_vector()
            block, previous = self.model.hit_test(self.position, vector)
            if (button == mouse.RIGHT) or \
                    ((button == mouse.LEFT) and (modifiers & key.MOD_CTRL)):
                if block and self.model.world[block].hasInventory() and (not self.player.inventory.hotbar.slots[self.hotbarelement].item or (self.player.inventory.hotbar.slots[self.hotbarelement].item and not OreDict.ORE_DROP in self.player.inventory.hotbar.slots[self.hotbarelement].item.getOreDictNames() and not (modifiers & key.MOD_SHIFT))):
                    invhandler.shown.append(self.model.world[block].getInventoryID())
                    invhandler.shown += invhandler.inventoryinst[self.model.world[block].getInventoryID()].getInventoryDependence()
                    self.set_menü(invhandler.inventoryinst[self.model.world[block].getInventoryID()].eventname)
                    print(self.model.world[block].getInventorys()[0].eventname,
                          invhandler.inventoryinst[self.model.world[block].getInventoryID()])
                    print("showing inventory")
                elif self.player.inventory.hotbar.slots[self.hotbarelement].item and OreDict.ORE_DROP in self.player.inventory.hotbar.slots[self.hotbarelement].item.getOreDictNames() and block and self.model.world[block].getName() == "minecraft:stone":
                    self.model.add_block(block, "minecraft:"+self.player.inventory.hotbar.slots[self.hotbarelement].item.getOreMaterial()+"_ore", hitblock=previous)
                elif self.player.inventory.hotbar.slots[self.hotbarelement].item:
                    slot = self.player.inventory.hotbar.slots[self.hotbarelement]
                    if slot.item.hasBlock() and block in self.model.world and not self.model.world[block].hasInventory():
                        self.model.add_block(previous, slot.item.getName(), hitblock=previous)
                        if self.player.gamemode == 0:
                            if slot.amount == 1:
                                slot.setItem(None)
                            else:
                                slot.amount -= 1
                    else:
                        slot.item.on_right_click(block, previous, button, modifiers)
            elif button == pyglet.window.mouse.LEFT:
                if block:
                    if (not self.player.inventory.hotbar.slots[self.hotbarelement].item) or self.player.inventory.hotbar.slots[self.hotbarelement].item.canDestroyBlock(block, button, modifiers) and self.model.world[block].isBreakAble():
                        self.braking_start = time.time()
                    else:
                        self.player.inventory.hotbar.slots[self.hotbarelement].item.on_left_click(self, block, previous, button, modifiers)
            elif button == pyglet.window.mouse.MIDDLE:
                if self.player.gamemode == 1:
                    item = Item.handler.getClass(self.model.world[block].getItemName())()
                    item.blocknbt = self.model.world[block].getAllItemNBT()
                    self.player.addToFreePlace(item)
        elif self.player.mode != 2 and self.player.mode != 3:
            self.set_exclusive_mouse(True)

    def on_mouse_release(self, x, y, button, modifiers):
        self.braking_start = None

    def on_mouse_motion(self, x, y, dx, dy):
        """ Called when the player moves the mouse.

        Parameters
        ----------
        x, y : int
            The coordinates of the mouse click. Always center of the screen if
            the mouse is captured.
        dx, dy : float
            The movement of the mouse.

        """
        EventHandler.eventhandler.call("on_mouse_motion", x, y, dx, dy, instant=True)

    def on_mouse_motion_game(self, eventname, x, y, dx, dy):
        """if self.player.inventory.moving_slot:
            if self.player.inventory.moving_slot:
                self.player.inventory.moving_slot.setPos(x + dx, y + dy)
            return"""
        self.mousepos = (x, y)
        if self.keyEvent == "chat" and chat.opened:
            return
        if self.exclusive:
            m = 0.15
            x, y = self.rotation
            x, y = x + dx * m, y + dy * m
            y = max(-90, min(90, y))
            self.rotation = (x, y)

    def on_key_press(self, symbol, modifiers):
        """ Called when the player presses a key. See pyglet docs for key
        mappings.

        Parameters
        ----------
        symbol : int
            Number representing the key that was pressed.
        modifiers : int
            Number representing any modifying keys that were pressed.

        """
        EventHandler.eventhandler.call("on_key_press", symbol, modifiers, instant=True)

    def on_key_press_player_inventory(self, eventname, symbol, mods):
        if symbol == key.ESCAPE or symbol == key.E:
            self.set_menü("game")
            for i in range(0, 4):
                invhandler.hide(i)

    def on_key_press_esc_menü(self, eventname, symbol, mods):
        if symbol == key.ESCAPE:
            self.set_menü("game")

    def on_key_press_demo_info(self, eventname, symbol, modifiers):
        if symbol == key.ESCAPE:
            self.set_menü("game")

    def on_key_press_chat(self, eventname, symbol, modifiers):
        if symbol == key.ESCAPE:
            chat.opened = False
            chat.text = ""
            self.set_menü("game")
        else:
            chat.addKey(symbol, modifiers)

    def on_key_press_game(self, eventname, symbol, modifiers):
        if symbol == config.CONFIGS["init"]["KEYBINDS"]['forward:key']:
            self.strafe[0] -= 1
        elif symbol == config.CONFIGS["init"]["KEYBINDS"]['backward:key']:
            self.strafe[0] += 1
        elif symbol == config.CONFIGS["init"]["KEYBINDS"]['left:key']:
            self.strafe[1] -= 1
        elif symbol == config.CONFIGS["init"]["KEYBINDS"]['right:key']:
            self.strafe[1] += 1
        elif symbol == config.CONFIGS["init"]["KEYBINDS"]['jump:key']:
            if self.dy == 0:
                self.dy = JUMP_SPEED
        elif symbol == config.CONFIGS["init"]["KEYBINDS"]['escape:key']:
            if self.player.mode == 1 and len(invhandler.shown) <= 1:
                self.set_exclusive_mouse(False)
            elif len(invhandler.shown) <= 1:
                if self.player.inventory.moving_slot and self.player.inventory.moving_start:
                    self.player.inventory.moving_slot.setPos(*self.player.inventory.moving_start)
                    self.player.inventory.moving_slot = None
                self.player.mode = 1
                self.set_exclusive_mouse(True)
                for i in range(0, 4):
                    invhandler.hide(i)
                for e in invhandler.shown:
                    if invhandler.inventoryinst[e].getId() == 4:
                        invhandler.hide(e)
                invhandler.show(0)
            self.set_menü("esc_menü")

        elif symbol == config.CONFIGS["init"]["KEYBINDS"]['togleflying:key'] and self.player.gamemode == 1:
            self.flying = not self.flying
        elif symbol in self.num_keys:
            index = self.num_keys.index(symbol)
            self.hotbarelement = index
            if self.braking_start: self.braking_start = time.time()
        elif symbol == config.CONFIGS["init"]["KEYBINDS"]['openchat:key']:
            chat.open()
            self.set_menü("chat")
        elif symbol == config.CONFIGS["init"]["KEYBINDS"]['openinventory:key']:
            for i in range(0, 4):
                invhandler.show(i)
            self.set_menü("inventory")
        elif symbol == key.LSHIFT and (self.player.mode == 2 or self.player.mode == 3):
            self.player.inventory.on_shift()
        elif symbol == config.CONFIGS["init"]["KEYBINDS"]['movecamera:key'][0] and config.CONFIGS["ALLOW_CAMERA_MOVING_WITH_ARROWS"]:
            self.turning_strafe[1] = 1
        elif symbol == config.CONFIGS["init"]["KEYBINDS"]['movecamera:key'][1] and config.CONFIGS["ALLOW_CAMERA_MOVING_WITH_ARROWS"]:
            self.turning_strafe[1] = -1
        elif symbol == config.CONFIGS["init"]["KEYBINDS"]['movecamera:key'][2] and config.CONFIGS["ALLOW_CAMERA_MOVING_WITH_ARROWS"]:
            self.turning_strafe[0] = 1
        elif symbol == config.CONFIGS["init"]["KEYBINDS"]['movecamera:key'][3] and config.CONFIGS["ALLOW_CAMERA_MOVING_WITH_ARROWS"]:
            self.turning_strafe[0] = -1

    def on_key_release(self, symbol, modifiers):
        """ Called when the player releases a key. See pyglet docs for key
        mappings.

        Parameters
        ----------
        symbol : int
            Number representing the key that was pressed.
        modifiers : int
            Number representing any modifying keys that were pressed.

        """
        EventHandler.eventhandler.call("on_key_release", symbol, modifiers, instant=True)

    def on_key_release_game(self, eventname, symbol, modifiers):
        if self.keyEvent == "chat" and chat.opened:
            if self.strafe[0] != 0:
                self.strafe[0] = 0
            if self.strafe[1] != 0:
                self.strafe[1] = 0
            return
        if symbol == key.W:
            self.strafe[0] += 1
        elif symbol == key.S:
            self.strafe[0] -= 1
        elif symbol == key.A:
            self.strafe[1] += 1
        elif symbol == key.D:
            self.strafe[1] -= 1
        elif symbol == key.UP:
            self.turning_strafe[1] = None
        elif symbol == key.DOWN:
            self.turning_strafe[1] = None
        elif symbol == key.RIGHT:
            self.turning_strafe[0] = None
        elif symbol == key.LEFT:
            self.turning_strafe[0] = None

    def on_resize(self, width, height):
        """ Called when the window is resized to a new `width` and `height`.

        """
        # label
        self.label.y = height - 10
        # reticle
        if self.reticle:
            self.reticle.delete()
        x, y = self.width // 2, self.height // 2
        n = 10
        self.reticle = pyglet.graphics.vertex_list(4,
            ('v2i', (x - n, y, x + n, y, x, y - n, x, y + n))
        )

    def set_2d(self):
        """ Configure OpenGL to draw in 2d.

        """
        width, height = self.get_size()
        glDisable(GL_DEPTH_TEST)
        glViewport(0, 0, width, height)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        glOrtho(0, width, 0, height, -1, 1)
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()

    def set_3d(self):
        """ Configure OpenGL to draw in 3d.

        """
        width, height = self.get_size()
        glEnable(GL_DEPTH_TEST)
        glViewport(0, 0, width, height)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()
        gluPerspective(65.0, width / float(height), 0.1, 60.0)
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()
        x, y = self.rotation
        glRotatef(x, 0, 1, 0)
        glRotatef(-y, math.cos(math.radians(x)), 0, math.sin(math.radians(x)))
        x, y, z = self.position
        glTranslatef(-x, -y, -z)

    def on_draw_3d_game(self, eventname, obj):
        self.model.batch.draw()
        self.draw_focused_block()

    def on_draw_2d_loading(self, eventname, obj):
        self.loading_label.draw()

    def on_draw_2d_game(self, eventname, obj):
        self.draw_label()
        self.draw_reticle()
        invhandler.draw()
        chat.draw()

    def on_draw_2d_start_menü(self, eventname, obj):
        self.option_background.draw()
        self.game_start_worldselect.draw()
        self.game_start_quit_sprite.draw()

    def on_draw_2d_world_select(self, eventname, obj):
        self.option_background.draw()
        self.world_select_creat_new_sprite.draw()
        self.world_select_canceled_sprite.draw()
        for e in self.worldlist:
            s = self.worlds[e]
            s.draw()

    def on_draw_2d_demo_info(self, eventname, obj):
        self.demoinfosprite.draw()

    def on_draw_2d_esc_menü(self, eventname, obj):
        self.esc_menü_back_to_gamesprite.draw()
        self.esc_menü_quitsprite.draw()

    def on_draw_2d_demo_label(self, eventname, obj):
        if config.CONFIGS["init"]["GAMETYPE"] != "FULL":
            now = time.time()
            d = now - self.demostarttime
            u = 100 * 60 - d
            self.demolabel.text = str(round_down(u/60)) + " min "
            self.demolabel.text += str(round_down(u-round_down(u/60)*60))
            self.demolabel.text += " sec"
        self.demolabel.draw()
        if (100 * 60 - time.time() - self.demostarttime) / 60 > 100:
            print("demo time over!!!")
            self.close()

    def on_draw(self):
        """ Called by pyglet to draw the canvas.

        """
        self.clear()
        self.set_3d()
        glColor3d(1, 1, 1)
        EventHandler.eventhandler.call("on_draw_3D", self, instant=True)
        self.set_2d()
        EventHandler.eventhandler.call("on_draw_2D", self, instant=True)

    def draw_focused_block(self):
        """ Draw black edges around the block that is currently under the
        crosshairs.

        """
        vector = self.get_sight_vector()
        block = self.model.hit_test(self.position, vector)[0]
        if block:
            x, y, z = block
            vertex_data = cube_vertices(x, y, z, 0.51)
            glColor3d(0, 0, 0)
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE)
            pyglet.graphics.draw(24, GL_QUADS, ('v3f/static', vertex_data))
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL)

    def draw_label(self):
        """ Draw the label in the top left of the screen.

        """
        x, y, z = self.position
        text = ""
        if config.CONFIGS["SHOW_FPS"]:
            text += str(round(pyglet.clock.get_fps())) + " "
        if config.CONFIGS["SHOW_KOORDINATES"]:
            text += str((round(x), round(y), round(z))) + " "
        if config.CONFIGS["SHOW_WORLDSIZE"]:
            text += str(len(self.model._shown)) + "/" + str(len(self.model.world)) + " "
        self.label.text = text
        self.label.draw()
        vector = self.get_sight_vector()
        block = self.model.hit_test(self.position, vector)[0]
        if block and config.CONFIGS["SHOW_BLOCK_LOOKING_AT"]:
            self.label2.text = "You are looking at "+self.model.world[block].getVisualName() + (str(block) if config.CONFIGS["SHOW_BLOCK_POS_LOOKING_AT"] else "")
            self.label2.draw()

    def draw_reticle(self):
        """ Draw the crosshairs in the center of the screen.

        """
        glColor3d(0, 0, 0)
        self.reticle.draw(GL_LINES)

    def kill(self, msg):
        y = 4
        while (0, y, 0) in self.model.world:
            y += 1
        self.position = self.startpos = (0, y+1, 0)
        chat.printIn(msg)
        self.player.harts = 10

    def openInventory(self, id):
        invhandler.show(id)

    def on_mouse_scroll(self, x, y, scroll_x, scroll_y):
        if 2 not in invhandler.shown:
            if self.hotbarelement + scroll_x > 8:
                if self.hotbarelement + 1 > 1:
                    scroll_x -= 1
                    self.hotbarelement = 0
                while self.hotbarelement + scroll_x > 8:
                    scroll_x -= 9
            self.hotbarelement += scroll_x
        if self.braking_start: self.braking_start = time.time()
