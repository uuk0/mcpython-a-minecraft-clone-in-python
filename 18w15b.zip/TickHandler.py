import threading
from time import *

from chat import *

class TickHandler:
    def __init__(self):
        self.ticks = [[]] * 100
        self.nextupdate = clock() + 1

    def _run(self, dt):
        self.nextupdate += 1
        data = self.ticks.pop(0)
        self.ticks.append([])
        for f in data:
            f[0](*f[1], **f[2])

    def run(self, funk, tick, args=[], kwargs={}):
        self.ticks[tick].append([funk, args, kwargs])


handler = TickHandler()
