import Inventorys
from .Block import *
from player import Slot
import crafting




class crafting_table(Block):
    def __init__(self, *args, **kwargs):
        Block.__init__(self, *args, **kwargs)
        self.stored = []
    
    def getTexturFile(self):
        return 1
    
    def getTex(self):
        return total_tex_coords((2, 0), (2, 0),
                                (0, 0), (0, 0), (0, 0), (0, 0))

    def getName(self):
        return "minecraft:crafting_table"

    def getNBTNames(self):
        names = []
        for e in range(10):
            names.append("inventory_"+str(e)+"_x")
            names.append("inventory_"+str(e)+"_y")
            names.append("inventory_"+str(e)+"_item")

        return names

    def drawInventory(self):
        pass

    def setNBT(self, name, value):
        pass

    def getNBT(self, name):
        pass

    def getAllNBT(self):
        return []

    def getAllItemNBT(self):
        return {}

    def setAllNBT(self, nbt):
        pass

    def hasInventory(self):
        return True

    def getInventoryID(self):
        return self.inv.id

    def on_creat(self):
        self.inv = Inventorys.craftingtable()
        self.inv.block = self
        self.crafting_recipi = None
        self.crafting_recipi_slots = []
        for e in self.inv.slots:
            e.update = self.crafting_update

    def crafting_update(self, slot, item, amount):
        if item == None:
            if slot.stid != "minecraft:slot:crafting_table:out":
                if slot in self.stored:
                    self.stored.remove(slot)
                    self.crafting_output_check()
            else:
                self.remove_output()
                self.crafting_output_check()
        else:
            if slot.stid != "minecraft:slot:crafting_table:out":
                self.crafting_output_check()
                if not slot in self.stored: self.stored.append(slot)

    def check_stored(self):
        self.stored = []
        for e in self.inv.slots[:-1]:
            if e.item:
                self.stored.append(e)

    def crafting_output_check(self):
        self.check_stored()
        for c in crafting.craftinghandler.recipis[crafting.Grid.crafting_1x1]:
            for i, s in enumerate(self.inv.slots[:9]):
                if (s.item and s.item.getName() == c.input[0] and s.amount >= c.inputamount[0]) or (c.input[0] == None and not s.item):
                    flag = len(self.stored) == 1
                    if flag:
                        self.crafting_recipi = c
                        self.crafting_recipi_slots = [self.inv.slots[i]]
                        self.inv.slots[9].setItem(c.output[0], update=False)
                        self.inv.slots[9].amount = c.outputamount[0]
                        return
        for c in crafting.craftinghandler.recipis[crafting.Grid.crafting_2x1]:
            for sl in [self.inv.slots[0:1], self.inv.slots[1:2],
                       self.inv.slots[3:4], self.inv.slots[4:5],
                       self.inv.slots[6:7], self.inv.slots[7:8]]:
                flag = len(self.stored) == 2
                for i, s in sl:
                    if not (s.item and s.item.getName() == c.input[i] and s.amount >= c.inputamount[i]):
                        if not s.item or not c.input[i] in s.item.getOreDictNames():
                            flag = False
                if flag:
                    self.crafting_recipi = c
                    self.crafting_recipi_slots = [sl[0].id, sl[1].id]
                    self.inv.slots[9].setItem(c.output[0])
                    self.inv.slots[9].amount = c.outputamount[0]
                    return
        for c in crafting.craftinghandler.recipis[crafting.Grid.crafting_1x2]:
            sll = [[self.inv.slots[0], self.inv.slots[3]], [self.inv.slots[1], self.inv.slots[4]], [self.inv.slots[2], self.inv.slots[5]],
                   [self.inv.slots[3], self.inv.slots[6]], [self.inv.slots[4], self.inv.slots[7]], [self.inv.slots[5], self.inv.slots[8]]]
            for si in range(0, len(sll)):
                sl = sll[si]
                flag = len(self.stored) == 2
                for i, s in enumerate(sl):
                    if not (s.item and s.item.getName() == c.input[i] and s.amount >= c.inputamount[i]):
                        if not s.item or not c.input[i] in s.item.getOreDictNames():
                            flag = False
                if flag:
                    self.crafting_recipi = c
                    self.crafting_recipi_slots = [sl[0], sl[1]]
                    self.inv.slots[9].setItem(c.output[0])
                    self.inv.slots[9].amount = c.outputamount[0]
                    return
        si = []
        for e in self.inv.slots:
            si.append([e])
        if self.check_crafting(crafting.craftinghandler.recipis[crafting.Grid.crafting_1x1],
                            si): return
        if self.check_crafting(crafting.craftinghandler.recipis[crafting.Grid.crafting_1x2],
                               [[self.inv.slots[0], self.inv.slots[3]], [self.inv.slots[1], self.inv.slots[4]],
                                [self.inv.slots[2], self.inv.slots[5]],
                                [self.inv.slots[3], self.inv.slots[6]], [self.inv.slots[4], self.inv.slots[7]],
                                [self.inv.slots[5], self.inv.slots[8]]]): return
        if self.check_crafting(crafting.craftinghandler.recipis[crafting.Grid.crafting_2x1],
                               [self.inv.slots[0:1], self.inv.slots[1:2],
                                self.inv.slots[3:4], self.inv.slots[4:5],
                                self.inv.slots[6:7], self.inv.slots[7:8]]): return
        if self.check_crafting(crafting.craftinghandler.recipis[crafting.Grid.crafting_2x2],
                            [[self.inv.slots[0], self.inv.slots[1], self.inv.slots[3], self.inv.slots[4]],
                   [self.inv.slots[1], self.inv.slots[2], self.inv.slots[4], self.inv.slots[5]],
                   [self.inv.slots[3], self.inv.slots[4], self.inv.slots[6], self.inv.slots[7]],
                   [self.inv.slots[4], self.inv.slots[5], self.inv.slots[7], self.inv.slots[8]]]): return
        if self.check_crafting(crafting.craftinghandler.recipis[crafting.Grid.crafting_1x3],
            [[self.inv.slots[0], self.inv.slots[3], self.inv.slots[6]],
             [self.inv.slots[1], self.inv.slots[4], self.inv.slots[7]],
             [self.inv.slots[2], self.inv.slots[5], self.inv.slots[8]]]): return
        if self.check_crafting(crafting.craftinghandler.recipis[crafting.Grid.crafting_3x1],
            [[self.inv.slots[0:3]],
             [self.inv.slots[3:6]],
             [self.inv.slots[6:9]]]): return
        if self.check_crafting(crafting.craftinghandler.recipis[crafting.Grid.crafting_3x2],
            [[self.inv.slots[0:6]],
             [self.inv.slots[3:9]]]): return
        if self.check_crafting(crafting.craftinghandler.recipis[crafting.Grid.crafting_3x3],
            [self.inv.slots]): return
        self.crafting_recipi = None
        self.crafting_recipi_slots = []
        self.inv.slots[8].setItem(None)

    def remove_output(self):
        if not self.crafting_recipi: return
        for i, e in enumerate(self.crafting_recipi.inputamount):
            self.crafting_recipi_slots[i].amount -= e
            if self.crafting_recipi_slots[i] == 0:
                self.crafting_recipi_slots[i].setItem(None)
        self.inv.slots[9].setPos(464, 275, update=False)

    def check_crafting(self, recipis, slotgroups):
        for c in recipis:
            sll = slotgroups
            for si in range(0, len(sll)):
                sl = sll[si]
                flag = len(self.stored) == len(slotgroups[0])
                for i, s in enumerate(sl):
                    if not (s.item and s.item.getName() == c.input[i] and s.amount >= c.inputamount[i]) and flag:
                        if (not s.item and c.input[i]) or (s.item and not c.input[i] in s.item.getOreDictNames()):
                            flag = False
                if flag:
                    self.crafting_recipi = c
                    self.crafting_recipi_slots = sl
                    self.inv.slots[9].setItem(c.output[0])
                    self.inv.slots[9].amount = c.outputamount[0]
                    return True

    def getInventoryID(self):
        return self.inv.id

    def getDestroyGroups(self):
        return [destroyGroups.AXE]

    def getDrop(self, item):
        items = [self.getName()]
        for e in self.inv.slots:
            if e.item: items.append(e.item.getName())
        return items

    def getDropAmount(self, item):
        items = [1]
        for e in self.inv.slots:
            if e.item: items.append(e.amount)
        return items


handler.register(crafting_table)
