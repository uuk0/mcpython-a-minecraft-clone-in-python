from .Item import *

class IronOre(Item):
    def getName(self):
        return "minecraft:iron_ore"

    def getTexturFile(self):
        return "./assets/textures/items/ironore.jpe"

handler.register(IronOre)
