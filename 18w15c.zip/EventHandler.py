import traceback

class EventHandler:
    def __init__(self):
        self.events = {}
        self.tocall = []
        self.nextid = 0
        self.fromid = {}

    def update(self, dt=None):
        if len(self.tocall) > 0:
            call = self.tocall.pop(0)
            for e in call:
                if e[0] != -1:
                    try:
                        e[0](*e[1])
                    except:
                        print(traceback.print_exc())


    def register(self, name):
        if not name in self.events: self.events[name] = []

    def on_event(self, name, funk):
        if not name in self.events:
            print("[ERROR] function "+str(funk)+" try to be callen on event "+str(name)+" what is not possible because event does not exist")
            return -1
        self.events[name].append(funk)
        id = self.nextid
        self.nextid += 1
        self.fromid[id] = [name, len(self.events[name]) - 1]
        return id

    def unregister_on_event(self, id):
        if id == -1: return
        if not id in self.fromid:
            print("[ERROR] an unknown function try to be unregistered")
            return
        self.events[self.fromid[id][0]][self.fromid[id][1]] = -1

    def call(self, name, *args, instant=False):
        if not name in self.events:
            print("[ERROR] an unknown event try to be callen")
            return
        if not instant:
            call = []
            for f in self.events[name]:
                call.append([f, [name]+list(args)])
            self.tocall.append(call)
        else:
            call = []
            for f in self.events[name]:
                call.append([f, [name] + list(args)])
            for e in call:
                if e[0] != -1:
                    try:
                        e[0](*e[1])
                    except:
                        print(traceback.print_exc())

eventhandler = EventHandler()
eventhandler.register("on_game_inited")
eventhandler.register("on_game_started")
eventhandler.register("on_command_executed")
eventhandler.register("on_unknown_command_executed")
eventhandler.register("on_game_crash")
eventhandler.register("on_draw_3D")
eventhandler.register("on_draw_2D")
eventhandler.register("on_chunk_generated")
eventhandler.register("on_key_press")
eventhandler.register("on_key_release")
eventhandler.register("on_mouse_motion")
eventhandler.register("on_mouse_press")
eventhandler.register("on_invalid_game_state")
eventhandler.register("on_demo_info_purchase_now_clicked")
eventhandler.register("on_demo_info_continue_plaing_clicked")