from .Block import *

class Bedrock(Block):
    def getTex(self):
        return tex_coords((3, 0), (3, 0), (3, 0))

    def getName(self):
        return "minecraft:bedrock"

    def isBreakAble(self):
        return False

handler.register(Bedrock)
