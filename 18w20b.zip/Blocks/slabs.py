from .Block import *
import player, EventHandler, texturGroups, pyglet
import entity.boxmodel as boxmodel
import globals as G


"""
SLABS = {}

class SlabHolder(Block):
    def on_creat(self):
        self.parts = [None, None]

    def getBaseName(self):
        return "minecraft:slab_base"

    def show(self, model, window, texture):
        for e in self.parts:
            if e != None: e.show(model, window, texture)

    def hide(self, model, window):
        for e in self.parts:
            if e != None: e.hide(model, window)

    def getNBTNames(self):
        return ["side", "IdU", "IdD"]

    def setNBT(self, name, value):
        if name == "side":
            if self.side != value:
                self.hide(player.playerinst.window.model, player.playerinst.window)
                self.side = value
                self.show(player.playerinst.window.model, player.playerinst.window, self.getTex())
        elif name == "IdU":
            self.parts[0] = SLABS[value](self.pos)
        elif name == "IdD":
            self.parts[1] = SLABS[value](self.pos)

    def getDrop(self, item):
        items = []
        for e in self.parts:
            if e != None: items.append(e.getItemName())
        return items

    def getDropAmount(self, item):
        items = []
        for e in self.parts:
            if e != None: items.append(1)
        return items

    def getTex(self):
        return None

class Slab(Block):
    def on_creat(self):
        self.boxmodel = boxmodel.BoxModel(1, 1, 0.5, pyglet.image.load(self.getTexturFile()), 64, 64, 32)
        self.side = "D"
        inst = SlabHolder(self.pos)
        inst.parts[0] = self
        G.window.model.add_block(self.pos, inst, inst=True)
        self.modelsys = []

    def setSide(self, side):
        self.side = side
        if side == "D":
            self.boxmodel.position = (self.pos[0] - 0.5, self.pos[1] - 0.5, self.pos[2] - 0.5)
            self.boxmodel.update_texture_data([self.getTexturPlace()] * 6)
        elif side == "U":
            self.boxmodel.position = (self.pos[0] - 0.5, self.pos[1], self.pos[2] - 0.5)
            self.boxmodel.update_texture_data([(self.getTexturPlace()[0], self.getTexturPlace()[1]+32)] * 6)

    def getTexturPlace(self):
        return (0, 0)

    def show(self, model, window, texture):
        self.modelsys = []
        self.modelsys.append(EventHandler.eventhandler.on_event("on_draw_3D", self.draw))

    def hide(self, model, window):
        for e in self.modelsys:
            EventHandler.eventhandler.unregister_on_event(e)

    def draw(self, *args):
        self.boxmodel.draw()

class Wood_0_Slab(Slab):
    def getTexturPlace(self):
        return (64, 448)

    def getTexturFile(self):
        return "./assets/textures/blocks/texture.png"

    def getName(self):
        return "minecraft:wood_slab_0"

handler.register(Wood_0_Slab)
"""
class Wood_0_Slab(Block):
    def on_creat(self):
        self.modelsys = []
        self.models = []
        self.side = "D"
        self.boxmodelA = boxmodel.BoxModel(1, 1, 0.5, pyglet.image.load("./assets/textures/blocks/texture.png"), 64, 64, 32)
        self.boxmodelA.position = (self.pos[0] - 0.5, self.pos[1] - 0.5, self.pos[2] - 0.5)
        self.boxmodelA.update_texture_data([(64, 448)] * 6)
        self.boxmodelB = boxmodel.BoxModel(1, 1, 0.5, pyglet.image.load("./assets/textures/blocks/texture.png"), 64, 64, 32)
        self.boxmodelB.position = (self.pos[0] - 0.5, self.pos[1], self.pos[2] - 0.5)
        self.boxmodelB.update_texture_data([(64, 480)] * 6)

    def show(self, model, window, texture):
        if self.side == "A":
            Block.show(self, model, window, texture)
            return
        self.modelsys.append(EventHandler.eventhandler.on_event("on_draw_3D", self.draw))
        self.models = []
        if self.side == "D":
            self.models.append(self.boxmodelA)
        if self.side == "U":
            self.models.append(self.boxmodelB)

    def hide(self, model, window):
        if self.side == "A":
            Block.hide(self, model, window)
            return
        for e in self.modelsys:
            EventHandler.eventhandler.unregister_on_event(e)

    def draw(self, *args):
        for e in self.models:
            e.draw()

    def getName(self):
        return "minecraft:wood_slab_0"

    def getTex(self):
        return tex_coords((1, 7), (1, 7), (1, 7))

    def getNBTNames(self):
        return ["side"]

    def setNBT(self, name, value):
        if name == "side":
            if self.side != value:
                self.hide(player.playerinst.window.model, player.playerinst.window)
                self.side = value
                self.show(player.playerinst.window.model, player.playerinst.window, self.getTex())

    def getDropAmount(self, item):
        return 2 if self.side == "A" else 1

handler.register(Wood_0_Slab)