import threading
from time import *
import player

from chat import *

class TickHandler:
    def __init__(self):
        self.ticks = [[]] * 100
        self.nextupdate = clock() + 1

    def _run(self, dt):
        if player.playerinst and (player.playerinst.window.keyEvent == "esc_menü" or player.playerinst.window.keyEvent == "start_menü"): return
        self.nextupdate += 1
        data = self.ticks.pop(0)
        self.ticks.append([])
        for f in data:
            f[0](*f[1], **f[2])

    def run(self, funk, tick, args=[], kwargs={}):
        self.ticks[tick].append([funk, args, kwargs])


handler = TickHandler()
