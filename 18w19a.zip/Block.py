from moduls import *

from mathhelper import *

from TickHandler import handler as tickhandler

import Blocks

print("[INFO] creating block-syntax")

from Blocks import handler, Block


TEXTURE_PATH = "./texturs/texture.png"


FACES = [
    ( 0, 1, 0),
    ( 0,-1, 0),
    (-1, 0, 0),
    ( 1, 0, 0),
    ( 0, 0, 1),
    ( 0, 0,-1),
]
