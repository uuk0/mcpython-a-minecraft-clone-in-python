from .Block import *

class Snow(Block):
    def getTex(self):
        return tex_coords((12, 13), (12, 13), (12, 13))

    def getName(self):
        return "minecraft:snow_block"

    def getDestroyGroups(self):
        return [destroyGroups.SHOVEL]

handler.register(Snow)
