from .Block import *
import player, EventHandler, texturGroups, pyglet
import entity.boxmodel as boxmodel

class Wood_0_Slab(Block):
    def on_creat(self):
        self.modelsys = []
        self.models = []
        self.side = "D"

    def show(self, model, window, texture):
        self.modelsys.append(EventHandler.eventhandler.on_event("on_draw_3D", self.draw))
        self.models = []
        if self.side == "D" or self.side == "A":
            self.models.append(boxmodel.BoxModel(1, 1, 0.5, pyglet.image.load("./assets/textures/blocks/texture.png"), 64, 64, 32))
            self.models[0].position = (self.pos[0] - 0.5, self.pos[1] - 0.5, self.pos[2] - 0.5)
        if self.side == "U" or self.side == "A":
            self.models.append(boxmodel.BoxModel(1, 1, 0.5, pyglet.image.load("./assets/textures/blocks/texture.png"), 64, 64, 32))
            self.models[-1].position = (self.pos[0] - 0.5, self.pos[1], self.pos[2] - 0.5)
        for e in self.models:
            e.update_texture_data([(64, 448)] * 6)

    def hide(self, model, window):
        for e in self.modelsys:
            EventHandler.eventhandler.unregister_on_event(e)

    def draw(self, *args):
        for e in self.models:
            e.draw()

    def getName(self):
        return "minecraft:wood_slab_0"

    def getTex(self):
        return None

    def getNBTNames(self):
        return ["side"]

    def setNBT(self, name, value):
        if name == "side":
            if self.side != value:
                self.side = value
                self.hide(None, None)
                self.show(None, None, None)

    def getDropAmount(self, item):
        return 2 if self.side == "A" else 1

handler.register(Wood_0_Slab)