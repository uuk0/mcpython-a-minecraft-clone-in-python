from .Block import *
from oredictnames import OreDict
from destroyGroup import *

class Dirt(Block):
    def getTex(self):
        return tex_coords((0, 1), (0, 1), (0, 1))

    def getName(self):
        return "minecraft:dirt"

    def getOreDictNames(self):
        return [OreDict.DIRT]

    def getDestroyGroups(self):
        return [destroyGroups.SHOVEL]


handler.register(Dirt)
