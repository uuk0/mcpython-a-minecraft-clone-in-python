from .Block import *


class GoldOre(Block):
    def getTex(self):
        return tex_coords((3, 4), (3, 4), (3, 4))

    def getName(self):
        return "minecraft:gold_ore"

    def getDestroyGroups(self):
        return [destroyGroups.PIKAXE]

handler.register(GoldOre)
