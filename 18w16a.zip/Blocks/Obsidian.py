from .Block import *
from oredictnames import *

class Obsidian(Block):
    def getTex(self):
        return tex_coords((3, 0), (3, 0), (3, 0))

    def getName(self):
        return "minecraft:obsidian"

    def getDestroyGroups(self):
        return [destroyGroups.PIKAXE]

    def isBreakAbleWithItem(self, item):
        return item.getDestroyGroup() == destroyGroups.PIKAXE and item.getToolMaterial() == "minecraft:diamond"

handler.register(Obsidian)
