import pickle

STRUCTUR_VERSION = "0.0.3"
COMPATIBLE = [STRUCTUR_VERSION]

""".structur file data:
pickled: {"version":"0.1.1",
          "size":(x, y, z),
          "blocks":[<blocklist>],
          "name":name}

block: [mode, ...]
mode = 0: add block with name at position
mode = 1: remove block at position"""

class StructurHandler:
    def __init__(self):
        self.structurs = {}

    def register(self, structur):
        self.structurs[structur.name] = structur


handler = StructurHandler()

class Structur:
    def __init__(self, file):
        f = open("./assets/structures/"+file+".structur", mode="rb")
        data = pickle.load(f)
        f.close()
        if not data["version"] in COMPATIBLE:
            print("[ERROR] can't load structur "+file+". structur version not compatible")
        else:
            self.size = data["size"]
            self.blocks = data["blocks"]
            self.name = data["name"]
            self.data = data
            handler.register(self)

    def past(self, model, x, y, z):
        for e in self.blocks:
            if e[0] == 0:
                model.add_block(e[1], (e[2][0]+x, e[2][1]+y, e[2][2]+z))
            elif e[0] == 1:
                model.remove_block((e[2][0]+x, e[2][1]+y, e[2][2]+z))
