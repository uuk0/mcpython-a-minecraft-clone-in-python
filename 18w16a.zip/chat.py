import Item, Blocks
from moduls import *

import pyperclip, structures, pickle

from pyglet.window import key

from crafting import craftinghandler

import WorldHandler

from Inventorys.Inventory import handler as invhandler

from mathhelper import *

from constans import *

import WorldSaver, config

import crafting

from EventHandler import eventhandler

import pyglet.window.key

KeyToValue = {key.A:"a", key.B:"b", key.C:"c", key.D:"d", key.E:"e", key.F:"f", key.G:"g", key.H:"h", key.I:"i",
              key.J:"j", key.K:"k", key.L:"l", key.M:"m", key.N:"n", key.O:"o", key.P:"p", key.Q:"q", key.R:"r",
              key.S:"s", key.T:"t", key.U:"u", key.V:"v", key.W:"w", key.X:"x", key.Y:"y", key.Z:"z", key._0:"0",
              key._1:"1", key._2:"2", key._3:"3", key._4:"4", key._5:"5", key._6:"6", key._7:"7", key._8:"8",
              key._9:"9", key.COMMA:",", key.MINUS:"-", key.PLUS:"+", key.SPACE:" "}

class chat:
    def __init__(self):
        self.chat = []
        self.opened = False
        self.window = None
        self.text = ""
        self.last_commants = []
        self.command_id = -1

    def printIn(self, msg):
        self.chat.append(msg)
        if len(self.chat) > 100:
            chat.pop(0)
        print("[CHAT] "+msg)

    def warn(self, msg):
        print("[WARNING] "+msg)

    def open(self):
        self.opened = True

    def addKey(self, symbol, mod):
        key = pyglet.window.key
        if mod & key.MOD_CTRL and key.C:
            pyperclip.copy(self.text)
            print("copiing...")
        elif mod & key.MOD_CTRL and key.V:
            self.text = pyperclip.paste()
            print("pasting....")
        elif symbol == key.ENTER:
            self.excecute(self.text)
            self.text = ""
            self.window.keyEvent = "window"
            self.opened = False
            self.last_commants.append(self.text)
            self.text = ""
        elif symbol == key.BACKSPACE:
            self.text = self.text[:-1]
        elif symbol == key._7 and (mod & key.MOD_SHIFT):
            self.text += "/"
        elif symbol == key.ESCAPE:
            print("[WARNING] keyhandler does give 'esc'-key to chat.")
        elif symbol == key.MINUS and (mod & key.MOD_SHIFT):
            self.text += "_"
        elif symbol == key.PLUS and (mod & key.MOD_SHIFT):
            self.text += "*"
        elif symbol == key.PLUS and (mod & 108):
            self.text += "~"
        elif symbol == key.MOD_SHIFT:
            return #vorbereitend
        elif symbol == key.UP:
            self.command_id += 1
            if self.command_id == len(self.last_commants):
                self.command_id = len(self.last_commants) - 1
            self.text = self.last_commants[self.command_id]
        elif symbol == key.DOWN:
            self.command_id -= 1
            if self.command_id == -1:
                self.text = ""
            else:
                self.text = self.last_commants[self.command_id]
        else:
            if symbol in KeyToValue.keys():
                k = KeyToValue[symbol]
                if (mod & key.MOD_SHIFT):
                    k = k.upper()
                self.text += k
            else:
                print("[WARN] unknown char key "+str(symbol))

    def draw(self):
        if self.opened:
            self.window.keyEvent = "chat"
        else:
            self.window.keyEvent = "window"
        self.window.chatlabel.text = self.text
        self.window.chatlabel.draw()

    def excecute(self, msg):
        if not self.opened: return
        command = msg
        sc = command.split(" ")
        if command == "/help":
            print("error::not_implemented")
        elif sc[0] == "/give":
            name = str(sc[1])
            amount = 1 if len(sc) == 2 else int(sc[2])
            self.window.player.addToFreePlace(name, amount)
        elif sc[0] == "/clear":
            for s in self.window.player.inventory.hotbar.slots:
                s.setItem(None)
            for s in self.window.player.inventory.rows.slots:
                s.setItem(None)
            for s in self.window.player.inventory.armor.slots:
                s.setItem(None)
            for s in self.window.player.inventory.crafting.slots:
                s.setItem(None)
        elif sc[0] == "/kill":
            self.window.kill("player fell out of the world")
        elif sc[0] == "/gamemode":
            self.window.player.gamemode = int(sc[1])
            if sc[1] == "0" or sc[1] == "2":
                self.window.flying = False
            elif sc[1] == "3":
                self.window.flying = True
        elif sc[0] == "/tp":
            self.window.position = (int(sc[1]), int(sc[2]), int(sc[3]))
        elif sc[0] == "/setblock":
            self.window.model.add_block((int(sc[1]), int(sc[2]), int(sc[3])), sc[4])
        elif sc[0] == "/fill":
            print("filling...")
            sx = int(sc[1]); sy = int(sc[2]); sz = int(sc[3])
            ex = int(sc[4]); ey = int(sc[5]); ez = int(sc[6])
            block = sc[7]
            if sx > ex:
                d = sx
                sx = ex
                ex = d
            if sy > ey:
                d = sy
                sy = ey
                ey = d
            if sz > ez:
                d = sz
                sz = ez
                ez = d
            print(sx, ex, sy, ey, sz, ez)
            for x in range(sx, ex+1):
                for y in range(sy, ey+1):
                    for z in range(sz, ez+1):
                        print(x, y, z)
                        self.window.model.add_block((x, y, z), block)
        elif sc[0] == "/setPlace":
            amount = 1 if len(sc) == 1 else int(sc[1])
            self.window.player.setPlace(int(sc[1]), sc[2], amount)
        elif sc[0] == "/save":
            self.window.worldname = None
            WorldSaver.saveWorld(self.window.model, sc[1])
            self.window.worldname = sc[1]
        elif sc[0] == "/change":
            start = int(sc[1])
            end = int(sc[2])
            slotA = self.window.player.getSlot(start).getData()
            slotB = self.window.player.getSlot(end).getData()
            self.window.player.getSlot(end).setItem(slotA[0])
            self.window.player.getSlot(end).setAmount(slotA[1])
            self.window.player.getSlot(start).setItem(slotB[0])
            self.window.player.getSlot(start).setAmount(slotB[1])
        elif sc[0] == "/info":
            vector = self.window.get_sight_vector()
            block, previous = self.window.model.hit_test(self.window.position, vector)
            if block:
                print(self.window.model.world[block].getInfoData())
        elif sc[0] == "/nbtNameInfo":
            vector = self.window.get_sight_vector()
            block, previous = self.window.model.hit_test(self.window.position, vector)
            if block:
                print(self.window.model.world[block].getNBTNames())
        elif sc[0] == "/nbtchange":
            vector = self.window.get_sight_vector()
            block, previous = self.window.model.hit_test(self.window.position, vector)
            if block:
                print(self.window.model.world[block].setNBT(sc[1], config.convertOption(sc[2])))
            self.excecute("/texupdate")
        elif sc[0] == "/nbtread":
            vector = self.window.get_sight_vector()
            block, previous = self.window.model.hit_test(self.window.position, vector)
            if block:
                print(self.window.model.world[block].getNBT(sc[1]))
        elif sc[0] == "/texupdate":
            vector = self.window.get_sight_vector()
            block, previous = self.window.model.hit_test(self.window.position, vector)
            if block:
                print(self.window.model.world[block].generateTEX())
                self.window.model.hide_block(block)
                self.window.model.show_block(block)
        elif sc[0] == "/changeinventory":
            if sc[1] == "1":
                id = int(sc[2])
                x, y = int(sc[3]), int(sc[4])
                slot = self.window.player.getSlot(id)
                slot.setPos(x, y)
        elif sc[0] == "/itemnbtread":
            if self.window.player.inventory.hotbar_slots[self.window.hotbarelement] != None:
                print(self.window.player.inventory.hotbar_slots[self.window.hotbarelement].item.blocknbt,
                      self.window.player.inventory.hotbar_slots[self.window.hotbarelement].item.getName())
        elif sc[0] == "/updatecrafting":
            craftinghandler.check_player(self.window.player)
        elif sc[0] == "/itemnameread":
            try:
                print(self.window.player.inventory.hotbar_slots[self.window.hotbarelement].item.id)
            except:
                print("no item found")
        elif sc[0] == "/getOpenGuis":
            print(invhandler.inventoryinst)
        elif sc[0] == "/resetInventory":
            invhandler.shown = [0]
        elif sc[0] == "/generate":
            sector = sectorize(self.window.position)
            l = WorldHandler.generateChunkA(sector[0] * SECTOR_SIZE, sector[2] * SECTOR_SIZE, (16, 16), self.window.model)
            for e in l:
                self.window.model.add_block(*e[1:], save=False)
        elif sc[0] == "/load":
            self.window.worldname = None
            name = sc[1]
            WorldSaver.loadWorld(self.window.model, name)
            self.window.worldname = name
        elif sc[0] == "/generatechunk":
            sector = (int(sc[1]), int(sc[2]))
            l = WorldHandler.generateChunkA(sector[0] * SECTOR_SIZE, sector[2] * SECTOR_SIZE, (16, 16),
                                            self.window.model)
            for e in l:
                self.window.model.add_block(*e[1:])
        elif sc[0] == "/movecamera":
            self.window.rotation = (int(sc[1]), int(sc[2]))
        elif sc[0] == "/gamerule":
            name = sc[1]
            value = sc[2]
            config.convertOption(value)
            config.CONFIGS[name] = value
        elif sc[0] == "/resetslots":
            for e in invhandler.inventoryslotsinst.keys():
                invhandler.inventoryslotsinst[e].reset()
        elif sc[0] == "/list":
            if len(sc) == 1:
                print("[ERROR] syntax error: command lenght incorrect")
                eventhandler.call("on_unknown_command_executed", sc)
                return
            if sc[1] == "blocks":
                print(Blocks.handler.blocks)
            elif sc[1] == "items":
                print(Item.handler.nametoitem)
            elif sc[1] == "recipis":
                for e in crafting.craftinghandler.recipis.keys():
                    print("recipi "+str(e)+":")
                    for r in crafting.craftinghandler.recipis[e]:
                        print("    Recipi{grid="+str(e)+", inputs="+str(r.input)+str(r.inputamount)+", outputs="+str(r.output)+str(r.outputamount)+", args="+str(r.args)+
                              ", kwargs="+str(r.kwargs)+"}")
            elif sc[1] == "commands":
                self.excecute("/help")
        elif sc[0] == "/reload":
            shown = self.window.model.shown_sectors[:]
            for e in self.window.model.shown_sectors:
                if e in self.window.model.shown_sectors:
                    self.window.model.hide_sector(e)
            print(shown)
            self.window.model.change_sectors(None, sectorize(self.window.position))
        elif sc[0] == "/savestructur":
            name = sc[1]
            sx = int(sc[2]); sy = int(sc[3]); sz = int(sc[4])
            ex = int(sc[5]); ey = int(sc[6]); ez = int(sc[7])
            copyair = bool(sc[8]) if len(sc) > 8 else False
            if sx > ex:
                d = sx
                sx = ex
                ex = d
            if sy > ey:
                d = sy
                sy = ey
                ey = d
            if sz > ez:
                d = sz
                sz = ez
                ez = d
            commands = []
            for x in range(sx, ex):
                for y in range(sy, ey):
                    for z in range(sz, ez):
                        if not (x, y, z) in self.window.model.world:
                            if copyair:
                                commands.append([1, (x-sx, y-sy, z-sz)])
                        else:
                            commands.append([0, self.window.model.world[(x, y, z)].getName(), (x-sx, y-sy, z-sz)])
            f = open("./assets/structures/"+name+".structur", mode="wb")
            pickle.dump({"version":structures.STRUCTUR_VERSION,
          "size":(ex-sx, ey-sy, ez-sz),
          "blocks":commands,
          "name":name}, f)
            f.close()
        elif sc[0] == "/gamestatechange":
            self.window.set_menü(sc[1])
        elif sc[0] == "/backup":
            name = sc[1] if len(sc) > 1 else self.window.worldname + "_backup_"+str(time.time())
            oname = self.window.worldname
            WorldSaver.saveWorld(self.window.model, name)
            WorldSaver.saveWorld(self.window.model, oname)
        else:
            print("error::unknowncommand")
            print(sc)
            eventhandler.call("on_unknown_command_executed", sc)
            self.window.set_menü("game")
            return
        eventhandler.call("on_command_executed", sc)
        self.window.set_menü("game")

chat = chat()
