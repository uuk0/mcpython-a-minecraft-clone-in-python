from .Block import *
from TickHandler import handler as tickhandler
from .fallingblock import *

class Gravel(FallingBlock):
    def getTex(self):
        return tex_coords((1, 5), (1, 5), (1, 5))

    def getName(self):
        return "minecraft:gravel"

    def getDestroyGroups(self):
        return [destroyGroups.SHOVEL]

handler.register(Gravel)
