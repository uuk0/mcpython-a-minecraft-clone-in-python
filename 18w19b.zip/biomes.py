import Item, Blocks, Random, structures

class BiomeHandler:
    def __init__(self):
        self.biomes = {}
        self.prefixes = []

    def getBiome(self, name):
        if type(name) == str:
            if name in self.biomes:
                return self.biomes[name]
            for pre in self.prefixes:
                if pre+":"+name in self.biomes:
                    return self.biomes[pre+":"+name]
            return None
        else:
            return name

class Biome:
    def __init__(self, poslist, seed):
        self.poslist = poslist
        self.generated = []
        self.blocked = []
        self.seed = seed

    def getTemperatur(self):
        return None

    def getStructures(self):
        return []

    def getStoneArgs(self): #!
        return ["minecraft:stone"]

    def getHighDiffrents(self, x, z):
        return 0

    def GenerateBiome(self, model):
        for p in self.poslist:
            if p not in self.generated:
                self.generated.append(p)
                x, z = p
                high = self.getHight(model, x, z)
                model.add_block((x, 0, z), "minecraft:bedrock", save=False, immediate=False)
                for y in range(1, 5):
                    if round(Random.randint(self.seed, (x, y, z)) * 4) == 1:
                        model.add_block((x, y, z), "minecraft:bedrock", save=False, immediate=False)
                    else:
                        model.add_block((x, y, z), self.getMaterial(x, y, z, high), save=False, immediate=False)
                for y in range(5, high):
                    if not self.hasOre(x, y, z, high):
                        model.add_block((x, y, z), self.getMaterial(x, y, z, high), save=False, immediate=False)
                    else:
                        model.add_block((x, y, z), self.getOre(x, y, z), save=False, immediate=False)
                struct = self.getStructur((x, y, z), high)
                if struct:
                    struct.past(model, x, high, z)

    def getMaterial(self, x, y, z, high):
        pass

    def getOre(self, x, y, z):
        pass

    def getStructur(self, pos, high):
        return None

    def hasOre(self, x, y, z, high):
        return False

    def getName(self):
        return ""

    def getStartHigh(self):
        return 10

    def getHight(self, model, x, z):
        highdata = model.high_data
        if (x, z) in highdata: return highdata[(x, z)]
        sourounding = [(x-1, z-1), (x-1, z), (x-1, z+1), (x, z-1), (x, z), (x, z+1), (x+1, z-1), (x+1, z), (x+1, z+1)]
        high_data = []
        for e in sourounding:
            if e in highdata:
                high_data.append([e, highdata[e]])
        maxh = 0
        minh = 2000
        for e in high_data:
            e = e[1]
            if e > maxh:
                maxh = e
            if e < minh:
                minh = e
        if len(high_data)>0:
            y = round((maxh + minh) / 2)
        else:
            y = self.getStartHigh()
        y += self.getHighDiffrents(x, z)
        i = 0
        if y < 5:
            y = self.getStartHigh()
        y = round(y)
        model.high_data[(x, z)] = y
        return y

class FlatBiomeSandstone(Biome):
    def getHighDiffrents(self, x, z):
        return 0

    def getMaterial(self, x, y, z, high):
        return "minecraft:sandstone"

    def getTemperatur(self):
        return 0

    def getHight(self, model, x, z):
        return 10

class FlatBiomeDirt(Biome):
    def getHighDiffrents(self, x, z):
        return 0

    def getMaterial(self, x, y, z, high):
        return "minecraft:dirt" if y != high else "minecraft:grass"

    def getTemperatur(self):
        return 0

    def getHight(self, model, x, z):
        return 10

class BaseBiome(Biome):   
    def getHighDiffrents(self, x, z):
        return round(Random.randint(self.seed, [x, z, 123]) * 4 - 2) if round(Random.randint(self.seed, [x, z, 0]) * 3) == 1 else 0

    def getTemperatur(self):
        return 1

    def getOre(self, x, y, z):
        return Random.choice(self.seed, [x, y, z], ["minecraft:iron_ore", "minecraft:coal_ore", "minecraft:diamond_ore", "minecraft:gold_ore",
                                                    "minecraft:emerald_ore"])

    def hasOre(self, x, y, z, high):
        r = round(Random.randint(self.seed, [x, y, z, high]) * 10) == 1 and high / 1.5 > y
        return r

    def getMaterial(self, x, y, z, high):
        return "minecraft:stone" if high / 1.5 > y else ("minecraft:dirt" if y != high - 1 else "minecraft:grass")

    def getName(self):
        return "mcpython:biome_base"

    def getStructures(self):
        return ["tree_0"]

    def getStructur(self, pos, high):
        r = round(Random.randint(self.seed, [pos, high]) * 20)
        #print(r)
        if r == 1:
            return structures.handler.structurs["tree_0"]
        return None

    def getStartHigh(self):
        return 20

class ColdTaiga(Biome): #missing: snow layers, snowing, grass, farn, flowers, mushrooms, wolfs, kaninchen
    def getName(self):
        return "minecraft:biome:cold_taiga"

    def getStructures(self):
        return ["tree_2", "tree_2_M"]

    def getHighDiffrents(self, x, z):
        return round(Random.randint(self.seed, [x, z, 123]) * 2 - 0.5) if round(Random.randint(self.seed, [x, z, 0]) * 7) == 1 else 0

    def getTemperatur(self):
        return 1

    def getOre(self, x, y, z):
        return Random.choice(self.seed, [x, y, z], ["minecraft:iron_ore", "minecraft:coal_ore", "minecraft:diamond_ore", "minecraft:gold_ore"])

    def hasOre(self, x, y, z, high):
        r = round(Random.randint(self.seed, [x, y, z, high]) * 15) == 1 and high / 1.5 > y
        return r

    def getMaterial(self, x, y, z, high):
        return "minecraft:stone" if high / 1.5 > y else ("minecraft:dirt" if y != high - 1 else "minecraft:grass")

    def getStructur(self, pos, high):
        r = round(Random.randint(self.seed, [pos, high]) * 30)
        if r == 1:
            return structures.handler.structurs["tree_2"]
        elif r == 1:
            return structures.handler.structurs["tree_2_M"]
        return None

    def getStartHigh(self):
        return 20


