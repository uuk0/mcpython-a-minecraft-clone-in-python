from .Block import *

class wood_plank_0(Block):
    def getName(self):
        return "minecraft:wood_plank_0"

    def getTex(self):
        return tex_coords((0, 7), (0, 7), (0, 7))

    def getDestroyGroups(self):
        return [destroyGroups.AXE]

handler.register(wood_plank_0)

class wood_plank_1(Block):
    def getName(self):
        return "minecraft:wood_plank_1"

    def getTex(self):
        return tex_coords((1, 7), (1, 7), (1, 7))

    def getDestroyGroups(self):
        return [destroyGroups.AXE]

handler.register(wood_plank_1)

class wood_plank_2(Block):
    def getName(self):
        return "minecraft:wood_plank_2"

    def getTex(self):
        return tex_coords((2, 7), (2, 7), (2, 7))

    def getDestroyGroups(self):
        return [destroyGroups.AXE]

handler.register(wood_plank_2)

class wood_plank_3(Block):
    def getName(self):
        return "minecraft:wood_plank_3"

    def getTex(self):
        return tex_coords((3, 7), (3, 7), (3, 7))

    def getDestroyGroups(self):
        return [destroyGroups.AXE]

handler.register(wood_plank_3)
