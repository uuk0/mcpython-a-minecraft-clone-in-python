from .Block import *
from oredictnames import OreDict
from destroyGroup import *

class Grass(Block):
    def getTex(self):
        return tex_coords((1, 0), (0, 1), (0, 0))

    def getName(self):
        return "minecraft:grass"

    def getDrop(self, item):
        return "minecraft:dirt"

    def getOreDictNames(self):
        return [OreDict.DIRT, OreDict.GRASS]

    def getDestroyGroups(self):
        return [destroyGroups.SHOVEL]

handler.register(Grass)
