from .Item import *

class Wood_0_Slab(Item):
    def getName(self):
        return "minecraft:wood_slab_0"

    def getTexturFile(self):
        return "./assets/textures/items/wood_slab_0.png"

    def canInteractWith(self, block):
        if block.getName() == "minecraft:wood_slab_0" and block.side != "A":
            block.setNBT("side", "A")

handler.register(Wood_0_Slab)
